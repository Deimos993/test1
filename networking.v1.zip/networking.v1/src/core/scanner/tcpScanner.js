// src/core/scanner/tcpScanner.js
const net = require('net');
const { getServiceName } = require('../../utils/portUtils');
const config = require('../../config');
const { parsePorts } = require('../../utils/scanHelpers');
const pLimit = require('p-limit').default || require('p-limit'); // This import remains correct

/**
 * Esegue una TCP connect scan (simula SYN scan, ma è una connect completa).
 * Per una vera SYN scan, sarebbe necessaria l'integrazione di Nmap o l'uso di raw sockets (es. node-raw-socket).
 * @param {string} host - Host da scansionare.
 * @param {string|Array|number} ports - Lista o range di porte.
 * @param {number} timing - Profilo di timing da 1 a 5.
 * @returns {Promise<Array>} Risultati della scansione.
 */
async function doTcpScan(host, ports, timing = 4) {
    const results = [];
    const portList = parsePorts(ports);
    const timeout = config.scan_timeouts.tcp[timing] || 500;

    // Dichiarazione e inizializzazione di concurrencyLimit e limit qui, all'interno della funzione
    // dove concurrencyLimit è definito e accessibile.
    const concurrencyLimit = config.scan_limits.tcpConcurrency || 200;
    const limit = pLimit(concurrencyLimit); // Questa riga crea la funzione di limitazione

    const promises = portList.map(port => limit(() => new Promise((resolve) => {
        const socket = new net.Socket();
        socket.setTimeout(timeout);

        const startTime = Date.now();

        socket.connect(port, host, () => {
            const elapsed = Date.now() - startTime;
            results.push({
                port,
                protocol: 'tcp',
                status: 'open',
                service: getServiceName(port),
                responseTime: `${elapsed}ms`,
                reason: 'tcp-connect-success'
            });
            socket.destroy();
            resolve();
        });

        socket.on('timeout', () => {
            results.push({
                port,
                protocol: 'tcp',
                status: 'filtered',
                service: getServiceName(port),
                responseTime: `>${timeout}ms`,
                reason: 'timeout'
            });
            socket.destroy();
            resolve();
        });

        socket.on('error', (err) => {
            const elapsed = Date.now() - startTime;
            results.push({
                port,
                protocol: 'tcp',
                status: 'closed',
                service: getServiceName(port),
                responseTime: `${elapsed}ms`,
                reason: err.code || 'connection-error'
            });
            socket.destroy();
            resolve();
        });
    })));

    await Promise.all(promises);
    return results.sort((a, b) => a.port - b.port);
}

module.exports = { doTcpScan };