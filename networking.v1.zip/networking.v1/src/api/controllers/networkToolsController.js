// api/controllers/networkToolsController.js
const os = require('os');
const { exec } = require('child_process');
const { performAdvancedNetworkMapping } = require('../../core/services/networkMapperService');
const { scanSinglePort } = require('../../core/services/serviceDetector');
// Consider using a more robust DNS library if nslookup becomes an issue
// const dns = require('dns'); // Node.js built-in DNS module

// REMOVE getNetworkInfo from here. It's handled by api/routes/networkRoutes.js
// const getNetworkInfo = (req, res, next) => { ... };

const pingSweep = (req, res, next) => {
    const { network } = req.body;
    if (!network) return res.status(400).json({ error: 'Network range richiesto (es. 192.168.1)' });

    const aliveHosts = [];
    const promises = [];
    const isWindows = process.platform === 'win32';
    // Shorter timeout for ping sweep to get quicker results, or delegate to networkMapperService
    const pingCommand = isWindows ? 'ping -n 1 -w 500' : 'ping -c 1 -W 0.5'; // Shorter timeout

    // It's better to use the already existing and more robust discoverAliveHosts from networkMapperService
    // However, if pingSweep is meant to be a simple, standalone function, keep it but improve.
    // For simplicity, let's keep it here for now but use the same logic as networkMapperService's discoverAliveHosts for consistency
    for (let i = 1; i <= 254; i++) {
        const host = `<span class="math-inline">\{network\}\.</span>{i}`;
        promises.push(new Promise(resolve => {
            exec(`${pingCommand} ${host}`, (error, stdout) => {
                if (!error && (stdout.includes('TTL=') || stdout.includes('ttl='))) {
                    aliveHosts.push(host);
                }
                resolve();
            });
        }));
    }
    Promise.all(promises)
        .then(() => res.json({ aliveHosts: aliveHosts.sort((a, b) => {
            const ipA = a.split('.').map(Number);
            const ipB = b.split('.').map(Number);
            for (let i = 0; i < 4; i++) {
                if (ipA[i] !== ipB[i]) {
                    return ipA[i] - ipB[i];
                }
            }
            return 0;
        })})) // Ensure correct numeric sort
        .catch(next);
};

const traceroute = (req, res, next) => {
    const { host, maxHops = 30 } = req.body;
    if (!host) return res.status(400).json({ error: 'Host è richiesto' });

    const isWindows = process.platform === 'win32';
    // Shorten timeout for traceroute to avoid blocking the API for too long
    // Traceroute can be slow, 1000ms per hop * 30 hops = 30 seconds
    // Consider client-side polling for long-running tasks.
    const traceCommand = isWindows ? `tracert -h ${maxHops} -w 1000 ${host}` : `traceroute -m ${maxHops} -w 1 ${host}`;

    exec(traceCommand, { timeout: 45000 }, (error, stdout, stderr) => { // Increased timeout slightly as it can be slow
        if (error) {
            // Check if it's a timeout error specifically
            if (error.killed && error.signal === 'SIGTERM') {
                return res.status(504).json({ error: `Traceroute timeout. Host might be unreachable or response too slow.` });
            }
            return res.status(500).json({ error: `Comando traceroute fallito: ${stderr || error.message}` });
        }
        const hops = [];
        const lines = stdout.split('\n');
        lines.forEach(line => {
            line = line.trim();
            if (!line || line.toLowerCase().includes('tracing route') || line.toLowerCase().includes('traceroute to')) return;
            const hopMatch = line.match(/^\s*(\d+)\s+(.+)/);
            if (hopMatch) {
                hops.push({ hop: parseInt(hopMatch[1]), details: hopMatch[2].trim() });
            }
        });
        res.json({ host, maxHops, hops, completed: true });
    });
};

const dnsEnum = (req, res, next) => {
    const { domain } = req.body;
    if (!domain) return res.status(400).json({ error: 'Domain è richiesto' });

    const dnsResults = { domain, records: {}, subdomains: [] };
    const recordTypes = ['A', 'AAAA', 'MX', 'NS', 'TXT', 'CNAME', 'SOA'];
    const promises = [];

    recordTypes.forEach(type => {
        promises.push(new Promise(resolve => {
            // Using dns.resolve built-in Node.js module is safer and more portable than nslookup
            // Example:
            // dns.resolve(domain, type, (err, records) => {
            //     if (!err && records) {
            //         dnsResults.records[type] = records.map(r => r.toString());
            //     }
            //     resolve();
            // });
            // For now, keeping exec for consistency with other tools, but note for future improvement
            exec(`nslookup -type=${type} ${domain}`, { timeout: 5000 }, (err, stdout) => { // Add timeout
                if (!err && stdout && !stdout.includes('** server can\'t find')) { // Check for actual results
                    const lines = stdout.split('\n').filter(l => l.trim() && !l.startsWith('Server:') && !l.startsWith('Address:'));
                    // Filter out empty lines and irrelevant nslookup output
                    dnsResults.records[type] = lines.filter(line => !line.includes('Non-existent domain') && !line.includes('can\'t find')).map(l => l.trim());
                }
                resolve();
            });
        }));
    });

    const commonSubdomains = ['www', 'mail', 'ftp', 'admin', 'api', 'dev', 'test', 'blog', 'shop']; // Add more common subdomains
    commonSubdomains.forEach(sub => {
        promises.push(new Promise(resolve => {
            exec(`nslookup <span class="math-inline">\{sub\}\.</span>{domain}`, { timeout: 5000 }, (err, stdout) => { // Add timeout
                if (!err && stdout && !stdout.includes('**') && !stdout.includes('NXDOMAIN') && !stdout.includes('can\'t find') && !stdout.includes('SERVFAIL')) {
                    // Check if an IP address is found
                    if (stdout.match(/\nAddress: (\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/)) {
                         dnsResults.subdomains.push(`<span class="math-inline">\{sub\}\.</span>{domain}`);
                    }
                }
                resolve();
            });
        }));
    });

    Promise.all(promises).then(() => res.json(dnsResults)).catch(next);
};


const networkMap = async (req, res, next) => {
    try {
        const { network, options } = req.body;
        if (!network) return res.status(400).json({ error: 'Network range richiesto (es. 192.168.1)' });

        // Validate network format using the new middleware if applicable or inline
        // Make sure networkValidator is applied to this route if needed.

        const results = await performAdvancedNetworkMapping(network, options);
        const statistics = {
            totalHostsInSubnet: 254, // Always 254 for a /24 subnet (1 to 254)
            aliveHosts: results.hosts.length,
            hostsWithOpenPorts: results.hosts.filter(h => h.openPorts?.length > 0).length,
            totalVulnerabilities: results.hosts.reduce((sum, h) => sum + (h.vulnerabilities?.length || 0), 0)
        };

        res.json({ ...results, statistics });
    } catch (error) {
        next(error);
    }
};

const singlePortScan = async (req, res, next) => {
    try {
        const { host, port } = req.body;
        if (!host || !port) {
            return res.status(400).json({ error: 'Host e porta sono richiesti' });
        }
        // Ensure port is a number
        const portNum = parseInt(port, 10);
        if (isNaN(portNum) || portNum < 1 || portNum > 65535) {
            return res.status(400).json({ error: 'Porta non valida. Deve essere un numero tra 1 e 65535.' });
        }

        const result = await scanSinglePort(host, portNum);
        res.json(result);
    } catch(error) {
        next(error);
    }
};

module.exports = {
    // getNetworkInfo, // Removed
    pingSweep,
    traceroute,
    dnsEnum,
    networkMap,
    singlePortScan,
};