const express = require('express');
const router = express.Router();
const os = require('os');

router.get('/local-info', (req, res) => {
    try {
        const interfaces = os.networkInterfaces();
        let networkBase = null;
        let localIP = null;

        // Analizza tutte le interfacce
        Object.values(interfaces).forEach(iface => {
            iface.forEach(addr => {
                if (addr.family === 'IPv4' && !addr.internal) {
                    const parts = addr.address.split('.');
                    if (parts.length === 4) {
                        networkBase = parts.slice(0, 3).join('.');
                        localIP = addr.address;
                    }
                }
            });
        });

        res.json({
            localIP,
            networkBase,
            interfaces: Object.keys(interfaces)
        });
    } catch (error) {
        res.status(500).json({ error: 'Errore rilevazione rete' });
    }
});

module.exports = router;
