// src/config/index.js
require('dotenv').config();

const config = {
    port: process.env.PORT || 3000,
    nvd: {
        apiKey: process.env.NIST_API_KEY,
        baseUrl: 'https://services.nvd.nist.gov/rest/json/cves/2.0',
    },
    scan_timeouts: {
        tcp: { 1: 5000, 2: 2500, 3: 1250, 4: 500, 5: 250 },
        udp: { 1: 3000, 2: 2000, 3: 1500, 4: 1000, 5: 500 },
        banner: 2000,
        postgres: 2000,
        http: 2000,
    },
    scan_limits: {
        tcpConcurrency: parseInt(process.env.SCAN_TCP_CONCURRENCY || '200', 10),
        udpConcurrency: parseInt(process.env.SCAN_UDP_CONCURRENCY || '50', 10),
        hostDiscoveryConcurrency: parseInt(process.env.SCAN_HOST_DISCOVERY_CONCURRENCY || '255', 10),
    },
    // Nuova sezione per la configurazione SSH
    ssh_tool: {
        port: parseInt(process.env.SSH_TOOL_PORT || '3001', 10), // Porta specifica per il WebSocket SSH
        rate_limit_delay: parseInt(process.env.SSH_RATE_LIMIT_DELAY || '750', 10), // ms tra tentativi
        connection_timeout: parseInt(process.env.SSH_CONNECTION_TIMEOUT || '8000', 10), // timeout connessione SSH
        max_concurrent_connections: parseInt(process.env.SSH_MAX_CONCURRENT_CONNECTIONS || '5', 10),
        
        // Percorsi per i log (relativi alla radice del progetto se accessibili)
        log_dir: process.env.SSH_LOG_DIR || './logs', // Usa ./logs dalla radice del progetto
        audit_log_path: process.env.SSH_AUDIT_LOG_PATH || './logs/ssh_audit.log',
        error_log_path: process.env.SSH_ERROR_LOG_PATH || './logs/ssh_errors.log',
        
        // Algoritmi crittografici moderni
        algorithms: {
            kex: [
                'curve25519-sha256@libssh.org',
                'ecdh-sha2-nistp384',
                'ecdh-sha2-nistp521',
                'diffie-hellman-group-exchange-sha256',
                'diffie-hellman-group16-sha512'
            ],
            serverHostKey: [
                'ssh-ed25519',
                'ecdsa-sha2-nistp521',
                'rsa-sha2-512',
                'rsa-sha2-256'
            ],
            cipher: [
                'chacha20-poly1305@openssh.com',
                'aes256-gcm@openssh.com',
                'aes128-gcm@openssh.com',
                'aes256-ctr',
                'aes192-ctr',
                'aes128-ctr'
            ],
            hmac: [
                'hmac-sha2-256-etm@openssh.com',
                'hmac-sha2-512-etm@openssh.com'
            ]
        }
    }
};

module.exports = config;