const express = require('express');
const router = express.Router();
const { handleBeacon } = require('../controllers/c2Controller');

router.post('/collect', handleBeacon);

module.exports = router;
