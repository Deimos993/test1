// api/routes/index.js
const express = require('express');
const router = express.Router();

const nmapRoutes = require('./nmapRoutes');
const vulnerabilityRoutes = require('./vulnerabilityRoutes');
const networkToolsRoutes = require('./networkToolsRoutes');
const networkRoutes = require('./networkRoutes'); // Add this lineù

const c2Routes = require('./c2Routes'); // ✅ importa le rotte C2

const sqlRoutes = require('./sqlRoutes');
const toolsRoutes = require('./tools');

router.use('/sql', sqlRoutes);      // <- questo monta tutto su /api/v1/sql/
router.use('/tools', toolsRoutes);  // già presente

// Monta i router specifici su sotto-percorsi
router.use('/nmap', nmapRoutes);
router.use('/vuln', vulnerabilityRoutes);
router.use('/tools', networkToolsRoutes);
router.use('/network', networkRoutes); // Add this line

router.use('/attack', c2Routes);        // ✅ monta su /attack


module.exports = router;