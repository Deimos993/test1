// routes/rateLimitRoutes.js
const express = require('express');
const router = express.Router();
const {
    setRateLimitStatus,
    getRateLimitStatus
} = require('../middleware/rateLimiter');
const authenticateToken = require('../middleware/authMiddleware');

// Attiva/disattiva il rate limiting
router.post('/toggle', authenticateToken, (req, res) => {
    const { enabled } = req.body;
    if (typeof enabled !== 'boolean') {
        return res.status(400).json({ error: 'Parametro "enabled" richiesto (boolean)' });
    }

    setRateLimitStatus(enabled);
    res.json({ message: `Rate limiting ${enabled ? 'abilitato' : 'disabilitato'}` });
});

// Ottiene lo stato corrente
router.get('/status', authenticateToken, (req, res) => {
    res.json({ enabled: getRateLimitStatus() });
});

module.exports = router;
