// src/core/services/sqlInjectionService.js

const { v4: uuidv4 } = require('uuid');
const axios = require('axios');
const cheerio = require('cheerio');
const config = require('../../config');
const logger = require('../../utils/logger');

const activeScans = new Map();

async function runScan(scanId, url, options) {
    const scan = activeScans.get(scanId);
    if (!scan) return;

    try {
        scan.status = 'running';
        scan.currentTest = 'Enumerating injection points...';

        const injectionPoints = await discoverInjectionPoints(url);
        scan.stats.injectionPoints = injectionPoints.length;

        if (injectionPoints.length === 0) {
            scan.results.push({ message: 'No potential injection points found.' });
            throw new Error('No injection points identified.');
        }

        const payloads = getPayloads(options.scanType);
        scan.stats.estimatedTotal = injectionPoints.length * payloads.length;

        for (const point of injectionPoints) {
            if (scan.status !== 'running') break;
            const pointResult = { point, results: [] };

            for (const payload of payloads) {
                if (scan.status !== 'running') break;

                if (options.safeMode && isDestructive(payload)) continue;

                scan.currentTest = `Testing ${point.name} with payload: ${payload}`;
                scan.stats.totalTests++;

                const result = await executePayloadTest(point, payload, url);
                pointResult.results.push(result);

                if (result.isVulnerable) {
                    scan.stats.vulnerabilitiesFound++;
                }
            }

            scan.results.push(pointResult);
        }

        scan.status = scan.status === 'running' ? 'completed' : scan.status;

    } catch (error) {
        scan.status = 'error';
        scan.error = error.message;
        logger.error(`Scan ${scanId} failed: ${error.message}`);
    } finally {
        scan.endTime = new Date();
        activeScans.set(scanId, scan);
    }
}

async function discoverInjectionPoints(url) {
    const points = [];
    const response = await axios.get(url, { timeout: config.sql_injection.timeout });
    const $ = cheerio.load(response.data);

    $('form').each((_, form) => {
        const action = $(form).attr('action') || url;
        const method = ($(form).attr('method') || 'GET').toUpperCase();

        $(form).find('input, textarea, select').each((_, input) => {
            const name = $(input).attr('name');
            if (name) {
                points.push({ type: 'form', name, method, action });
            }
        });
    });

    const urlParams = new URL(url).searchParams;
    urlParams.forEach((_, name) => {
        points.push({ type: 'url', name, method: 'GET', action: url });
    });

    return points;
}

async function executePayloadTest(point, payload, originalUrl) {
    const result = { payload, isVulnerable: false, status: 'tested', error: null };
    const scanType = Object.keys(config.sql_injection.payloads).find(key =>
        config.sql_injection.payloads[key].includes(payload)
    );

    try {
        // === Error-Based + Time-Based ===
        const testVal = `test${payload}`;
        const start = Date.now();
        const response = await makeRequest(point, testVal, originalUrl);
        const time = Date.now() - start;
        const html = response.data?.toString?.() || '';

        if (config.sql_injection.error_signatures?.some(sig => html.includes(sig))) {
            result.isVulnerable = true;
            result.status = 'vulnerable (error-based)';
            return result;
        }
        if (time > 4500) {
            result.isVulnerable = true;
            result.status = 'vulnerable (time-based)';
            return result;
        }

        // === Boolean-Based ===
        if (scanType === 'boolean') {
            const truePayload = payload;
            const falsePayload = payload
                .replace(/1'='1/g, "1'='2'")
                .replace(/1=1/g, "1=2");

            const baselineRes = await makeRequest(point, 'baseline', originalUrl);
            const trueRes = await makeRequest(point, `test${truePayload}`, originalUrl);
            const falseRes = await makeRequest(point, `test${falsePayload}`, originalUrl);

            const baseline = baselineRes.data.toString();
            const trueBody = trueRes.data.toString();
            const falseBody = falseRes.data.toString();

            if (
                trueBody.length !== baseline.length &&
                falseBody.length === baseline.length
            ) {
                result.isVulnerable = true;
                result.status = 'vulnerable (boolean-based)';
            }
        }

    } catch (err) {
        result.error = err.message;
        result.status = 'error';
    }

    return result;
}


function getPayloads(scanType) {
    const p = config.sql_injection.payloads;
    if (p[scanType]) return p[scanType];
    if (scanType === 'full') return Object.values(p).flat();
    return p.basic;
}

function isDestructive(payload) {
    return config.sql_injection.destructive_patterns.some(p => payload.toUpperCase().includes(p));
}

module.exports = {
    async scan(targetUrl, options) {
        const scanId = uuidv4();
        const metadata = {
            id: scanId,
            target: targetUrl,
            status: 'queued',
            startTime: new Date(),
            endTime: null,
            currentTest: 'queued',
            results: [],
            stats: {
                injectionPoints: 0,
                totalTests: 0,
                estimatedTotal: 0,
                vulnerabilitiesFound: 0,
            }
        };

        activeScans.set(scanId, metadata);
        logger.info(`Initiated SQLi scan ${scanId} on ${targetUrl}`);

        runScan(scanId, targetUrl, options);
        return metadata;
    },

    getScanStatus(id) {
        return activeScans.get(id);
    },

    cancelScan(id) {
        const scan = activeScans.get(id);
        if (scan && scan.status === 'running') {
            scan.status = 'cancelled';
            logger.warn(`SQLi scan ${id} cancelled.`);
            return true;
        }
        return false;
    }
};
