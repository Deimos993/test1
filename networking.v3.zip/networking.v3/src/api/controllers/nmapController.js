const { doTcpScan, doUdpScan } = require('../../core/scanner/tcpScanner');
const orchestrator = require('../../core/services/scanOrchestrator');

const synScan = async (req, res, next) => {
    try {
        const { host, ports, timing = 4 } = req.body;
        if (!host || !ports) {
            return res.status(400).json({ error: 'Host e ports sono richiesti' });
        }
        const results = await doTcpScan(host, ports, timing);
        res.json({
            scanType: 'TCP Scan',
            host,
            timing: `T${timing}`,
            results: results
        });
    } catch (error) {
        next(error);
    }
};

const comprehensiveScan = async (req, res, next) => {
    try {
        const { host, timing = 4 } = req.body;
        if (!host) {
            return res.status(400).json({ error: 'Host è richiesto' });
        }
        const results = await orchestrator.performComprehensiveScan(host, timing);
        res.json(results);
    } catch (error) {
        next(error);
    }
};

const fullPortScan = async (req, res, next) => {
     try {
        const { host, maxPorts = 1000, timing = 4 } = req.body;
        if (!host) {
            return res.status(400).json({ error: 'Host è richiesto' });
        }
        const results = await orchestrator.performFullPortScan(host, maxPorts, timing);
        res.json(results);
    } catch (error) {
        next(error);
    }
};

module.exports = {
    synScan,
    comprehensiveScan,
    fullPortScan,
};