// src/core/services/nvdService.js
const axios = require('axios');
const semver = require('semver');
const config = require('../../config');
const { generateCpeName } = require('../../utils/cpeUtils');

/**
 * Trova le vulnerabilità utilizzando una ricerca di precisione basata su CPE Name interrogando l'API NVD.
 * @param {Array} services - Array di oggetti servizio dal fingerprinting.
 * @returns {Promise<Array>} - Un array di oggetti CVE che corrispondono.
 */
async function findVulnerabilitiesFor(services) {
    // Non avvisare se la chiave API non è configurata, ma non inviarla se non esiste.
    // L'API NVD richiede una chiave per l'uso in produzione. Senza chiave, potresti incontrare limitazioni.
    const headers = {};
    if (config.nvd.apiKey && config.nvd.apiKey !== 'LA_TUA_CHIAVE_API_NVD_QUI') {
        headers['apiKey'] = config.nvd.apiKey;
    } else {
        console.warn('WARN: Chiave API NVD non configurata. Le richieste potrebbero essere limitate o fallire.');
    }

    let allFoundVulns = [];

    for (const service of services) {
        if (!service.version || service.version === 'unknown') continue;

        // Estrae prodotto e versione dal risultato del service detector
        const versionString = service.version.toLowerCase();
        let product = service.service; // Usa il nome del servizio come fallback
        const productMatch = versionString.match(/^([a-zA-Z\-]+)/);
        if (productMatch) {
            product = productMatch[1].trim();
        }
        
        // Pulisci ulteriormente la stringa di versione per renderla compatibile con semver
        // Rimuovi prefissi non numerici come 'v' e caratteri speciali non numerici/punto
        const cleanVersion = semver.coerce(service.version); // semver.coerce è già abbastanza robusto
        if (!cleanVersion) {
            // console.log(`INFO: Versione "${service.version}" non coercibile per CPE. Salto.`); // Per debugging
            continue;
        }

        const cpeName = generateCpeName(product, cleanVersion.version); // Usa la versione coercita
        if (!cpeName) {
            console.log(`INFO: Nessuna mappatura CPE per il prodotto "${product}" con versione "${cleanVersion.version}".`);
            continue;
        }

        try {
            console.log(`INFO: Eseguo ricerca di vulnerabilità per CPE: ${cpeName}`);
            const response = await axios.get(config.nvd.baseUrl, {
                headers: headers, // Usa l'oggetto headers condizionale
                params: { 'cpeName': cpeName },
                timeout: 10000 // Aggiungi un timeout per le richieste NVD
            });

            if (response.data.vulnerabilities?.length > 0) {
                response.data.vulnerabilities.forEach(item => {
                    const cve = item.cve;
                    const cvssMetric = cve.metrics.cvssMetricV31?.[0] || cve.metrics.cvssMetricV2?.[0];
                    allFoundVulns.push({
                        port: service.port,
                        cveId: cve.id,
                        description: cve.descriptions.find(d => d.lang === 'en')?.value || 'No description available.',
                        severity: cvssMetric?.cvssData.baseSeverity || 'UNKNOWN',
                        score: cvssMetric?.cvssData.baseScore || 'N/A',
                        source: cve.sourceIdentifier || 'N/A',
                        cpe: cve.configurations?.[0]?.nodes?.[0]?.cpeMatch?.[0]?.criteria || cpeName // Aggiungi il CPE effettivo
                    });
                });
            } else {
                 console.log(`INFO: Nessuna CVE trovata per ${cpeName}`);
            }
        } catch (error) {
             console.error(`ERRORE: Impossibile interrogare NVD per ${cpeName}. Dettagli: ${error.response?.status} - ${error.response?.data?.message || error.message}`);
        }
    }

    // Rimuovi duplicati basati su cveId
    const uniqueVulns = [...new Map(allFoundVulns.map(item => [item.cveId, item])).values()];
    return uniqueVulns;
}

module.exports = { findVulnerabilitiesFor };