// utils/cpeUtils.js
/**
 * Tenta di generare un CPE 2.3 Name standardizzato a partire da un prodotto e una versione.
 * @param {string} product - Il nome del prodotto (es. 'apache', 'nginx').
 * @param {string} version - La stringa della versione del prodotto.
 * @returns {string|null} - Il CPE Name o null se non c'è una mappatura.
 */
function generateCpeName(product, version) {
    // Mappatura da nomi di prodotto comuni a nomi CPE ufficiali
    // Questa lista è stata estesa per migliorare la copertura del rilevamento delle vulnerabilità.
    const productMap = {
        'apache': 'apache:http_server',
        'nginx': 'nginx:nginx',
        'openssh': 'openssh:openssh',
        'vsftpd': 'vsftpd:vsftpd',
        'proftpd': 'proftpd:proftpd',
        'postgresql': 'postgresql:postgresql',
        'mysql': 'mysql:mysql',
        'mariadb': 'mariadb:mariadb',
        'redis': 'redis:redis',
        'mongodb': 'mongodb:mongodb',
        'microsoft iis': 'microsoft:internet_information_services', // Aggiunto per IIS
        'iis': 'microsoft:internet_information_services',
        'microsoft exchange': 'microsoft:exchange_server',
        'bind': 'isc:bind',
        'sendmail': 'sendmail:sendmail',
        'postfix': 'postfix:postfix',
        'docker': 'docker:docker',
        'kubernetes': 'kubernetes:kubernetes',
        'jenkins': 'jenkins:jenkins',
        'nginx unit': 'nginx:unit',
        'php': 'php:php',
        'node.js': 'nodejs:node.js',
        'tomcat': 'apache:tomcat',
        'jetty': 'eclipse:jetty',
        'squid': 'squid-cache:squid',
        'wordpress': 'wordpress:wordpress', // Esempio se il crawler potesse rilevarlo
        'joomla': 'joomla:joomla', // Esempio
        'drupal': 'drupal:drupal', // Esempio
        'jquey': 'jquery:jquery', // Esempio per librerie client-side
        'bootstrap': 'getbootstrap:bootstrap' // Esempio
    };

    const cpeProduct = productMap[product.toLowerCase()];
    if (!cpeProduct) {
        // console.warn(`WARN: Nessuna mappatura CPE diretta per il prodotto "${product}".`); // Useful for debugging
        return null;
    }

    // Pulisce la versione per assicurarsi che sia valida per un CPE, rimuovendo suffissi non numerici.
    const sanitizedVersionMatch = version.match(/^(\d+(\.\d+)*)/);
    const sanitizedVersion = sanitizedVersionMatch ? sanitizedVersionMatch[1] : '';

    if (!sanitizedVersion) {
        // console.warn(`WARN: Versione non valida per CPE per il prodotto "${product}" e versione "${version}".`); // Useful for debugging
        return null;
    }

    // Costruisce la stringa CPE 2.3. 'a' sta per 'application'.
    // Aggiunto '*' per indicare "qualsiasi" vendor (se non specificato), "qualsiasi" edizione, ecc. per maggiore generalità.
    const parts = cpeProduct.split(':');
    const vendor = parts[0];
    const item = parts[1];

    // cpe:/a:vendor:product:version:update:edition:language:sw_edition:target_sw:target_hw:other
    return `cpe:2.3:a:${vendor}:${item}:${sanitizedVersion}:*:*:*:*:*:*:*`;
}

module.exports = { generateCpeName };