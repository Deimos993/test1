const axios = require('axios');
const cheerio = require('cheerio');
const { URL } = require('url');

class WebCrawler {
    constructor(maxDepth = 2) {
        this.visited = new Set();
        this.maxDepth = maxDepth;
    }

    async crawl(url, depth = 0) {
        if (depth > this.maxDepth || this.visited.has(url)) return [];
        
        this.visited.add(url);
        const results = [];
        
        try {
            const response = await axios.get(url, {
                timeout: 5000,
                headers: { 'User-Agent': 'DeimosSecurityScanner/1.0' }
            });
            
            const $ = cheerio.load(response.data);
            results.push({
                url,
                status: response.status,
                title: $('title').text().trim(),
                links: []
            });

            // Estrazione e filtraggio link
            $('a').each((i, el) => {
                const href = $(el).attr('href');
                if (href) {
                    try {
                        const absoluteUrl = new URL(href, url).href;
                        if (!absoluteUrl.startsWith('http')) return;
                        results[0].links.push(absoluteUrl);
                    } catch (e) { /* Ignora URL malformati */ }
                }
            });

            // Crawl ricorsivo
            for (const link of results[0].links) {
                if (!this.visited.has(link)) {
                    const subResults = await this.crawl(link, depth + 1);
                    results.push(...subResults);
                }
            }
        } catch (error) {
            results.push({
                url,
                error: error.message,
                status: error.response?.status || 500
            });
        }
        
        return depth === 0 ? { pages: results } : results;
    }
}

module.exports = WebCrawler;