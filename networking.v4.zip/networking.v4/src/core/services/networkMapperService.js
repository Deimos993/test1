// src/core/services/networkMapperService.js

const { exec } = require('child_process');
const { doTcpScan } = require('../scanner/tcpScanner');
const { getTopPorts } = require('../../utils/portUtils');
const { performServiceDetection } = require('./serviceDetector');
const { performOSDetection } = require('./osDetector');
const { findVulnerabilitiesFor } = require('./nvdService');
const pLimit = require('p-limit').default || require('p-limit');
const config = require('../../config');

/**
 * Esegue una mappatura avanzata della rete, inviando aggiornamenti di stato.
 * @param {string} network
 * @param {object} options
 * @param {Function} progressCallback - Funzione per inviare aggiornamenti di progresso.
 * @returns {Promise<object>}
 */
async function performAdvancedNetworkMapping(network, options = {}, progressCallback = () => {}) {
    progressCallback({ stage: 'discovery_start', message: `Inizio Host Discovery per ${network}.0/24...` });
    const aliveHosts = await discoverAliveHosts(network, progressCallback);
    progressCallback({ stage: 'discovery_complete', message: `Host Discovery completato. Trovati ${aliveHosts.length} host attivi.`, count: aliveHosts.length });

    if (aliveHosts.length === 0) {
        return { hosts: [], topology: {} };
    }

    progressCallback({ stage: 'scan_start', message: `Inizio scansione dettagliata per ${aliveHosts.length} host...`, total: aliveHosts.length });
    
    const detailedHosts = [];
    for (let i = 0; i < aliveHosts.length; i++) {
        const host = aliveHosts[i];
        console.log(`Scanning host ${i + 1}/${aliveHosts.length}: ${host.ip}`);
        const hostInfo = await scanDetailedHostInfo(host.ip, options);
        detailedHosts.push(hostInfo);
        
        // Invia aggiornamento dopo ogni host scansionato
        progressCallback({
            stage: 'host_scanned',
            message: `Scansione completata per ${host.ip}`,
            current: i + 1,
            total: aliveHosts.length,
            hostData: hostInfo // Invia i dati parziali
        });
    }

    console.log(`[Phase 2] Scansione dettagliata completata.`);
    
    return { 
        hosts: detailedHosts.sort((a,b) => parseInt(a.ip.split('.')[3], 10) - parseInt(b.ip.split('.')[3], 10)),
        topology: buildTopology(detailedHosts)
    };
}

/**
 * Scopre host attivi inviando aggiornamenti.
 * @param {string} network
 * @param {Function} progressCallback
 * @returns {Promise<Array>}
 */
function discoverAliveHosts(network, progressCallback = () => {}) {
    const limit = pLimit(config.scan_limits.hostDiscoveryConcurrency || 50);

    return new Promise(resolve => {
        const aliveHosts = [];
        const promises = [];
        const isWindows = process.platform === 'win32';
        const pingCommand = isWindows ? 'ping -n 1 -w 500' : 'ping -c 1 -W 0.5';

        for (let i = 1; i <= 254; i++) {
            const host = `${network}.${i}`;
            promises.push(limit(() => new Promise(resolvePing => {
                exec(`${pingCommand} ${host}`, (error, stdout) => {
                    if (!error && (stdout.includes('TTL=') || stdout.includes('ttl='))) {
                        aliveHosts.push({ ip: host });
                    }
                    progressCallback({ stage: 'discovery_progress', current: i, total: 254 });
                    resolvePing();
                });
            })));
        }
        Promise.all(promises).then(() => resolve(aliveHosts));
    });
}


/**
 * Esegue scansioni dettagliate su un singolo host.
 * @param {string} ip 
 * @param {object} options 
 * @returns {Promise<object>}
 */
async function scanDetailedHostInfo(ip, options) {
    try {
        const hostInfo = { ip, openPorts: [], services: [], osDetection: {}, vulnerabilities: [] };
        
        const topPorts = getTopPorts(100);
        const portScanResults = await doTcpScan(ip, topPorts, 4);
        const openPorts = portScanResults.filter(r => r.status === 'open');
        hostInfo.openPorts = openPorts.map(p => ({ port: p.port, protocol: p.protocol, service: p.service }));
        
        if (openPorts.length > 0) {
            const [serviceDetails, osDetection] = await Promise.all([
                performServiceDetection(ip, openPorts),
                performOSDetection(openPorts)
            ]);
            hostInfo.services = serviceDetails;
            hostInfo.osDetection = osDetection;

            if (options && options.runVulnScan) {
                hostInfo.vulnerabilities = await findVulnerabilitiesFor(serviceDetails);
            }
        }
        return hostInfo;
    } catch (error) {
        console.error(`Errore durante la scansione di ${ip}:`, error);
        return { ip, error: `Scansione fallita: ${error.message}` };
    }
}

function buildTopology(hosts) {
    const servers = hosts.filter(h => {
        const serverPorts = [80, 443, 3306, 5432, 21, 25];
        return h.openPorts?.some(p => serverPorts.includes(p.port));
    });
    
    return {
        gateways: hosts.filter(h => h.ip.endsWith('.1') || h.ip.endsWith('.254')),
        servers: servers,
        workstations: hosts.filter(h => !servers.some(s => s.ip === h.ip) && !h.ip.endsWith('.1') && !h.ip.endsWith('.254')),
    };
}

module.exports = { performAdvancedNetworkMapping };