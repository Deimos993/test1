const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');

const VALID_SCRIPTS = ['pitone.py', 'decr.py'];

function runRemoteScript({ ip, username, password, script }, callback) {
    if (!VALID_SCRIPTS.includes(script)) {
        return callback(new Error('Script non autorizzato.'));
    }

    const scriptPath = path.join(__dirname, '..', '..', 'scripts', 'creds', script);
    if (!fs.existsSync(scriptPath)) {
        return callback(new Error('Script non trovato.'));
    }

    const remotePath = `/tmp/${script}`;
    const scpCmd = `sshpass -p '${password}' scp -o StrictHostKeyChecking=no "${scriptPath}" ${username}@${ip}:${remotePath}`;
    const sshCmd = `sshpass -p '${password}' ssh -o StrictHostKeyChecking=no ${username}@${ip} "python3 ${remotePath}"`;

    exec(scpCmd, (err) => {
        if (err) return callback(new Error('Errore durante la copia con SCP.'));
        exec(sshCmd, (error, stdout, stderr) => {
            if (error) return callback(new Error(stderr || 'Errore durante esecuzione remota.'));
            return callback(null, stdout);
        });
    });
}

module.exports = { runRemoteScript };