// core/services/scanOrchestrator.js
const { doTcpScan } = require('../scanner/tcpScanner');
const { doUdpScan } = require('../scanner/udpScanner');
const { performServiceDetection } = require('./serviceDetector');
const { performOSDetection } = require('./osDetector');
const { getTopPorts } = require('../../utils/portUtils');

/**
 * Esegue una scansione completa (OS, Service, Version) sulle porte TCP più comuni.
 * @param {string} host
 * @param {number} timing
 * @returns {Promise<object>}
 */
async function performComprehensiveScan(host, timing = 4) {
    const topPorts = getTopPorts(100);

    // 1. Scansione porte TCP
    const portScanResults = await doTcpScan(host, topPorts, timing);
    const openPorts = portScanResults.filter(r => r.status === 'open');

    const results = {
        portScan: portScanResults,
        serviceDetection: [],
        osDetection: {},
    };

    if (openPorts.length > 0) {
        // 2. Service/Version detection
        const serviceDetails = await performServiceDetection(host, openPorts); // Assicurati di passare host e openPorts
        results.serviceDetection = serviceDetails;
        // 3. OS detection (usa i serviceDetails per l'analisi del banner)
        results.osDetection = await performOSDetection(serviceDetails); //
    }

    return results;
}

/**
 * Esegue una scansione completa su tutte le porte specificate (fino a un limite).
 * @param {string} host
 * @param {number} maxPorts
 * @param {number} timing
 * @returns {Promise<object>}
 */
async function performFullPortScan(host, maxPorts = 1000, timing = 4) {
    const portRange = `1-${maxPorts}`;
    const tcpResults = await doTcpScan(host, portRange, timing);

    // Per un gold standard, qui si potrebbe aggiungere service/OS detection sui risultati open
    const openPorts = tcpResults.filter(r => r.status === 'open');
    let serviceDetails = [];
    let osDetection = {};
    if (openPorts.length > 0) {
       serviceDetails = await performServiceDetection(host, openPorts);
        osDetection = await performOSDetection(serviceDetails);
    }

    return {
        totalPortsScanned: tcpResults.length,
        openPortsCount: tcpResults.filter(r => r.status === 'open').length,
        results: tcpResults,
        // serviceDetails,
        // osDetection
    };
}


/**
 * Esegue una scansione TCP e UDP stealth-like.
 * @param {string} host
 * @param {string} portRange
 * @param {number} timing
 * @returns {Promise<object>}
 */
async function performStealthComprehensiveScan(host, portRange = '1-1000', timing = 4) {
    const commonUDPPorts = [53, 67, 68, 69, 123, 137, 138, 161, 5353]; //

    const [tcpResults, udpResults] = await Promise.all([
        doTcpScan(host, portRange, timing), //
        doUdpScan(host, commonUDPPorts, timing) //
    ]);

    const openTcpPorts = tcpResults.filter(r => r.status === 'open'); //
    let serviceDetails = [];
    let osDetection = {}; //
    if (openTcpPorts.length > 0) {
        serviceDetails = await performServiceDetection(host, openTcpPorts); //
        osDetection = await performOSDetection(serviceDetails); //
    }

    return {
        tcpResults,
        udpResults,
        serviceDetails,
        osDetection //
    };
}


module.exports = {
    performComprehensiveScan,
    performFullPortScan,
    performStealthComprehensiveScan, //
};