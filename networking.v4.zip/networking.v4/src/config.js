// src/config.js
require('dotenv').config();
const path = require('path');

module.exports = {
  server: {
    port: process.env.PORT || 3000,
    host: process.env.HOST || '0.0.0.0',
  },
  logging: {
    dir: path.resolve(__dirname, '../logs'),
    level: process.env.LOG_LEVEL || 'info',
    formats: ['json', 'csv'],
  },
  security: {
    allowedIPs: ['127.', '192.168.', '10.'], // Subnet private locali
    requireToken: true,
    authToken: process.env.AUTH_TOKEN || 'deimos-secure-token',
  },
  targets: {
    defaultTarget: process.env.DEFAULT_TARGET || '192.168.56.101',
    defaultPorts: [21, 22, 80, 443, 3306, 27017],
  },
};
