// src/modules/persist.js
const fs = require('fs');
const os = require('os');
const path = require('path');
const logger = require('../utils/logger');

async function run() {
  const platform = os.platform();
  try {
    const content = platform === 'win32'
      ? '@echo on\nstart "" "calc.exe"'
      : '#!/bin/sh\n# persistence script';
    const target = platform === 'win32'
      ? process.env.APPDATA + '\\persist.bat'
      : '/tmp/persist.sh';

    fs.writeFileSync(target, content, { mode: 0o755 });
    logger.info(`Persistenza creata: ${target}`);
    logger.json('persistence.json',{platform,target});
  } catch(e) {
    logger.error(`Persist error: ${e.message}`);
  }
}

module.exports = { run };
