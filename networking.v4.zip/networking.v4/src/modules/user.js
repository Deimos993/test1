// src/modules/users.js
const os = require('os');
const { execSync } = require('child_process');
const logger = require('../utils/logger');

async function run() {
  const platform = os.platform();
  const report = { users: [] };

  try {
    if (platform === 'win32') {
      const out = execSync('net user').toString();
      report.users = out.split('\n').filter(l=>l.includes('---')===false);
    } else {
      report.users = execSync('cat /etc/passwd').toString().split('\n');
    }
    logger.json('users.json', report);
    logger.info('Recupero utenti completato');
  } catch(e) {
    logger.error(`Users fallback error: ${e.message}`);
  }
}

module.exports = { run };
