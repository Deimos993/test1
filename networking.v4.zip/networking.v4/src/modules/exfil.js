// src/modules/exfil.js
const fs = require('fs');
const archiver = require('archiver');
const os = require('os');
const path = require('path');
const logger = require('../utils/logger');

async function run(_, logDir = path.resolve(__dirname,'../logs')) {
  const tmpFile = path.join(logDir,'archive.zip');
  const output = fs.createWriteStream(tmpFile);
  const archive = archiver('zip', { zlib: { level: 9 } });

  archive.pipe(output);
  archive.append(JSON.stringify({ host: os.hostname(), date: new Date() }), { name: 'info.json' });
  await archive.finalize();

  logger.info(`Exfil: archivio creato ${tmpFile}`);
  logger.json('exfil.json',{file: tmpFile, size: fs.statSync(tmpFile).size});
}

module.exports = { run };
