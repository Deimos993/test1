// src/modules/recon.js
const net = require('net');
const fs = require('fs');
const logger = require('../utils/logger');
const config = require('../config');

async function run(target, logDir = config.logging.dir) {
  const results = [];
  const ports = config.targets.defaultPorts;

  logger.info(`Recon: scan porte su ${target}`);

  await Promise.all(ports.map(port => new Promise(res => {
    const s = new net.Socket();
    let status = 'CLOSED';
    s.setTimeout(1500);
    s.on('connect', () => { status = 'OPEN'; s.destroy(); });
    s.on('timeout', () => s.destroy());
    s.on('error', () => {});
    s.on('close', () => {
      results.push([port, status]);
      res();
    });
    s.connect(port, target);
  })));

  logger.csv('recon.csv', ['Port','Status'], results);
  logger.info('Recon completata');
}

module.exports = { run };
