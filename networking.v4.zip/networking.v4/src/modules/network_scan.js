// src/modules/network_scan.js
const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const net = require('net');
const logger = require('../utils/logger');
const config = require('../config');

function getLocalIPv4() {
  const interfaces = os.networkInterfaces();
  for (const iface of Object.values(interfaces)) {
    for (const entry of iface) {
      if (entry.family === 'IPv4' && !entry.internal) return entry.address;
    }
  }
  return null;
}

function getSubnet(ip) {
  const parts = ip.split('.');
  return `${parts[0]}.${parts[1]}.${parts[2]}`;
}

async function run(_, logDir = config.logging.dir) {
  try {
    const ip = getLocalIPv4();
    if (!ip) {
      logger.error('IP locale non rilevato');
      return;
    }

    const subnet = getSubnet(ip);
    logger.info(`🌐 Avvio scansione subnet: ${subnet}.0/24`);

    // Inizializza progress
    const progressFile = path.join(logDir, 'scan_progress.json');
    fs.writeFileSync(progressFile, JSON.stringify({ done: 0, total: 254 }));

    logger.info(`🔍 Fase 1: Discovery host via PING + ARP + TCP SYN`);
    
    // Metodo 1: Ping tradizionale
    const pingHosts = await discoverViaping(subnet, logDir);
    logger.info(`📡 PING ha trovato ${pingHosts.length} host`);

    // Metodo 2: ARP scan (più affidabile in LAN)
    const arpHosts = await discoverViaARP(subnet);
    logger.info(`🔗 ARP ha trovato ${arpHosts.length} host`);

    // Metodo 3: TCP SYN scan su porte comuni (bypassa firewall ICMP)
    const tcpHosts = await discoverViaTCP(subnet);
    logger.info(`🚪 TCP SYN ha trovato ${tcpHosts.length} host`);

    // Combina tutti i risultati e rimuovi duplicati
    const allHosts = [...new Set([...pingHosts, ...arpHosts, ...tcpHosts])];
    logger.info(`🎯 TOTALE: ${allHosts.length} host unici scoperti`);

    // Salva host attivi
    fs.writeFileSync(path.join(logDir, 'open_hosts.json'), JSON.stringify(allHosts, null, 2));

    if (allHosts.length > 0) {
      logger.info(`🔍 Fase 2: Scansione porte dettagliata su ${allHosts.length} host`);
      await tcpScanParallel(allHosts, logDir);
    } else {
      logger.error('❌ NESSUN HOST TROVATO - Verifica rete/firewall');
      // Fallback: aggiungi almeno l'IP target per debug
      const fallbackHosts = [ip, config.targets.defaultTarget];
      logger.info(`🆘 Fallback: test su ${fallbackHosts.join(', ')}`);
      await tcpScanParallel(fallbackHosts, logDir);
    }
    
  } catch (error) {
    logger.error(`Errore durante network_scan: ${error.message}`);
    throw error;
  }
}

// Metodo 1: Ping Discovery (migliorato)
async function discoverViaping(subnet, logDir) {
  const activeHosts = [];
  const tasks = [];
  const progressFile = path.join(logDir, 'scan_progress.json');
  let pingDone = 0;

  logger.info('🏓 Avvio PING discovery...');

  for (let i = 1; i <= 254; i++) {
    const target = `${subnet}.${i}`;
    tasks.push(new Promise(resolve => {
      // Ping più aggressivo e dettagliato
      const pingCmd = process.platform === 'win32' 
        ? `ping -n 2 -w 2000 ${target}` 
        : `ping -c 2 -W 2 ${target}`;
        
      exec(pingCmd, { timeout: 5000 }, (err, stdout, stderr) => {
        let isAlive = false;
        
        if (process.platform === 'win32') {
          // Windows: cerca TTL= o "bytes="
          isAlive = stdout.includes('TTL=') || stdout.includes('bytes=');
        } else {
          // Linux/Mac: controlla statistiche
          isAlive = stdout.includes('1 received') || stdout.includes('2 received');
        }
        
        if (isAlive) {
          activeHosts.push(target);
          logger.info(`✅ PING: ${target} risponde`);
        }
        
        pingDone++;
        fs.writeFileSync(progressFile, JSON.stringify({ done: Math.floor(pingDone / 3), total: 254 }));
        resolve();
      });
    }));
  }

  await Promise.all(tasks);
  return activeHosts;
}

// Metodo 2: ARP Discovery (molto efficace in LAN)
async function discoverViaARP(subnet) {
  return new Promise(resolve => {
    const activeHosts = [];
    
    logger.info('🔗 Avvio ARP discovery...');
    
    const arpCmd = process.platform === 'win32' 
      ? 'arp -a' 
      : 'arp -a';
      
    exec(arpCmd, { timeout: 5000 }, (err, stdout) => {
      if (err) {
        logger.info('⚠️ ARP scan fallito, continuo...');
        resolve([]);
        return;
      }
      
      const lines = stdout.split('\n');
      lines.forEach(line => {
        // Cerca IP nel range subnet
        const match = line.match(/(\d+\.\d+\.\d+\.\d+)/);
        if (match && match[1].startsWith(subnet)) {
          const ip = match[1];
          if (!activeHosts.includes(ip)) {
            activeHosts.push(ip);
            logger.info(`✅ ARP: ${ip} in tabella`);
          }
        }
      });
      
      resolve(activeHosts);
    });
  });
}

// Metodo 3: TCP SYN Discovery (bypassa firewall ICMP)
async function discoverViaTCP(subnet) {
  const activeHosts = [];
  const commonPorts = [22, 80, 135, 139, 443, 445, 3389]; // Porte molto comuni
  const tasks = [];

  logger.info('🚪 Avvio TCP SYN discovery...');

  // Test solo alcuni IP campione per velocità (ogni 10)
  for (let i = 1; i <= 254; i += 5) {
    const target = `${subnet}.${i}`;
    
    for (const port of commonPorts) {
      tasks.push(new Promise(resolve => {
        const socket = net.createConnection({ host: target, port, timeout: 800 }, () => {
          if (!activeHosts.includes(target)) {
            activeHosts.push(target);
            logger.info(`✅ TCP: ${target}:${port} aperta`);
          }
          socket.destroy();
          resolve();
        });
        
        socket.on('error', resolve);
        socket.on('timeout', () => {
          socket.destroy();
          resolve();
        });
      }));
    }
  }

  await Promise.all(tasks);
  return activeHosts;
}
  const ports = config.targets.defaultPorts || [21, 22, 80, 135, 139, 443, 445, 3306, 3389, 5432, 27017];
  const results = [];
  const progressFile = path.join(logDir, 'scan_progress.json');

  const total = hosts.length * ports.length;
  let done = 0;

  logger.info(`🔍 Avvio scansione TCP su ${hosts.length} host, ${ports.length} porte (${total} test)`);

  const scanTasks = [];

  for (const host of hosts) {
    for (const port of ports) {
      scanTasks.push(new Promise(resolve => {
        const socket = net.createConnection({ host, port, timeout: 1000 }, () => {
          results.push({ host, port, status: 'OPEN' });
          logger.info(`🔓 ${host}:${port} OPEN`);
          socket.destroy();
        });

        socket.on('error', () => {
          results.push({ host, port, status: 'CLOSED' });
        });
        
        socket.on('timeout', () => {
          results.push({ host, port, status: 'CLOSED' });
          socket.destroy();
        });
        
        socket.on('close', () => {
          done++;
          // Aggiorna progresso ogni 10 scansioni per performance
          if (done % 10 === 0 || done === total) {
            fs.writeFileSync(progressFile, JSON.stringify({ done, total }));
          }
          resolve();
        });
      }));
    }
  }

  await Promise.all(scanTasks);

  // Salva risultati in CSV
  const csvHeaders = 'Host,Port,Status\n';
  const csvData = results.map(r => `${r.host},${r.port},${r.status}`).join('\n');
  fs.writeFileSync(path.join(logDir, 'active_ports.csv'), csvHeaders + csvData);

  // Crea mappa gerarchica per il frontend
  const grouped = {};
  results.forEach(({ host, port, status }) => {
    if (!grouped[host]) grouped[host] = [];
    grouped[host].push({ port, status });
  });

  fs.writeFileSync(path.join(logDir, 'network_map.json'), JSON.stringify(grouped, null, 2));
  
  const openPorts = results.filter(r => r.status === 'OPEN').length;
  logger.info(`🎯 Scansione completata: ${openPorts}/${total} porte aperte`);
}

// IMPORTANTE: Esporta la funzione run
module.exports = { run };