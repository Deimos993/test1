// src/modules/mongo.js
const net = require('net');
const logger = require('../utils/logger');

async function run(target, logDir) {
  return new Promise(resolve => {
    const socket = new net.Socket();
    const port = 27017;
    socket.setTimeout(3000);

    logger.info(`Mongo: test accesso a ${target}:${port}`);

    socket.connect(port, target, () => {
      socket.write(Buffer.from([0x3a,0x00,0,0,0,0,0,0]));
    });

    socket.on('data', data => {
      logger.json('mongo_access.json',{target,port,ok:true,len:data.length});
      socket.destroy();
    });
    socket.on('timeout', () => {
      logger.json('mongo_access.json',{target,port,ok:false,error:'timeout'});
      socket.destroy();
    });
    socket.on('error', err => {
      logger.json('mongo_access.json',{target,port,ok:false,error:err.message});
      resolve();
    });
    socket.on('close', () => {
      logger.info('Mongo test completato');
      resolve();
    });
  });
}

module.exports = { run };
