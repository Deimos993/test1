// src/server.js - Versione Rifattorizzata per networking.v3
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const http = require('http');
const WebSocket = require('ws');

const config = require('./config');
const logger = require('./utils/logger');
const { validateIP, authorizeRequest } = require('./utils/security');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// === Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));
app.use('/logs', express.static(path.join(__dirname, '../logs')));

// === API Routing
app.get('/api/health', (req, res) => res.json({ status: 'ok', version: 'v3.0.0' }));

app.post('/api/trigger', authorizeRequest, async (req, res) => {
  const { stage = 'recon', target = config.targets.defaultTarget } = req.body;

  if (!validateIP(target) && stage !== 'network_scan') {
    return res.status(403).json({ error: `IP non autorizzato: ${target}` });
  }

  try {
    const stagePath = path.join(__dirname, 'modules', `${stage}.js`);
    if (!fs.existsSync(stagePath)) {
      return res.status(404).json({ error: `Stage non trovato: ${stage}` });
    }

    const stageModule = require(stagePath);
    await stageModule.run(target, config.logging.dir);
    logger.info(`[+] Eseguito stage "${stage}" su ${target}`);
    res.json({ success: true });
  } catch (err) {
    logger.error(`[!] Errore stage ${stage}: ${err.message}`);
    res.status(500).json({ error: 'Errore interno durante esecuzione stage.' });
  }
});

// === WebSocket
wss.on('connection', ws => {
  ws.send(JSON.stringify({ type: 'info', msg: '🔌 WebSocket connesso' }));

  // Reinvio log eventi in tempo reale
  logger.on('event', data => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(data));
    }
  });
});

// === Avvio Server
server.listen(config.server.port, config.server.host, () => {
  console.log(`[🧠 DNST] Server attivo su http://${config.server.host}:${config.server.port}`);
});
