const services = {
    tcp: { 21: 'ftp', 22: 'ssh', 23: 'telnet', 25: 'smtp', 53: 'dns', 80: 'http', 110: 'pop3', 135: 'msrpc', 139: 'netbios-ssn', 143: 'imap', 443: 'https', 445: 'microsoft-ds', 993: 'imaps', 995: 'pop3s', 1433: 'mssql', 3306: 'mysql', 3389: 'rdp', 5432: 'postgresql', 5900: 'vnc', 6379: 'redis', 8080: 'http-proxy', 27017: 'mongodb' },
    udp: { 53: 'dns', 67: 'dhcp', 68: 'dhcp', 69: 'tftp', 123: 'ntp', 161: 'snmp', 162: 'snmp-trap', 514: 'syslog', 520: 'rip', 1434: 'mssql-m', 1900: 'upnp', 4500: 'ipsec', 5353: 'mdns' }
};

const topPortsList = [ 21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 995, 1723, 3389, 3306, 5432, 5900, 8080, 20, 69, 123, 161, 162, 389, 636, 514, 1433, 1521, 2049, 2121, 6379, 8443, 9200, 111, 113, 179, 199, 427, 465, 513, 543, 544, 548, 554, 587, 631, 646, 873, 990, 1025, 1026, 1027, 1028, 1029, 1110, 1720, 1755, 1900, 2000, 2001, 2717, 3000, 3128, 5000, 5009, 5051, 5060, 5101, 5190, 5357, 5631, 5666, 5800, 6000, 6001, 6646, 7070, 8000, 8008, 8009, 8081, 8888, 9100, 9999, 10000, 32768, 49152, 49153, 49154, 49155, 49156, 49157 ];

function getServiceName(port, protocol = 'tcp') {
    return services[protocol]?.[port] || 'unknown';
}

function getTopPorts(count = 100) {
    return topPortsList.slice(0, count);
}

module.exports = {
    getServiceName,
    getTopPorts,
};