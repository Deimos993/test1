/**
 * Converte input porte in array numerico
 * @param {string|Array|number} ports - Input porte (es: "80,443" o "1-100" o [80,443])
 * @returns {number[]} Array di numeri di porta
 */
function parsePorts(ports) {
    if (typeof ports === 'string') {
        if (ports.includes(',')) {
            return ports.split(',').map(p => parseInt(p.trim())).filter(p => !isNaN(p));
        } else if (ports.includes('-')) {
            const [start, end] = ports.split('-').map(Number);
            return Array.from({ length: end - start + 1 }, (_, i) => start + i);
        }
        return [parseInt(ports)].filter(p => !isNaN(p));
    } else if (Array.isArray(ports)) {
        return ports.map(p => parseInt(p)).filter(p => !isNaN(p));
    }
    return [];
}

module.exports = { parsePorts };