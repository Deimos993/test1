// src/utils/logger.js
const fs = require('fs');
const path = require('path');
const EventEmitter = require('events');
const config = require('../config');

class Logger extends EventEmitter {
  constructor() {
    super();
    this.logDir = config.logging.dir;
    fs.mkdirSync(this.logDir, { recursive: true });
  }

  _write(filename, line) {
    const filepath = path.join(this.logDir, filename);
    fs.appendFileSync(filepath, line + '\n');
  }

  info(msg) {
    const line = `[INFO] ${new Date().toISOString()} ${msg}`;
    this._write('events.log', line);
    this.emit('event', { type: 'info', msg });
  }

  error(msg) {
    const line = `[ERROR] ${new Date().toISOString()} ${msg}`;
    this._write('events.log', line);
    this.emit('event', { type: 'error', msg });
  }

  csv(filename, headers, rows) {
    const filepath = path.join(this.logDir, filename);
    if (!fs.existsSync(filepath)) {
      fs.writeFileSync(filepath, headers.join(',') + '\n');
    }
    const lines = rows.map(r => r.join(',')).join('\n');
    fs.appendFileSync(filepath, lines + '\n');
    this.emit('event', { type: 'csv', file: filename, rows });
  }

  json(filename, obj) {
    const filepath = path.join(this.logDir, filename);
    fs.writeFileSync(filepath, JSON.stringify(obj, null, 2));
    this.emit('event', { type: 'json', file: filename, data: obj });
  }
}

module.exports = new Logger();
