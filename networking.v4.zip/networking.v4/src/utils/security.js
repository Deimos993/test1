// src/utils/security.js
const config = require('../config');

// IP Filtering (solo IP locali)
function validateIP(ip) {
  return config.security.allowedIPs.some(prefix => ip.startsWith(prefix));
}

// Middleware per autenticazione con token
function authorizeRequest(req, res, next) {
  if (!config.security.requireToken) return next();
  const token = req.headers['x-auth-token'] || req.query.token;
  if (token === config.security.authToken) {
    return next();
  } else {
    return res.status(403).json({ error: 'Token non valido o mancante.' });
  }
}

module.exports = {
  validateIP,
  authorizeRequest,
};
