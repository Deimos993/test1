const express = require('express');
const router = express.Router();
const nmapController = require('../controllers/nmapController');

router.post('/syn-scan', nmapController.synScan);
router.post('/comprehensive-scan', nmapController.comprehensiveScan);
router.post('/full-port-scan', nmapController.fullPortScan);

module.exports = router;