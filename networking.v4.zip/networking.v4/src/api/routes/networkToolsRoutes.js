// networkToolsRoutes.js
const express = require('express');
const router = express.Router();
const networkToolsController = require('../controllers/networkToolsController');
const networkValidator = require('../middleware/networkValidator'); // Importa il middleware

// Rimuovere questa riga, network-info è gestito da networkRoutes.js
// router.get('/network-info', networkToolsController.getNetworkInfo); //

router.post('/ping-sweep', networkValidator, networkToolsController.pingSweep); // Applica il validator
router.post('/traceroute', networkToolsController.traceroute);
router.post('/dns-enum', networkToolsController.dnsEnum);
router.post('/network-map', networkValidator, networkToolsController.networkMap); // Applica il validator
router.post('/scan-port', networkToolsController.singlePortScan);


module.exports = router;