// src/api/routes/sqlRoutes.js
const express = require('express');
const router = express.Router();

// Endpoint base di test
router.get('/ping', (req, res) => {
  res.json({ message: 'SQL route attiva!' });
});

// Esegui test di SQLi
router.post('/scan', async (req, res) => {
  const { targetUrl, method, payloads } = req.body;
  if (!targetUrl || !payloads) {
    return res.status(400).json({ error: 'Parametri mancanti' });
  }

  // Simulazione risposta
  res.json({
    message: 'SQL Injection scan eseguito',
    targetUrl,
    method,
    payloadsTestati: payloads.length
  });
});

module.exports = router;
