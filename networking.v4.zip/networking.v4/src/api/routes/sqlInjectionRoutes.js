// src/api/routes/sqlInjectionRoutes.js
const express = require('express');
const router = express.Router();
const controller = require('../controllers/sqlInjectionController');
const validator = require('../middleware/networkValidator');

// POST /api/v1/sql/scan
router.post('/scan', 
  validator.validateUrl,
  controller.scan
);

// GET /api/v1/sql/status/:scanId
router.get('/status/:scanId',
  controller.getScanStatus
);

// POST /api/v1/sql/cancel/:scanId
router.post('/cancel/:scanId',
  controller.cancelScan
);

// POST /api/v1/sql/toggle-safemode
router.post('/toggle-safemode',
  controller.toggleSafeMode
);

module.exports = router;