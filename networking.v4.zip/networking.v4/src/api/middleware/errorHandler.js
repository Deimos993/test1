/**
 * Middleware di gestione degli errori centralizzato.
 * Cattura tutti gli errori passati tramite next(error).
 * @param {Error} err - L'oggetto errore.
 * @param {import('express').Request} req - L'oggetto richiesta di Express.
 * @param {import('express').Response} res - L'oggetto risposta di Express.
 * @param {import('express').NextFunction} next - La funzione per passare al middleware successivo.
 */
function errorHandler(err, req, res, next) {
    console.error("ERRORE NON GESTITO:", err);

    const statusCode = err.statusCode || 500;
    const message = err.message || 'Errore Interno del Server';

    res.status(statusCode).json({
        error: message,
        stack: process.env.NODE_ENV === 'development' ? err.stack : undefined,
    });
}

module.exports = errorHandler;