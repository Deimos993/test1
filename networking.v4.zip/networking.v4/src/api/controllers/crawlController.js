const WebCrawler = require('../../core/services/webCrawler');
const { validateUrl } = require('../../utils/validators');

async function crawlWebsite(req, res) {
    try {
        const { url, depth = 2 } = req.body;
        
        if (!validateUrl(url)) {
            return res.status(400).json({ error: 'URL non valida' });
        }

        const crawler = new WebCrawler(depth);
        const results = await crawler.crawl(url);
        
        res.json({
            scannedUrl: url,
            totalPages: results.pages.length,
            uniqueDomains: [...new Set(results.pages.map(p => new URL(p.url).hostname))].length,
            results
        });
    } catch (error) {
        console.error(`[Crawler] Error: ${error.message}`);
        res.status(500).json({ error: 'Errore durante il crawling' });
    }
}

module.exports = { crawlWebsite };