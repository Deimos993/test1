// middleware/rateLimiter.js
const rateLimit = require('express-rate-limit');
const RedisStore = require('rate-limit-redis');
const Redis = require('ioredis');

const redisClient = new Redis({
    host: process.env.REDIS_HOST || 'localhost',
    port: process.env.REDIS_PORT || 6379,
});

let isRateLimitEnabled = true; // Stato controllabile dinamicamente

const dynamicRateLimiter = rateLimit({
    store: new RedisStore({
        sendCommand: (...args) => redisClient.call(...args),
    }),
    windowMs: 15 * 60 * 1000,
    max: 100,
    message: 'Limite di richieste superato. Riprova più tardi.',
    skip: () => !isRateLimitEnabled,
});

const setRateLimitStatus = (enabled) => {
    isRateLimitEnabled = enabled;
};

const getRateLimitStatus = () => isRateLimitEnabled;

module.exports = {
    dynamicRateLimiter,
    setRateLimitStatus,
    getRateLimitStatus
};
