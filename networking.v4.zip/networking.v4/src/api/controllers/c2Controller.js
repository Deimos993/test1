const fs = require('fs');
const path = require('path');

// Salva ogni beacon in un file separato
function handleBeacon(req, res) {
    const beacon = req.body;

    if (!beacon || Object.keys(beacon).length === 0) {
        return res.status(400).json({ success: false, error: 'Beacon vuoto' });
    }

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const sessionId = `${beacon.hostname || 'unknown'}-${timestamp}`;

    const logsDir = path.join(__dirname, '../../../logs/beacons');  // ✅ Definito qui
    const savePath = path.join(logsDir, `${sessionId}.json`);

    // Crea la directory se non esiste
    if (!fs.existsSync(logsDir)) {
        fs.mkdirSync(logsDir, { recursive: true });
    }

    fs.writeFile(savePath, JSON.stringify(beacon, null, 2), (err) => {
        if (err) {
            console.error('Errore salvataggio beacon:', err);
            return res.status(500).json({ success: false, error: 'Errore salvataggio beacon' });
        }

        console.log(`[+] Nuovo beacon ricevuto da ${sessionId}`);
        res.json({ success: true, message: 'Beacon ricevuto' });
    });
}

module.exports = { handleBeacon };
