// src/core/websocket/WebSocketManager.js
const { v4: uuidv4 } = require('uuid');
const WebSocket = require('ws');

class WebSocketManager {
  constructor(wss, logger) {
    this.wss = wss;
    this.logger = logger;
    this.clients = new Map();
    this.activeSessions = new Map();
    
    this.setupWebSocketServer();
  }

  setupWebSocketServer() {
    this.wss.on('connection', (ws, req) => {
      this.handleNewConnection(ws, req);
    });
    
    this.logger.info('WebSocket Manager initialized', {
      port: this.wss.options.port
    });
  }

  handleNewConnection(ws, req) {
    const clientId = uuidv4();
    const clientIp = this.getClientIp(req);
    
    // Configurazione client
    ws.id = clientId;
    ws.ip = clientIp;
    ws.isAlive = true;
    ws.connectedAt = new Date();
    
    // Aggiungi alla mappa dei client
    this.clients.set(clientId, {
      ws,
      ip: clientIp,
      connectedAt: ws.connectedAt,
      lastActivity: new Date(),
      messageCount: 0
    });
    
    this.logger.info('WebSocket client connected', { 
      clientId, 
      clientIp,
      totalClients: this.clients.size
    });
    
    // Setup handlers
    this.setupClientHandlers(ws, clientId);
    
    // Invia messaggio di benvenuto
    this.sendToClient(clientId, {
      type: 'connection_established',
      clientId,
      serverTime: new Date().toISOString(),
      features: ['ssh_bruteforce', 'network_mapping', 'sql_injection']
    });
  }

  setupClientHandlers(ws, clientId) {
    // Gestore messaggi
    ws.on('message', async (data) => {
      try {
        await this.handleMessage(clientId, data);
      } catch (error) {
        this.logger.error('Message handling error', {
          clientId,
          error: error.message,
          stack: error.stack
        });
        
        this.sendToClient(clientId, {
          type: 'error',
          message: 'Errore interno del server',
          code: 'INTERNAL_ERROR'
        });
      }
    });
    
    // Gestore pong (heartbeat)
    ws.on('pong', () => {
      ws.isAlive = true;
      this.updateClientActivity(clientId);
    });
    
    // Gestore chiusura
    ws.on('close', (code, reason) => {
      this.handleClientDisconnection(clientId, code, reason);
    });
    
    // Gestore errori
    ws.on('error', (error) => {
      this.logger.error('WebSocket client error', {
        clientId,
        error: error.message
      });
    });
  }

  async handleMessage(clientId, data) {
    const client = this.clients.get(clientId);
    if (!client) {
      this.logger.warn('Message from unknown client', { clientId });
      return;
    }
    
    // Aggiorna attività client
    this.updateClientActivity(clientId);
    
    let message;
    try {
      message = JSON.parse(data.toString());
    } catch (error) {
      this.sendToClient(clientId, {
        type: 'error',
        message: 'Formato messaggio non valido',
        code: 'INVALID_JSON'
      });
      return;
    }
    
    // Validazione messaggio base
    if (!message.type) {
      this.sendToClient(clientId, {
        type: 'error',
        message: 'Tipo messaggio mancante',
        code: 'MISSING_TYPE'
      });
      return;
    }
    
    this.logger.debug('Processing WebSocket message', {
      clientId,
      messageType: message.type,
      hasPayload: !!message.payload
    });
    
    // Router messaggi
    await this.routeMessage(clientId, message);
  }

  async routeMessage(clientId, message) {
    const client = this.clients.get(clientId);
    
    // Rate limiting per tipo di messaggio
    if (this.isRateLimited(clientId, message.type)) {
      this.sendToClient(clientId, {
        type: 'error',
        message: 'Troppe richieste. Rallenta.',
        code: 'RATE_LIMITED'
      });
      return;
    }
    
    try {
      switch (message.type) {
        case 'ping':
          this.handlePing(clientId);
          break;
          
        case 'start_ssh_attack':
          await this.handleSshAttack(clientId, message);
          break;
          
        case 'stop_ssh_attack':
          await this.handleStopSshAttack(clientId);
          break;
          
        case 'start_network_scan':
          await this.handleNetworkScan(clientId, message);
          break;
          
        case 'start_sql_scan':
          await this.handleSqlScan(clientId, message);
          break;
          
        case 'execute_sql':
          await this.handleSqlExecution(clientId, message);
          break;
          
        case 'analyze_sql':
          await this.handleSqlAnalysis(clientId, message);
          break;
          
        case 'toggle_sql_safemode':
          await this.handleSqlSafeModeToggle(clientId);
          break;
          
        default:
          this.sendToClient(clientId, {
            type: 'error',
            message: `Tipo messaggio sconosciuto: ${message.type}`,
            code: 'UNKNOWN_MESSAGE_TYPE'
          });
      }
    } catch (error) {
      this.logger.error('Message routing error', {
        clientId,
        messageType: message.type,
        error: error.message
      });
      
      this.sendToClient(clientId, {
        type: 'error',
        message: 'Errore durante l\'elaborazione',
        code: 'PROCESSING_ERROR'
      });
    }
  }

  // Handlers specifici
  handlePing(clientId) {
    this.sendToClient(clientId, {
      type: 'pong',
      timestamp: new Date().toISOString()
    });
  }

  async handleSshAttack(clientId, message) {
    const { startSshAttackSession } = require('../services/sshBruteForceService');
    const { SSHAuditLogger } = require('../services/sshBruteForceService');
    
    // Verifica se c'è già una sessione attiva
    if (this.activeSessions.has(clientId)) {
      this.sendToClient(clientId, {
        type: 'error',
        message: 'Una sessione SSH è già attiva',
        code: 'SESSION_ALREADY_ACTIVE'
      });
      return;
    }
    
    const client = this.clients.get(clientId);
    const sshLogger = new SSHAuditLogger();
    
    try {
      const session = startSshAttackSession(client.ws, message, sshLogger);
      this.activeSessions.set(clientId, {
        type: 'ssh_attack',
        session,
        startedAt: new Date()
      });
      
      this.logger.info('SSH attack session started', { clientId });
      
    } catch (error) {
      this.sendToClient(clientId, {
        type: 'error',
        message: 'Errore avvio sessione SSH',
        code: 'SSH_START_ERROR'
      });
    }
  }

  async handleStopSshAttack(clientId) {
    const activeSession = this.activeSessions.get(clientId);
    
    if (!activeSession || activeSession.type !== 'ssh_attack') {
      this.sendToClient(clientId, {
        type: 'error',
        message: 'Nessuna sessione SSH attiva',
        code: 'NO_ACTIVE_SESSION'
      });
      return;
    }
    
    if (activeSession.session && activeSession.session.stop) {
      activeSession.session.stop();
    }
    
    this.activeSessions.delete(clientId);
    this.logger.info('SSH attack session stopped', { clientId });
    
    this.sendToClient(clientId, {
      type: 'ssh_attack_stopped',
      timestamp: new Date().toISOString()
    });
  }

  async handleNetworkScan(clientId, message) {
    const { performAdvancedNetworkMapping } = require('../services/networkMapperService');
    
    const progressCallback = (progressData) => {
      this.sendToClient(clientId, {
        type: 'network_scan_progress',
        ...progressData
      });
    };
    
    try {
      const results = await performAdvancedNetworkMapping(
        message.network, 
        message.options, 
        progressCallback
      );
      
      this.sendToClient(clientId, {
        type: 'network_scan_complete',
        data: results,
        timestamp: new Date().toISOString()
      });
      
    } catch (error) {
      this.sendToClient(clientId, {
        type: 'network_scan_error',
        message: error.message,
        code: 'NETWORK_SCAN_ERROR'
      });
    }
  }

  async handleSqlScan(clientId, message) {
    const sqlInjectionService = require('../services/sqlInjectionService');
    
    try {
      const scan = await sqlInjectionService.scan(message.url, {
        scanType: message.scanType,
        safeMode: message.safeMode
      });
      
      this.sendToClient(clientId, {
        type: 'sql_scan_complete',
        data: scan,
        timestamp: new Date().toISOString()
      });
      
    } catch (error) {
      this.sendToClient(clientId, {
        type: 'sql_scan_error',
        message: error.message,
        code: 'SQL_SCAN_ERROR'
      });
    }
  }

  async handleSqlExecution(clientId, message) {
    const sqlInjectionService = require('../services/sqlInjectionService');
    
    try {
      const result = await sqlInjectionService.executeQuery(
        message.query, 
        message.safeMode
      );
      
      this.sendToClient(clientId, {
        type: 'sql_execution_result',
        data: result,
        timestamp: new Date().toISOString()
      });
      
    } catch (error) {
      this.sendToClient(clientId, {
        type: 'sql_execution_error',
        message: error.message,
        code: 'SQL_EXECUTION_ERROR'
      });
    }
  }

  async handleSqlAnalysis(clientId, message) {
    const sqlInjectionService = require('../services/sqlInjectionService');
    
    try {
      const analysis = sqlInjectionService.analyzeQuery(message.query);
      
      this.sendToClient(clientId, {
        type: 'sql_analysis_result',
        data: analysis,
        timestamp: new Date().toISOString()
      });
      
    } catch (error) {
      this.sendToClient(clientId, {
        type: 'sql_analysis_error',
        message: error.message,
        code: 'SQL_ANALYSIS_ERROR'
      });
    }
  }

  async handleSqlSafeModeToggle(clientId) {
    const sqlInjectionService = require('../services/sqlInjectionService');
    
    try {
      const newMode = sqlInjectionService.toggleSafeMode();
      
      this.sendToClient(clientId, {
        type: 'sql_safemode_toggled',
        safeMode: newMode,
        timestamp: new Date().toISOString()
      });
      
    } catch (error) {
      this.sendToClient(clientId, {
        type: 'sql_safemode_error',
        message: error.message,
        code: 'SQL_SAFEMODE_ERROR'
      });
    }
  }

  // Utility methods
  sendToClient(clientId, message) {
    const client = this.clients.get(clientId);
    if (!client || client.ws.readyState !== WebSocket.OPEN) {
      return false;
    }
    
    try {
      client.ws.send(JSON.stringify(message));
      return true;
    } catch (error) {
      this.logger.error('Failed to send message to client', {
        clientId,
        error: error.message
      });
      return false;
    }
  }

  broadcast(message, excludeClientId = null) {
    let successCount = 0;
    
    this.clients.forEach((client, clientId) => {
      if (clientId !== excludeClientId) {
        if (this.sendToClient(clientId, message)) {
          successCount++;
        }
      }
    });
    
    return successCount;
  }

  updateClientActivity(clientId) {
    const client = this.clients.get(clientId);
    if (client) {
      client.lastActivity = new Date();
      client.messageCount++;
    }
  }

  isRateLimited(clientId, messageType) {
    const client = this.clients.get(clientId);
    if (!client) return true;
    
    // Rate limiting semplice basato su conteggio messaggi
    const now = Date.now();
    const windowMs = 60000; // 1 minuto
    const maxMessages = messageType.includes('scan') || messageType.includes('attack') ? 5 : 30;
    
    if (!client.rateLimitWindow || now - client.rateLimitWindow.start > windowMs) {
      client.rateLimitWindow = {
        start: now,
        count: 1
      };
      return false;
    }
    
    client.rateLimitWindow.count++;
    return client.rateLimitWindow.count > maxMessages;
  }

  handleClientDisconnection(clientId, code, reason) {
    const client = this.clients.get(clientId);
    if (!client) return;
    
    this.logger.info('WebSocket client disconnected', {
      clientId,
      ip: client.ip,
      code,
      reason: reason.toString(),
      duration: Date.now() - client.connectedAt.getTime(),
      messageCount: client.messageCount,
      totalClients: this.clients.size - 1
    });
    
    // Ferma sessioni attive
    const activeSession = this.activeSessions.get(clientId);
    if (activeSession && activeSession.session && activeSession.session.stop) {
      activeSession.session.stop();
    }
    
    // Rimuovi dalle mappe
    this.clients.delete(clientId);
    this.activeSessions.delete(clientId);
  }

  getClientIp(req) {
    return req.headers['x-forwarded-for']?.split(',')[0] || 
           req.connection.remoteAddress || 
           req.socket.remoteAddress ||
           'unknown';
  }

  // Metodi per monitoraggio
  getStats() {
    return {
      totalClients: this.clients.size,
      activeSessions: this.activeSessions.size,
      uptime: process.uptime(),
      memoryUsage: process.memoryUsage()
    };
  }

  getClientList() {
    const clients = [];
    this.clients.forEach((client, clientId) => {
      clients.push({
        id: clientId,
        ip: client.ip,
        connectedAt: client.connectedAt,
        lastActivity: client.lastActivity,
        messageCount: client.messageCount,
        hasActiveSession: this.activeSessions.has(clientId)
      });
    });
    return clients;
  }
}

module.exports = WebSocketManager;