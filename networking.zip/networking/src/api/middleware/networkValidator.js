function validateNetworkBase(network) {
    // Verifica formato 192.168.1
    const parts = network.split('.');
    if (parts.length !== 3) return false;
    
    return parts.every(part => {
        const num = parseInt(part, 10);
        return !isNaN(num) && num >= 0 && num <= 255;
    });
}

module.exports = (req, res, next) => {
    if (req.body.network && !validateNetworkBase(req.body.network)) {
        return res.status(400).json({ error: 'Formato network base non valido' });
    }
    next();
};