const express = require('express');
const router = express.Router();
const { runRemoteScript } = require('../../core/services/remoteExecService');

router.post('/run-script', (req, res) => {
    const { ip, username, password, script } = req.body;
    runRemoteScript({ ip, username, password, script }, (err, output) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ output });
    });
});

module.exports = router;