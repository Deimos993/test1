document.addEventListener('DOMContentLoaded', () => {
    const App = {
        config: { 
            apiBaseUrl: 'http://localhost:3000/api/v1', 
            wsUrl: 'ws://localhost:3001' 
        },
        state: { 
            isScanning: false, 
            ws: null, 
            scanStartTime: 0, 
            isSshAttacking: false,
            currentSqlScanId: null,
            sqlScanInterval: null
        },
        elements: {
            statusIndicator: document.getElementById('status-indicator'),
            currentTime: document.getElementById('current-time'),
            tabButtons: document.querySelectorAll('.tab-button'),
            tabContents: document.querySelectorAll('.tab-content'),
            mainLogConsole: document.getElementById('log-console'),
            mainClearLogBtn: document.getElementById('clear-log-btn'),
            mainConsoleContainer: document.getElementById('main-output-console-container'),
            scanType: document.getElementById('scan-type'),
            targetIp: document.getElementById('target-ip'),
            ports: document.getElementById('ports'),
            startScanBtn: document.getElementById('start-scan-btn'),
            scanBtnText: document.getElementById('scan-btn-text'),
            scanBtnIcon: document.getElementById('scan-btn-icon'),
            networkRange: document.getElementById('network-range'),
            wifiBtn: document.getElementById('wifi-btn'),
            networkMapBtn: document.getElementById('network-map-btn'),
            networkMapText: document.getElementById('network-map-text'),
            networkMapIcon: document.getElementById('network-map-icon'),
            vulnScanCheckbox: document.getElementById('vuln-scan-checkbox'),
            localNetworkInfo: document.getElementById('local-network-info'),
            progressContainer: document.getElementById('progress-container'),
            progressLabel: document.getElementById('progress-label'),
            progressBar: document.getElementById('progress-bar'),
            progressPercentage: document.getElementById('progress-percentage'),
            etrLabel: document.getElementById('etr-label'),
            tracerouteHost: document.getElementById('traceroute-host'),
            tracerouteBtn: document.getElementById('traceroute-btn'),
            dnsDomain: document.getElementById('dns-domain'),
            dnsEnumBtn: document.getElementById('dns-enum-btn'),
            pingSweepNetwork: document.getElementById('ping-sweep-network'),
            pingSweepBtn: document.getElementById('ping-sweep-btn'),
            singleScanHost: document.getElementById('single-scan-host'),
            singleScanPort: document.getElementById('single-scan-port'),
            singleScanBtn: document.getElementById('single-scan-btn'),
            sshTab: document.getElementById('ssh-bruteforce-tab'),
            sshTargetHost: document.getElementById('ssh-target-host'),
            sshTargetPort: document.getElementById('ssh-target-port'),
            sshTargetUser: document.getElementById('ssh-target-user'),
            sshPasswordList: document.getElementById('ssh-password-list'),
            sshFileUpload: document.getElementById('ssh-file-upload'),
            sshStartAttackBtn: document.getElementById('ssh-start-attack-btn'),
            sshAttackBtnText: document.getElementById('ssh-attack-btn-text'),
            sshAttackBtnIcon: document.getElementById('ssh-start-attack-btn').querySelector('span'),
            sshProgressBar: document.getElementById('ssh-progress-bar'),
            sshProgressContainer: document.getElementById('ssh-progress-container'),
            sshProgressText: document.getElementById('ssh-progress-text'),
            sshLogConsole: document.getElementById('ssh-log-console'),
            sshClearLogBtn: document.getElementById('ssh-clear-log-btn'),
            sqlTab: document.getElementById('sql-injection-tab'),
            sqlTargetUrl: document.getElementById('sql-target-url'),
            sqlScanType: document.getElementById('sql-scan-type'),
            sqlSafeMode: document.getElementById('sql-safe-mode'),
            sqlStartScanBtn: document.getElementById('start-sql-scan'),
            sqlStopScanBtn: document.getElementById('stop-sql-scan'),
            sqlScanIcon: document.getElementById('sql-scan-icon'),
            sqlScanText: document.getElementById('sql-scan-text'),
            sqlProgressContainer: document.getElementById('sql-progress-container'),
            sqlProgressBar: document.getElementById('sql-progress-bar'),
            sqlProgressPercentage: document.getElementById('sql-progress-percentage'),
            sqlScanStats: document.getElementById('sql-scan-stats'),
            sqlTestsCount: document.getElementById('sql-tests-count'),
            sqlResultsContent: document.getElementById('sql-results-content'),
            sqlClearResultsBtn: document.getElementById('sql-clear-results'),
            sqlVulnCount: document.getElementById('sql-vuln-count')
        },

        init() {
            this.setupEventListeners();
            this.connectWebSocket();
            this.updateTime();
            setInterval(() => this.updateTime(), 1000);
            this.appendToLog(this.elements.mainLogConsole, '🛡️ Deimos Lab v5.0 - Console Inizializzata', 'info');
            this.getInitialNetworkInfo();
            this.elements.sshPasswordList.value = "admin\nroot\npassword\n123456\ntest";
            this.toggleMainConsoleVisibility(); 
        },

        setupEventListeners() {
            // Tab switching
            this.elements.tabButtons.forEach(b => b.addEventListener('click', () => { 
                this.handleTabSwitch(b.dataset.tab); 
                this.toggleMainConsoleVisibility(); 
            }));

            // Main console
            this.elements.mainClearLogBtn.addEventListener('click', () => { 
                this.elements.mainLogConsole.innerHTML = ''; 
            });

            // Port scanning
            this.elements.startScanBtn.addEventListener('click', () => this.dispatchScan());
            this.elements.networkMapBtn.addEventListener('click', () => this.executeNetworkMap());
            this.elements.wifiBtn.addEventListener('click', () => this.setTargetToWiFi());

            // Network tools
            this.elements.tracerouteBtn.addEventListener('click', () => this.executeTraceroute());
            this.elements.dnsEnumBtn.addEventListener('click', () => this.executeDnsEnum());
            this.elements.pingSweepBtn.addEventListener('click', () => this.executePingSweep());
            this.elements.singleScanBtn.addEventListener('click', () => this.executeSinglePortScan());

            // SSH brute force
            this.elements.sshFileUpload.addEventListener('change', (e) => { 
                const f = e.target.files[0]; 
                if(f) { 
                    const r = new FileReader(); 
                    r.onload = (ev) => this.elements.sshPasswordList.value = ev.target.result; 
                    r.readAsText(f); 
                } 
            });
            this.elements.sshClearLogBtn.addEventListener('click', () => { 
                this.elements.sshLogConsole.innerHTML = ''; 
            });
            this.elements.sshStartAttackBtn.addEventListener('click', () => this.executeSshAttack());
            
            // SQL Injection listeners
            this.elements.sqlStartScanBtn.addEventListener('click', () => this.executeSqlScan());
            this.elements.sqlStopScanBtn.addEventListener('click', () => this.cancelSqlScan());
            this.elements.sqlClearResultsBtn.addEventListener('click', () => {
                this.elements.sqlResultsContent.innerHTML = '<p class="text-gray-400">Scan results will appear here...</p>';
                this.elements.sqlVulnCount.classList.add('hidden');
            });
            
            // Host card selection
            document.body.addEventListener('click', e => { 
                const card = e.target.closest('.host-card'); 
                if (card && card.dataset.ip) this.setTargetIp(card.dataset.ip); 
            });
        },

        connectWebSocket() {
            this.state.ws = new WebSocket(this.config.wsUrl);
            this.state.ws.onopen = () => {
                this.elements.statusIndicator.textContent = '✅ Backend Connesso';
                this.elements.statusIndicator.className = 'text-sm text-green-400';
                this.elements.sshStartAttackBtn.disabled = false;
                this.elements.sshAttackBtnText.textContent = 'Avvia Attacco';
                this.appendToLog(this.elements.mainLogConsole, '🔌 Connesso al server Real-time.', 'success');
            };
            this.state.ws.onmessage = (event) => this.handleWebSocketMessage(JSON.parse(event.data));
            this.state.ws.onclose = () => {
                this.elements.statusIndicator.textContent = '🔴 Backend Disconnesso';
                this.elements.statusIndicator.className = 'text-sm text-red-400';
                this.elements.sshStartAttackBtn.disabled = true;
                this.elements.sshAttackBtnText.textContent = 'Connetti al Backend';
                setTimeout(() => this.connectWebSocket(), 5000);
            };
        },

        handleWebSocketMessage(message) {
            switch(message.type) {
                case 'network_map_progress': 
                    this.updateScanProgress(message); 
                    break;
                case 'network_map_result': 
                    this.handleNetworkMapResult(message); 
                    break;
                case 'log': 
                    this.appendToLog(this.elements.sshLogConsole, message.message, message.level); 
                    break;
                case 'progress': 
                    this.updateSshProgress(message.current, message.total); 
                    break;
                case 'found': 
                    this.handleSshPasswordFound(message); 
                    break;
                case 'finished': 
                    this.handleSshAttackFinished(); 
                    break;
                case 'sql_scan_progress':
                    this.updateSqlScanProgress(message.data);
                    break;
                case 'sql_scan_result':
                    this.handleSqlScanResult(message.data);
                    break;
                case 'sql_scan_error':
                    this.handleSqlScanError(message);
                    break;
            }
        },
        
        appendToLog(consoleEl, message, type = 'info', data = null) {
            const now = new Date();
            const timestamp = `${now.getHours().toString().padStart(2,'0')}:${now.getMinutes().toString().padStart(2,'0')}:${now.getSeconds().toString().padStart(2,'0')}`;
            const logTypes = { 
                info: {c:'text-gray-400',i:'ℹ️'}, 
                success: {c:'text-green-400',i:'✅'}, 
                error: {c:'text-red-400',i:'❌'}, 
                scan: {c:'text-blue-400',i:'🔍'}, 
                result: {c:'text-purple-300',i:'📊'}, 
                vuln: {c:'text-red-300 animate-pulse',i:'🚨'}, 
                attack: {c:'text-orange-400',i:'⚡'}, 
                warning: {c:'text-yellow-400',i:'⚠️'}, 
                sql: {c:'text-amber-400',i:'💉'} 
            };
            const logType = logTypes[type] || logTypes.info;
            const logEntry = document.createElement('div');
            logEntry.className = `mb-1 flex items-start ${logType.c}`;
            const msgSpan = document.createElement('span');
            msgSpan.textContent = `[${timestamp}] ${message}`;
            logEntry.innerHTML = `<span class="mr-2">${logType.i}</span>`;
            logEntry.appendChild(msgSpan);
            if(data){ 
                const pre = document.createElement('pre');
                pre.className = 'console text-xs bg-black/30 p-3 rounded-lg mt-2 ml-8';
                pre.textContent = JSON.stringify(data, null, 2);
                logEntry.appendChild(pre);
            }
            consoleEl.appendChild(logEntry);
            consoleEl.scrollTop = consoleEl.scrollHeight;
        },

        handleTabSwitch(tabId) {
            this.elements.tabContents.forEach(c => c.classList.add('hidden'));
            this.elements.tabButtons.forEach(b => b.classList.remove('active'));
            document.getElementById(`${tabId}-tab`).classList.remove('hidden');
            document.querySelector(`[data-tab="${tabId}"]`).classList.add('active');
        },
        
        toggleMainConsoleVisibility() {
            const sshTabActive = !this.elements.sshTab.classList.contains('hidden');
            const sqlTabActive = !this.elements.sqlTab.classList.contains('hidden');
            // Corretto: usa display 'flex' invece di 'block' per mantenere il layout originale
            this.elements.mainConsoleContainer.style.display = (sshTabActive || sqlTabActive) ? 'none' : 'flex';
        },
        
        setLoading(btn, textEl, iconEl, isLoading, originalText, originalIcon = '🚀') {
            btn.disabled = isLoading;
            if (isLoading) {
                textEl.textContent = 'In Corso...';
                iconEl.innerHTML = `<svg class="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>`;
            } else { 
                textEl.textContent = originalText; 
                iconEl.innerHTML = originalIcon; 
            }
        },
        
        async apiCall(endpoint, options = {}) {
            try {
                const response = await fetch(`${this.config.apiBaseUrl}${endpoint}`, options);
                if (!response.ok) { 
                    const errData = await response.json(); 
                    throw new Error(errData.error || `Errore ${response.status}`); 
                }
                return await response.json();
            } catch (error) { 
                this.appendToLog(this.elements.mainLogConsole, `Errore API: ${error.message}`, 'error'); 
                return null; 
            }
        },
        
        updateTime() { 
            this.elements.currentTime.textContent = new Date().toLocaleTimeString('it-IT'); 
        },
        
        setTargetIp(ip) { 
            this.elements.targetIp.value = ip; 
            this.appendToLog(this.elements.mainLogConsole, `🎯 Host target impostato su ${ip}.`, 'info'); 
            this.handleTabSwitch('port-scan'); 
        },

        createCardsContainer() {
            const existing = document.getElementById('host-cards-container');
            if (existing) return existing;
            const container = document.createElement('div');
            container.id = 'host-cards-container';
            container.className = 'mt-2 flex flex-wrap max-h-60 overflow-y-auto p-2 bg-black/10 rounded';
            const logHeader = document.createElement('div');
            logHeader.className = 'w-full mb-2 text-purple-300';
            logHeader.innerHTML = '📊 Host Rilevati:';
            this.elements.mainLogConsole.appendChild(logHeader);
            this.elements.mainLogConsole.appendChild(container);
            return container;
        },

        createHostCard(host) {
            const osGuess = host.osDetection?.possible?.map(o => o.os).join('/') || 'Unknown';
            const servicesText = host.services?.map(s => `${s.port}:${s.service}`).join(', ') || 'Nessun servizio rilevato';
            const hasVulnerabilities = host.vulnerabilities && host.vulnerabilities.length > 0;
            const card = document.createElement('div');
            card.className = 'host-card inline-block bg-black/20 p-3 rounded-lg border-2 mr-2 mb-2 w-48 align-top';
            card.dataset.ip = host.ip;
            card.style.borderColor = hasVulnerabilities ? 'rgba(239, 68, 68, 0.5)' : 'transparent';
            if(host.error) { 
                card.innerHTML = `<p class="font-semibold text-white font-mono">${host.ip}</p><p class="text-xs text-red-400 truncate" title="${host.error}">${host.error}</p>`; 
                return card; 
            }
            const ipElement = document.createElement('p'); 
            ipElement.className = 'font-semibold text-white font-mono'; 
            ipElement.textContent = host.ip;
            const osElement = document.createElement('p'); 
            osElement.className = 'text-xs text-green-400 truncate'; 
            osElement.title = osGuess; 
            osElement.textContent = osGuess;
            const servicesElement = document.createElement('p'); 
            servicesElement.className = 'text-xs text-purple-400 truncate'; 
            servicesElement.title = servicesText; 
            servicesElement.textContent = servicesText;
            card.appendChild(ipElement); 
            card.appendChild(osElement); 
            card.appendChild(servicesElement);
            if (hasVulnerabilities) { 
                const vulnElement = document.createElement('p'); 
                vulnElement.className = 'text-xs text-red-400 font-bold mt-1'; 
                vulnElement.textContent = `${host.vulnerabilities.length} CVE trovate`; 
                card.appendChild(vulnElement); 
            }
            return card;
        },
        
        async dispatchScan() {
            if (this.state.isScanning) return;
            const host = this.elements.targetIp.value.trim();
            if (!host) { 
                this.appendToLog(this.elements.mainLogConsole, 'Errore: Inserire un host target.', 'error'); 
                return; 
            }
            this.state.isScanning = true;
            this.setLoading(this.elements.startScanBtn, this.elements.scanBtnText, this.elements.scanBtnIcon, true, 'Avvia Scansione');
            let endpoint, body, scanType = this.elements.scanType.value, ports = this.elements.ports.value.trim();
            switch (scanType) {
                case 'tcp': 
                    if (!ports) { 
                        this.appendToLog(this.elements.mainLogConsole, 'Errore: Inserire le porte.', 'error'); 
                        this.state.isScanning = false; 
                        this.setLoading(this.elements.startScanBtn, this.elements.scanBtnText, this.elements.scanBtnIcon, false, 'Avvia Scansione'); 
                        return; 
                    } 
                    endpoint = '/nmap/syn-scan'; 
                    body = { host, ports }; 
                    break;
                case 'comprehensive': 
                    endpoint = '/nmap/comprehensive-scan'; 
                    body = { host }; 
                    break;
                case 'full': 
                    endpoint = '/nmap/full-port-scan'; 
                    body = { host, maxPorts: 1000 }; 
                    break;
                case 'vuln': 
                    endpoint = '/vuln/scan'; 
                    body = { host }; 
                    break;
            }
            this.appendToLog(this.elements.mainLogConsole, `Inizio Scansione (${scanType}) su ${host}...`, 'scan');
            const data = await this.apiCall(endpoint, { 
                method: 'POST', 
                headers: { 'Content-Type': 'application/json' }, 
                body: JSON.stringify(body) 
            });
            if (data) { 
                this.appendToLog(this.elements.mainLogConsole, `Scansione completata.`, 'success', data); 
            }
            this.state.isScanning = false;
            this.setLoading(this.elements.startScanBtn, this.elements.scanBtnText, this.elements.scanBtnIcon, false, 'Avvia Scansione');
        },
        
        executeNetworkMap() {
            if (this.state.isScanning) return;
            const network = this.elements.networkRange.value.trim();
            if (!network) { 
                this.appendToLog(this.elements.mainLogConsole, 'Inserire un Network Base.', 'error'); 
                return; 
            }
            this.state.isScanning = true;
            this.setLoading(this.elements.networkMapBtn, this.elements.networkMapText, this.elements.networkMapIcon, true, 'Avvia Mappatura Rete', '🗺️');
            const oldContainer = document.getElementById('host-cards-container');
            if (oldContainer) { 
                const parent = oldContainer.parentElement; 
                if(parent.previousElementSibling?.innerHTML?.includes('Host Rilevati')) 
                    parent.previousElementSibling.remove(); 
                parent.remove(); 
            }
            this.state.ws.send(JSON.stringify({ 
                type: 'start_network_map', 
                network, 
                options: { runVulnScan: this.elements.vulnScanCheckbox.checked } 
            }));
        },
        
        updateScanProgress(progress) {
             this.elements.progressContainer.classList.remove('hidden'); 
             let percentage = 0;
             switch (progress.stage) {
                 case 'discovery_start': 
                    this.elements.progressLabel.textContent = 'Fase 1: Scoperta Host...'; 
                    this.elements.progressBar.style.width = '0%'; 
                    this.elements.progressPercentage.textContent = '0%'; 
                    this.elements.etrLabel.textContent = ''; 
                    break;
                 case 'discovery_progress': 
                    percentage = Math.round((progress.current / progress.total) * 100); 
                    this.elements.progressBar.style.width = `${percentage}%`; 
                    this.elements.progressPercentage.textContent = `${percentage}%`; 
                    break;
                 case 'discovery_complete': 
                    this.appendToLog(this.elements.mainLogConsole, `Trovati ${progress.count} host attivi.`, 'success'); 
                    this.elements.progressBar.style.width = '100%'; 
                    break;
                 case 'scan_start': 
                    if (progress.total === 0) { 
                        this.state.isScanning = false; 
                        this.setLoading(this.elements.networkMapBtn, this.elements.networkMapText, this.elements.networkMapIcon, false, 'Avvia Mappatura Rete', '🗺️'); 
                        this.elements.progressContainer.classList.add('hidden'); 
                        return; 
                    } 
                    this.elements.progressLabel.textContent = `Fase 2: Scansione di ${progress.total} Host...`; 
                    this.elements.progressBar.style.width = '0%'; 
                    this.elements.progressPercentage.textContent = '0%'; 
                    this.state.scanStartTime = Date.now(); 
                    break;
                 case 'host_scanned': 
                    percentage = Math.round((progress.current / progress.total) * 100); 
                    this.elements.progressBar.style.width = `${percentage}%`; 
                    this.elements.progressPercentage.textContent = `${percentage}%`; 
                    const cardsContainer = document.getElementById('host-cards-container') || this.createCardsContainer(); 
                    if(progress.hostData) 
                        cardsContainer.appendChild(this.createHostCard(progress.hostData)); 
                    this.elements.mainLogConsole.scrollTop = this.elements.mainLogConsole.scrollHeight; 
                    const elapsedTime = Date.now() - this.state.scanStartTime; 
                    const hostsRemaining = progress.total - progress.current; 
                    const etrMs = hostsRemaining * (elapsedTime / progress.current); 
                    if (hostsRemaining > 0) { 
                        const s = Math.round(etrMs / 1000); 
                        this.elements.etrLabel.textContent = `Tempo stimato rimanente: ${Math.floor(s/60)}m ${s%60}s`; 
                    } else { 
                        this.elements.etrLabel.textContent = 'Completamento...'; 
                    } 
                    break;
             }
        },
        
        handleNetworkMapResult(message) {
            this.state.isScanning = false;
            this.setLoading(this.elements.networkMapBtn, this.elements.networkMapText, this.elements.networkMapIcon, false, 'Avvia Mappatura Rete', '🗺️');
            this.elements.progressContainer.classList.add('hidden');
            if (message.status === 'completed') { 
                this.appendToLog(this.elements.mainLogConsole, 'Mappatura rete completata con successo.', 'success'); 
                if(message.data?.statistics) 
                    this.appendToLog(this.elements.mainLogConsole, 'Statistiche finali', 'result', message.data.statistics); 
            }
            else { 
                this.appendToLog(this.elements.mainLogConsole, `Errore mappatura: ${message.message}`, 'error'); 
            }
        },

        executeSshAttack() {
            if (this.state.isSshAttacking) {
                this.state.ws.send(JSON.stringify({ type: 'stop_attack' }));
                return;
            }
            const host = this.elements.sshTargetHost.value.trim();
            const port = parseInt(this.elements.sshTargetPort.value);
            const user = this.elements.sshTargetUser.value.trim();
            const passwords = this.elements.sshPasswordList.value.split('\n').map(p => p.trim()).filter(Boolean);
            if (!host || !port || !user || passwords.length === 0) { 
                this.appendToLog(this.elements.sshLogConsole, 'Configurazione incompleta.', 'error'); 
                return; 
            }
            this.state.isSshAttacking = true;
            this.setLoading(this.elements.sshStartAttackBtn, this.elements.sshAttackBtnText, this.elements.sshAttackBtnIcon, true, "Avvia Attacco", "⚡");
            this.elements.sshAttackBtnText.textContent = 'Interrompi Attacco';
            this.elements.sshProgressContainer.classList.remove('hidden');
            this.updateSshProgress(0, passwords.length);
            this.state.ws.send(JSON.stringify({ 
                type: 'start_attack', 
                host, 
                port, 
                user, 
                passwords 
            }));
        },
        
        updateSshProgress(current, total) { 
            this.elements.sshProgressBar.style.width = `${current/total*100}%`; 
            this.elements.sshProgressText.textContent = `${Math.round(current/total*100)}% (${current}/${total})`; 
        },
        
        handleSshPasswordFound(data) { 
            this.appendToLog(this.elements.sshLogConsole, `🎉 TROVATA! La password per ${data.username} è: ${data.password}`, 'vuln'); 
            this.state.isSshAttacking = false; 
            this.setLoading(this.elements.sshStartAttackBtn, this.elements.sshAttackBtnText, this.elements.sshAttackBtnIcon, false, "Avvia Attacco", "⚡"); 
            this.elements.sshAttackBtnText.textContent = 'Avvia Attacco'; 
        },
        
        handleSshAttackFinished() { 
            this.state.isSshAttacking = false; 
            this.setLoading(this.elements.sshStartAttackBtn, this.elements.sshAttackBtnText, this.elements.sshAttackBtnIcon, false, "Avvia Attacco", "⚡"); 
            this.elements.sshAttackBtnText.textContent = 'Avvia Attacco'; 
        },
        
        async executeSqlScan() {
            const url = this.elements.sqlTargetUrl.value.trim();
            const scanType = this.elements.sqlScanType.value;
            const safeMode = this.elements.sqlSafeMode.checked;
            
            if (!url) {
                this.appendToLog(this.elements.sqlResultsContent, 'Error: Please enter a target URL', 'error');
                return;
            }

            this.state.isScanning = true;
            this.setLoading(this.elements.sqlStartScanBtn, this.elements.sqlScanText, this.elements.sqlScanIcon, true, 'Scanning...', '⏳');
            this.elements.sqlStopScanBtn.disabled = false;
            this.elements.sqlProgressContainer.classList.remove('hidden');
            this.elements.sqlScanStats.classList.remove('hidden');
            
            this.appendToLog(this.elements.sqlResultsContent, `Starting ${scanType} scan on ${url}...`, 'sql');
            
            try {
                const response = await fetch(`${this.config.apiBaseUrl}/sql/scan`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        url, 
                        scanType,
                        safeMode 
                    })
                });
                
                const data = await response.json();
                if (data.error) throw new Error(data.error);
                
                this.state.currentSqlScanId = data.data.id;
                
                // Avvia polling per lo stato
                this.state.sqlScanInterval = setInterval(() => {
                    this.checkSqlScanStatus();
                }, 2000);
                
            } catch (error) {
                this.handleSqlScanError({ message: error.message });
            }
        },

        async checkSqlScanStatus() {
            if (!this.state.currentSqlScanId) return;
            
            try {
                const response = await fetch(`${this.config.apiBaseUrl}/sql/status/${this.state.currentSqlScanId}`);
                const data = await response.json();
                
                if (data.error) throw new Error(data.error);
                
                if (data.data.status === 'completed') {
                    this.handleSqlScanResult(data.data);
                } else if (data.data.status === 'running') {
                    this.updateSqlScanProgress({
                        current: data.data.stats?.totalTests || 0,
                        total: data.data.stats?.estimatedTotal || 100,
                        message: `Testing ${data.data.currentTest || 'unknown'}...`
                    });
                }
                
            } catch (error) {
                console.error('Error checking scan status:', error);
            }
        },

        async cancelSqlScan() {
            if (!this.state.currentSqlScanId) return;
            
            try {
                const response = await fetch(`${this.config.apiBaseUrl}/sql/cancel/${this.state.currentSqlScanId}`, {
                    method: 'POST'
                });
                
                const data = await response.json();
                if (data.error) throw new Error(data.error);
                
                this.appendToLog(this.elements.sqlResultsContent, `Scan ${this.state.currentSqlScanId} cancelled`, 'warning');
                this.resetSqlScanState();
                
            } catch (error) {
                this.appendToLog(this.elements.sqlResultsContent, `Error cancelling scan: ${error.message}`, 'error');
            }
        },

        updateSqlScanProgress(progress) {
            const percentage = Math.round((progress.current / progress.total) * 100);
            this.elements.sqlProgressBar.style.width = `${percentage}%`;
            this.elements.sqlProgressPercentage.textContent = `${percentage}%`;
            this.elements.sqlTestsCount.textContent = progress.current;
            
            if (progress.message) {
                this.appendToLog(this.elements.sqlResultsContent, progress.message, 'info');
            }
        },

        handleSqlScanResult(data) {
            clearInterval(this.state.sqlScanInterval);
            this.resetSqlScanState();
            
            // Processa i risultati
            let vulnerabilitiesCount = 0;
            let resultsHtml = '';
            
            resultsHtml += `
                <div class="mb-6 p-4 bg-black/20 rounded-lg border ${data.status === 'completed' ? 'border-green-500/30' : 'border-red-500/30'}">
                    <h4 class="text-lg font-bold mb-2">Scan Summary</h4>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                        <div>
                            <p class="text-gray-400">Target</p>
                            <p class="text-blue-300 break-all">${this.escapeHtml(data.target)}</p>
                        </div>
                        <div>
                            <p class="text-gray-400">Status</p>
                            <p class="${data.status === 'completed' ? 'text-green-400' : 'text-red-400'}">${data.status}</p>
                        </div>
                        <div>
                            <p class="text-gray-400">Duration</p>
                            <p>${((new Date(data.endTime) - new Date(data.startTime)) / 1000)}s</p>
                        </div>
                        <div>
                            <p class="text-gray-400">Injection Points</p>
                            <p>${data.stats.injectionPoints}</p>
                        </div>
                        <div>
                            <p class="text-gray-400">Tests Performed</p>
                            <p>${data.stats.totalTests}</p>
                        </div>
                        <div>
                            <p class="text-gray-400">Vulnerabilities</p>
                            <p class="${data.stats.vulnerabilitiesFound > 0 ? 'text-red-400 font-bold' : 'text-green-400'}">
                                ${data.stats.vulnerabilitiesFound}
                            </p>
                        </div>
                    </div>
                </div>
            `;
            
            data.results.forEach((result, index) => {
                vulnerabilitiesCount += result.results.filter(r => r.isVulnerable).length;
                
                resultsHtml += `
                    <div class="mb-6">
                        <h4 class="font-bold mb-2 text-lg">${index + 1}. ${result.point.type === 'form' ? 'Form' : 'URL Parameter'}</h4>
                        <div class="text-sm text-gray-400 mb-3">
                            <p>URL: <span class="text-blue-300">${this.escapeHtml(result.point.url)}</span></p>
                            <p>Method: <span class="font-mono">${result.point.method}</span></p>
                        </div>
                        
                        <div class="space-y-3">
                `;
                
                result.results.forEach(test => {
                    resultsHtml += `
                        <div class="p-4 rounded-lg ${test.isVulnerable ? 'sql-vulnerable' : 'sql-safe'}">
                            <div class="flex justify-between items-start">
                                <div>
                                    <p class="font-mono text-sm mb-2 break-all">Payload: <span class="text-yellow-300">${this.escapeHtml(test.payload)}</span></p>
                                    <p class="text-sm">Status: ${test.status} - 
                                        <span class="${test.isVulnerable ? 'text-red-400 font-bold' : 'text-green-400'}">
                                            ${test.isVulnerable ? 'VULNERABLE' : 'SAFE'}
                                        </span>
                                    </p>
                                    ${test.error ? `<p class="text-xs text-red-300 mt-1">Error: ${this.escapeHtml(test.error)}</p>` : ''}
                                </div>
                                <span class="px-2 py-1 text-xs rounded-full ${test.isVulnerable ? 'bg-red-500/20 text-red-300' : 'bg-green-500/20 text-green-300'}">
                                    ${test.isVulnerable ? 'CRITICAL' : 'SAFE'}
                                </span>
                            </div>
                            ${test.isVulnerable ? `
                            <div class="mt-2 p-2 bg-red-900/10 rounded border border-red-900/30">
                                <p class="text-xs text-red-300">Vulnerability detected: ${this.detectVulnerabilityType(test.payload)}</p>
                            </div>
                            ` : ''}
                        </div>
                    `;
                });
                
                resultsHtml += `
                        </div>
                    </div>
                `;
            });
            
            // Aggiorna il conteggio vulnerabilità
            if (vulnerabilitiesCount > 0) {
                this.elements.sqlVulnCount.textContent = vulnerabilitiesCount;
                this.elements.sqlVulnCount.classList.remove('hidden');
            }
            
            this.elements.sqlResultsContent.innerHTML = resultsHtml;
            this.elements.sqlResultsContent.scrollTop = 0;
        },

        detectVulnerabilityType(payload) {
            if (payload.includes('UNION SELECT')) return 'Union-Based SQL Injection';
            if (payload.includes('WAITFOR DELAY') || payload.includes('SLEEP(')) return 'Time-Based Blind SQLi';
            if (payload.includes('CONVERT(int') || payload.includes('1/0')) return 'Error-Based SQLi';
            if (payload.includes('SUBSTRING')) return 'Blind SQL Injection';
            if (payload.includes('OR 1=1') || payload.includes("OR '1'='1")) return 'Basic SQL Injection';
            return 'SQL Injection Vulnerability';
        },

        handleSqlScanError(error) {
            clearInterval(this.state.sqlScanInterval);
            this.resetSqlScanState();
            
            this.appendToLog(this.elements.sqlResultsContent, `Scan failed: ${error.message}`, 'error');
        },

        resetSqlScanState() {
            this.state.isScanning = false;
            this.state.currentSqlScanId = null;
            this.setLoading(this.elements.sqlStartScanBtn, this.elements.sqlScanText, this.elements.sqlScanIcon, false, 'Start Scan', '🔍');
            this.elements.sqlStopScanBtn.disabled = true;
            this.elements.sqlProgressContainer.classList.add('hidden');
            this.elements.sqlScanStats.classList.add('hidden');
            this.elements.sqlProgressBar.style.width = '0%';
            this.elements.sqlProgressPercentage.textContent = '0%';
            this.elements.sqlTestsCount.textContent = '0';
        },

        escapeHtml(unsafe) {
            return unsafe
                .replace(/&/g, "&amp;")
                .replace(/</g, "&lt;")
                .replace(/>/g, "&gt;")
                .replace(/"/g, "&quot;")
                .replace(/'/g, "&#039;");
        },

        async getInitialNetworkInfo() { 
            const data = await this.apiCall('/network/local-info'); 
            if (data?.networkBase) { 
                this.elements.networkRange.value = data.networkBase; 
                this.elements.pingSweepNetwork.value = data.networkBase; 
                this.elements.localNetworkInfo.textContent = `Rilevata rete locale: ${data.localIP}`; 
            } else { 
                this.elements.localNetworkInfo.textContent = `Impossibile rilevare la rete locale.`; 
            } 
        },
        
        async setTargetToWiFi() { 
            const data = await this.apiCall('/network/local-info'); 
            if (data?.networkBase) { 
                this.elements.networkRange.value = data.networkBase; 
                this.elements.pingSweepNetwork.value = data.networkBase; 
                this.appendToLog(this.elements.mainLogConsole, `📡 Network range impostato su ${data.networkBase}.*`, 'success'); 
            } else { 
                this.appendToLog(this.elements.mainLogConsole, `📡 Impossibile rilevare la rete.`, 'error'); 
            } 
        },
        
        async executeTraceroute() { 
            const host = this.elements.tracerouteHost.value.trim(); 
            if (!host) return; 
            this.appendToLog(this.elements.mainLogConsole, `Esecuzione traceroute verso ${host}...`, 'scan'); 
            const data = await this.apiCall('/tools/traceroute', { 
                method: 'POST', 
                headers: { 'Content-Type': 'application/json' }, 
                body: JSON.stringify({ host }) 
            }); 
            if(data) 
                this.appendToLog(this.elements.mainLogConsole, `Traceroute per ${host} completato.`, 'success', data); 
        },
        
        async executeDnsEnum() { 
            const domain = this.elements.dnsDomain.value.trim(); 
            if (!domain) return; 
            this.appendToLog(this.elements.mainLogConsole, `Enumerazione DNS per ${domain}...`, 'scan'); 
            const data = await this.apiCall('/tools/dns-enum', { 
                method: 'POST', 
                headers: { 'Content-Type': 'application/json' }, 
                body: JSON.stringify({ domain }) 
            }); 
            if(data) 
                this.appendToLog(this.elements.mainLogConsole, `Enumerazione DNS per ${domain} completata.`, 'success', data); 
        },
        
        async executePingSweep() { 
            const network = this.elements.pingSweepNetwork.value.trim(); 
            if (!network) return; 
            this.appendToLog(this.elements.mainLogConsole, `Esecuzione Ping Sweep su ${network}.0/24...`, 'scan'); 
            const data = await this.apiCall('/tools/ping-sweep', { 
                method: 'POST', 
                headers: { 'Content-Type': 'application/json' }, 
                body: JSON.stringify({ network }) 
            }); 
            if(data) 
                this.appendToLog(this.elements.mainLogConsole, `Ping Sweep completato.`, 'success', data); 
        },
        
        async executeSinglePortScan() { 
            const host = this.elements.singleScanHost.value.trim(); 
            const port = parseInt(this.elements.singleScanPort.value, 10); 
            if (!host || !port) return; 
            this.appendToLog(this.elements.mainLogConsole, `Scansione porta ${port} su ${host}...`, 'scan'); 
            const data = await this.apiCall('/tools/scan-port', { 
                method: 'POST', 
                headers: { 'Content-Type': 'application/json' }, 
                body: JSON.stringify({ host, port }) 
            }); 
            if(data) 
                this.appendToLog(this.elements.mainLogConsole, `Scansione porta completata.`, 'success', data); 
        }
    };
    
    App.init();
});
