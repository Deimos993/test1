const dgram = require('dgram');
const { getServiceName } = require('../../utils/portUtils');
const config = require('../../config');
const { parsePorts } = require('../../utils/scanHelpers');


/**
 * Esegue una UDP scan con probe predefiniti per servizi noti.
 * @param {string} host 
 * @param {string|Array|number} ports 
 * @param {number} timing 
 * @returns {Promise<Array>}
 */
async function doUdpScan(host, ports, timing = 4) {
    const results = [];
    const promises = [];
    const timeout = config.scan_timeouts.udp[timing] || 1000;
    const portList = parsePorts(ports);

    for (const port of portList) {
        promises.push(new Promise((resolve) => {
            const client = dgram.createSocket('udp4');
            const startTime = Date.now();

            let probeData;
            if (port === 53) {
                probeData = Buffer.from([0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
            } else if (port === 123) {
                probeData = Buffer.from([0x1b, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
            } else {
                probeData = Buffer.from('UDP_PROBE');
            }

            const timer = setTimeout(() => {
                results.push({
                    port,
                    protocol: 'udp',
                    status: 'open|filtered',
                    service: getServiceName(port, 'udp'),
                    responseTime: `>${timeout}ms`,
                    reason: 'no-response'
                });
                client.close();
                resolve();
            }, timeout);

            client.on('message', () => {
                clearTimeout(timer);
                results.push({
                    port,
                    protocol: 'udp',
                    status: 'open',
                    service: getServiceName(port, 'udp'),
                    responseTime: `${Date.now() - startTime}ms`,
                    reason: 'udp-response'
                });
                client.close();
                resolve();
            });

            client.on('error', (err) => {
                clearTimeout(timer);
                results.push({
                    port,
                    protocol: 'udp',
                    status: ['ECONNREFUSED', 'EHOSTUNREACH', 'ENETUNREACH'].includes(err.code) ? 'closed' : 'open|filtered',
                    service: getServiceName(port, 'udp'),
                    responseTime: `${Date.now() - startTime}ms`,
                    reason: err.code || 'unknown'
                });
                client.close();
                resolve();
            });

            client.send(probeData, port, host);
        }));
    }

    await Promise.all(promises);
    return results.sort((a, b) => a.port - b.port);
}

module.exports = { doUdpScan };
