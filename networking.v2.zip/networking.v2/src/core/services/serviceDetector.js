// src/core/services/serviceDetector.js
const net = require('net');
const axios = require('axios');
const https = require('https');
const { getServiceName } = require('../../utils/portUtils');
const config = require('..//../config');

/**
 * Funzione helper per sondare i servizi basati su HTTP (HTTP/HTTPS).
 * @param {string} host
 * @param {number} port
 * @param {string} protocol - 'http' o 'httpss'
 * @returns {Promise<object>}
 */
async function probeHttpService(host, port, protocol = 'http') {
    const result = {
        service: protocol,
        version: 'unknown',
        proof: ''
    };
    
    const url = `${protocol}://${host}:${port}`;
    const options = {
        timeout: config.scan_timeouts.http,
        validateStatus: () => true, // Accetta qualsiasi status code
    };

    if (protocol === 'httpss') {
        options.httpsAgent = new https.Agent({ rejectUnauthorized: false });
    }

    const response = await axios.get(url, options);
    
    let serverHeader = response.headers['server'];
    let poweredByHeader = response.headers['x-powered-by'];
    let foundInBody = '';
    let proofDetails = [];

    // Analisi del body
    if (response.data && typeof response.data === 'string') {
        const body = response.data.toLowerCase();
        if (body.includes('wordpress')) {
            result.service = 'WordPress';
            const wpVersionMatch = body.match(/wp-emoji-release\.min\.js\?ver=([\d\.]+)/) || body.match(/wordpress version ([\d\.]+)/);
            if (wpVersionMatch && wpVersionMatch[1]) result.version = wpVersionMatch[1];
            foundInBody = 'WordPress';
        } else if (body.includes('joomla')) {
            result.service = 'Joomla';
            foundInBody = 'Joomla';
        } else if (body.includes('drupal')) {
            result.service = 'Drupal';
            foundInBody = 'Drupal';
        }
        
        const titleMatch = response.data.match(/<title>(.*?)<\/title>/i);
        if (titleMatch) proofDetails.push(`Title: ${titleMatch[1].substring(0, 50)}`);
    }

    // Analisi degli header
    if (serverHeader) {
        if (result.version === 'unknown') result.version = serverHeader;
        proofDetails.push(`Server: ${serverHeader}`);
    }
    if (poweredByHeader) {
        if (result.version === 'unknown') result.version = poweredByHeader;
        proofDetails.push(`X-Powered-By: ${poweredByHeader}`);
    }
     if (foundInBody) {
        proofDetails.push(`Found ${foundInBody} in body`);
    }

    result.proof = proofDetails.join('. ') || `Server responded with status ${response.status}.`;
    
    return result;
}

/**
 * Esegue il fingerprinting attivo usando sonde specifiche per protocollo e analisi dei banner.
 * @param {string} host - L'host target.
 * @param {Array} openPorts - Un array di oggetti delle porte aperte ({port, protocol, service}).
 * @returns {Promise<Array>} - Un array di risultati di servizio con versioni reali dove possibile.
 */
async function performServiceDetection(host, openPorts) {
    const detectionPromises = openPorts.map(portInfo => {
        return new Promise(async (resolve) => {
            const { port } = portInfo;
            const result = {
                port,
                protocol: 'tcp',
                service: getServiceName(port), // Iniziale, sarà aggiornato se rilevato
                version: 'unknown',
                proof: 'N/A'
            };

            try {
                if (port === 80 || port === 8080) {
                    const httpResult = await probeHttpService(host, port, 'http');
                    Object.assign(result, httpResult);
                } else if (port === 443 || port === 8443) {
                    const httpsResult = await probeHttpService(host, port, 'https');
                    Object.assign(result, httpsResult);
                } else if (port === 5432) { // PostgreSQL
                    result.version = await getPostgresVersion(host, port);
                    result.proof = result.version !== 'unknown' ? 'PostgreSQL protocol probe response' : 'Probe failed';
                } else if (port === 22) { // SSH
                    const banner = await getBanner(host, port);
                    const match = banner?.match(/^SSH-(\d+\.\d+)-(\S+)(?:\s+(.*))?/);
                    if (match) {
                        result.service = 'SSH';
                        result.version = match[2];
                        result.proof = `SSH Banner: ${banner.trim()}`;
                        if (match[3]) result.proof += ` (${match[3].trim()})`;
                    } else if (banner) {
                        result.service = 'SSH';
                        result.version = banner.trim().substring(0, 50);
                        result.proof = `SSH Generic Banner: ${banner.trim()}`;
                    }
                } else if (port === 21) { // FTP
                    const banner = await getBanner(host, port);
                    if (banner) {
                        const match = banner.match(/(vsFTPd|ProFTPD|Pure-FTPd|FileZilla|Microsoft FTP Service)\s+([\d\.]+)/i);
                        if (match) {
                            result.service = match[1];
                            result.version = match[2];
                        } else {
                            result.service = 'FTP';
                            const versionMatch = banner.match(/[\d\.]+/);
                            if (versionMatch) result.version = versionMatch[0];
                        }
                        result.proof = `FTP Banner: ${banner.trim()}`;
                    }
                } else if (port === 25 || port === 587) { // SMTP
                     const banner = await getBanner(host, port);
                    if (banner) {
                        const match = banner.match(/(Postfix|Sendmail|Exim|Microsoft ESMTP SVC|Exchanger|Cisco IronPort)\s+([\d\.]+)/i);
                        if (match) {
                            result.service = match[1];
                            result.version = match[2];
                        } else {
                            result.service = 'SMTP';
                            const versionMatch = banner.match(/[\d\.]+/);
                            if (versionMatch) result.version = versionMatch[0];
                        }
                        result.proof = `SMTP Banner: ${banner.trim()}`;
                    }
                } else if (port === 3306) { // MySQL
                    const banner = await getBanner(host, port);
                    if (banner) {
                        const match = banner.match(/(mysql|mariadb)\s+server\s+([\d\.]+)/i);
                        if (match) {
                            result.service = match[1];
                            result.version = match[2];
                        } else {
                            result.service = 'MySQL';
                            const versionMatch = banner.match(/[\d\.]+/);
                            if (versionMatch) result.version = versionMatch[0];
                        }
                        result.proof = `MySQL Banner: ${banner.trim()}`;
                    }
                } else { // Fallback per banner grabbing generico
                    const banner = await getBanner(host, port);
                    if (banner) {
                        const cleanBanner = banner.trim().replace(/[^\x20-\x7E]/g, '');
                        let serviceVersionMatch = cleanBanner.match(/(\S+)\/(\d+(\.\d+){0,3}(\S*))?/i);
                        if (!serviceVersionMatch) {
                            serviceVersionMatch = cleanBanner.match(/(\S+)\s+([\d\.]+(?:-\S+)?)/i);
                        }
                        if (serviceVersionMatch && serviceVersionMatch[1] && serviceVersionMatch[2]) {
                            result.service = serviceVersionMatch[1].toLowerCase();
                            result.version = serviceVersionMatch[2];
                            result.proof = `Generic banner match: ${serviceVersionMatch[0]}`;
                        } else {
                            const numericVersionMatch = cleanBanner.match(/(v?\d+(\.\d+){0,3}(\.\d+)?(-[a-z0-9\._]+)?)/i);
                            if (numericVersionMatch) {
                                result.version = numericVersionMatch[0];
                                result.proof = `Generic banner (numeric version): ${numericVersionMatch[0]}`;
                            } else {
                                result.version = cleanBanner.substring(0, Math.min(cleanBanner.length, 100));
                                result.proof = 'Generic banner grabbing.';
                            }
                        }
                    }
                }
            } catch (error) {
                result.proof = `Connection or probe attempt failed. Error: ${error.message}`;
            }

            resolve(result);
        });
    });

    return Promise.all(detectionPromises);
}

function getPostgresVersion(host, port) {
    return new Promise((resolve) => {
        const socket = new net.Socket();
        socket.setTimeout(config.scan_timeouts.postgres);
        const startupMessage = Buffer.from([0x00, 0x00, 0x00, 0x08, 0x04, 0xd2, 0x16, 0x2f]);
        socket.on('connect', () => socket.write(startupMessage));
        socket.on('data', (data) => {
            const response = data.toString();
            const match = response.match(/PostgreSQL ([\d\.]+)|\b(\d{1,2}\.\d{1,2}(?:\.\d{1,2})?)\b/i);
            if (match) {
                const version = match[1] || match[2];
                resolve(`PostgreSQL ${version}`);
            } else {
                resolve('PostgreSQL (version not detected)');
            }
            socket.destroy();
        });
        socket.on('error', () => { resolve('unknown'); socket.destroy(); });
        socket.on('timeout', () => { resolve('unknown'); socket.destroy(); });
        socket.connect(port, host);
    });
}

function getBanner(host, port) {
    return new Promise((resolve) => {
        const socket = new net.Socket();
        socket.setTimeout(config.scan_timeouts.banner);
        const probe = '\r\n';
        socket.on('connect', () => socket.write(probe));
        socket.on('data', (data) => {
            socket.destroy();
            resolve(data.toString());
        });
        socket.on('error', () => { socket.destroy(); resolve(null); });
        socket.on('timeout', () => { socket.destroy(); resolve(null); });
        socket.connect(port, host);
    });
}

async function scanSinglePort(host, port) {
    return new Promise((resolve) => {
        const socket = new net.Socket();
        const timeout = config.scan_timeouts.banner;
        socket.setTimeout(timeout);
        socket.connect(port, host, () => {
             socket.once('data', (data) => {
                let banner = data.toString('utf8').trim().replace(/[^\x20-\x7E]/g, '', 'g');
                let service = getServiceName(port);
                let version = 'unknown';
                if (banner) {
                   const lowerBanner = banner.toLowerCase();
                    if (lowerBanner.includes('ssh')) service = 'SSH';
                    else if (lowerBanner.includes('http')) service = 'HTTP';
                    else if (lowerBanner.includes('ftp')) service = 'FTP';
                    else if (lowerBanner.includes('smtp')) service = 'SMTP';
                    else if (lowerBanner.includes('mysql')) service = 'MySQL';
                    else if (lowerBanner.includes('postgresql')) service = 'PostgreSQL';
                    const versionMatch = banner.match(/(\S+)\/(\d+(\.\d+){0,3}(\S*))?/i);
                    if (versionMatch && versionMatch[2]) {
                        version = versionMatch[2];
                        if (versionMatch[1]) service = versionMatch[1];
                    } else {
                        const simpleVersionMatch = banner.match(/(v?\d+(\.\d+){0,3}(\.\d+)?(-[a-z0-9\._]+)?)/i);
                        if (simpleVersionMatch) version = simpleVersionMatch[0];
                    }
                }
                resolve({ port, status: 'open', service, version, banner: banner.substring(0, 200) });
                socket.destroy();
            });
            setTimeout(() => {
                if (!socket.destroyed) {
                    resolve({ port, status: 'open', service: getServiceName(port), version: 'unknown', banner: 'No banner received, but port is open.' });
                    socket.destroy();
                }
            }, timeout / 2);
        });
        socket.on('timeout', () => {
            resolve({ port, status: 'filtered', service: getServiceName(port), version: 'unknown', reason: 'timeout' });
            socket.destroy();
        });
        socket.on('error', (err) => {
            resolve({ port, status: 'closed', service: getServiceName(port), version: 'unknown', reason: err.code });
            socket.destroy();
        });
    });
}

module.exports = {
    performServiceDetection,
    scanSinglePort,
};