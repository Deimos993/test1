// core/services/osDetector.js
/**
 * Tenta una semplice inferenza del sistema operativo basata sulle porte aperte e sui banner.
 * @param {Array} openPortsWithServiceDetails - Un array di oggetti delle porte aperte con i dettagli del servizio (inclusi i banner/versioni).
 * @returns {object} - Un oggetto con il possibile OS e la confidenza.
 */
async function performOSDetection(openPortsWithServiceDetails) {
    const osHints = {
        // Port: [OS, Weight]
        22: [['Linux', 'Unix'], 3],
        135: [['Windows'], 5],
        139: [['Windows', 'Linux (Samba)'], 3],
        445: [['Windows', 'Linux (Samba)'], 5],
        3389: [['Windows'], 10],
        // Aggiunti hint basati su servizi comuni
        80: [['Linux', 'Windows'], 2], // HTTP server, OS could be either
        443: [['Linux', 'Windows'], 2], // HTTPS server, OS could be either
        21: [['Linux', 'Unix', 'Windows'], 1], // FTP, very generic
        25: [['Linux', 'Unix', 'Windows'], 1], // SMTP, very generic
        3306: [['Linux', 'Windows'], 2], // MySQL, common on both
        5432: [['Linux', 'Unix'], 2], // PostgreSQL, more common on Linux/Unix
    };

    const bannerHints = {
        'apache': [['Linux', 'Unix'], 4],
        'nginx': [['Linux', 'Unix'], 4],
        'microsoft-iis': [['Windows'], 8],
        'ftp': [['Linux', 'Unix', 'Windows'], 2], // Need more specific analysis for FTP banners
        'samba': [['Linux'], 5],
        'openssh': [['Linux', 'Unix'], 5],
        'vsftpd': [['Linux'], 5],
        'postfix': [['Linux', 'Unix'], 3],
        'sendmail': [['Linux', 'Unix'], 3],
        'mysql': [['Linux', 'Windows'], 3],
        'postgresql': [['Linux', 'Unix'], 3],
        'iis': [['Windows'], 8], // Often just "IIS" in banner
        'windows': [['Windows'], 10], // Direct mention
        'ubuntu': [['Linux'], 10],
        'debian': [['Linux'], 10],
        'centos': [['Linux'], 10],
        'red hat': [['Linux'], 10],
        'cisco': [['Cisco IOS'], 10], // Example for network devices
    };

    const scores = {};
    let totalWeight = 0;

    openPortsWithServiceDetails.forEach(serviceDetail => {
        const { port, service, version, banner } = serviceDetail;

        // Hint basati sulle porte
        if (osHints[port]) {
            const [osList, weight] = osHints[port];
            osList.forEach(os => {
                scores[os] = (scores[os] || 0) + weight;
            });
            totalWeight += weight;
        }

        // Hint basati sui banner e sulle versioni dei servizi
        const relevantText = `${service || ''} ${version || ''} ${banner || ''}`.toLowerCase();
        for (const hint in bannerHints) {
            if (relevantText.includes(hint)) {
                const [osList, weight] = bannerHints[hint];
                osList.forEach(os => {
                    scores[os] = (scores[os] || 0) + weight;
                });
                totalWeight += weight;
            }
        }
    });

    if (totalWeight === 0) {
        return { possible: [{ os: 'Unknown', confidence: '100%' }], confidence: 'Low', method: 'Port/Banner-based inference (no strong clues)' };
    }

    // Convert scores to percentages for confidence
    const possible = Object.entries(scores)
        .sort(([, a], [, b]) => b - a)
        .map(([os, score]) => ({ os, confidence: ((score / totalWeight) * 100).toFixed(0) + '%' }));

    // Aumenta la confidenza se il peso totale è alto
    let overallConfidence = 'Low';
    if (totalWeight > 15) {
        overallConfidence = 'Medium';
    }
    if (totalWeight > 30) {
        overallConfidence = 'High';
    }

    return {
        possible,
        confidence: overallConfidence,
        method: 'Port and Banner Inference'
    };
}

module.exports = { performOSDetection };