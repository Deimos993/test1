// src/api/controllers/sqlInjectionController.js
const sqlInjectionService = require('../../core/services/sqlInjectionService');
const logger = require('../../utils/logger');

module.exports = {
  async scan(req, res) {
    try {
      const { url, scanType = 'basic', safeMode = true } = req.body;
      
      if (!url) {
        return res.status(400).json({ error: 'URL parameter is required' });
      }

      logger.info(`Starting SQL injection scan for ${url} (Type: ${scanType})`);
      const results = await sqlInjectionService.scan(url, { scanType, safeMode });
      
      res.json({
        status: 'success',
        data: results
      });

    } catch (error) {
      logger.error(`SQL injection scan failed: ${error.message}`);
      res.status(500).json({ 
        status: 'error',
        message: error.message 
      });
    }
  },

  async getScanStatus(req, res) {
    try {
      const { scanId } = req.params;
      const status = sqlInjectionService.getScanStatus(scanId);
      
      if (!status) {
        return res.status(404).json({ error: 'Scan not found' });
      }
      
      res.json({
        status: 'success',
        data: status
      });
    } catch (error) {
      res.status(500).json({ 
        status: 'error',
        message: error.message 
      });
    }
  },

  async cancelScan(req, res) {
    try {
      const { scanId } = req.params;
      const success = sqlInjectionService.cancelScan(scanId);
      
      if (!success) {
        return res.status(404).json({ 
          status: 'error',
          message: 'Scan not found or already completed' 
        });
      }
      
      res.json({
        status: 'success',
        message: 'Scan cancelled successfully'
      });
    } catch (error) {
      res.status(500).json({ 
        status: 'error',
        message: error.message 
      });
    }
  },

  toggleSafeMode(req, res) {
    try {
      const newMode = sqlInjectionService.toggleSafeMode();
      res.json({
        status: 'success',
        safeMode: newMode
      });
    } catch (error) {
      res.status(500).json({ 
        status: 'error',
        message: error.message 
      });
    }
  }
};