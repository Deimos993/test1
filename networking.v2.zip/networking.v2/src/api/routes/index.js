// api/routes/index.js
const express = require('express');
const router = express.Router();

const nmapRoutes = require('./nmapRoutes');
const vulnerabilityRoutes = require('./vulnerabilityRoutes');
const networkToolsRoutes = require('./networkToolsRoutes');
const networkRoutes = require('./networkRoutes'); // Add this line

// Monta i router specifici su sotto-percorsi
router.use('/nmap', nmapRoutes);
router.use('/vuln', vulnerabilityRoutes);
router.use('/tools', networkToolsRoutes);
router.use('/network', networkRoutes); // Add this line

module.exports = router;