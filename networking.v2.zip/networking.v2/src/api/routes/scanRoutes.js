const express = require('express');
const router = express.Router();
const { scanSubdomainPorts } = require('../controllers/portScanController');
const { crawlWebsite } = require('../controllers/crawlController');

// Scansione porte per subdomains
router.post('/scan/ports', scanSubdomainPorts);

// Web crawling
router.post('/crawl', crawlWebsite);

module.exports = router;